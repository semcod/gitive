from __future__ import annotations

import hashlib
from typing import Any


HASH_ALGORITHM = "sha256-chain-v1"


def event_hash(
    *,
    previous_event_hash: str,
    event_id: str,
    stream_id: str,
    stream_version: int,
    event_type: str,
    occurred_at: str,
    metadata: Any,
    payload_type: str,
    payload: bytes,
) -> str:
    parts: list[bytes] = [
        previous_event_hash.encode(), event_id.encode(), stream_id.encode(), str(stream_version).encode(),
        event_type.encode(), occurred_at.encode(), metadata.actor_id.encode(), metadata.correlation_id.encode(),
        metadata.causation_id.encode(), metadata.trace_id.encode(), metadata.idempotency_key.encode(),
        metadata.organization_id.encode(), metadata.principal_id.encode(), metadata.subject_user_id.encode(),
        metadata.device_id.encode(), metadata.profile_id.encode(), metadata.installation_id.encode(),
        payload_type.encode(), bytes(payload),
    ]
    digest = hashlib.sha256()
    for part in parts:
        digest.update(len(part).to_bytes(8, "big"))
        digest.update(part)
    return digest.hexdigest()


def verify_events(events) -> dict[str, Any]:
    previous = ""
    checked = 0
    for stored in events:
        envelope = stored.event_envelope()
        expected = event_hash(
            previous_event_hash=previous,
            event_id=stored.event_id,
            stream_id=stored.stream_id,
            stream_version=stored.stream_version,
            event_type=stored.event_type,
            occurred_at=stored.occurred_at,
            metadata=stored.metadata,
            payload_type=stored.payload_type,
            payload=stored.payload,
        )
        actual_previous = getattr(envelope, "previous_event_hash", "")
        actual_hash = getattr(envelope, "event_hash", "")
        algorithm = getattr(envelope, "hash_algorithm", "")
        if algorithm and algorithm != HASH_ALGORITHM:
            return {"ok": False, "checked": checked, "event_id": stored.event_id, "reason": "unsupported_hash_algorithm"}
        # Legacy 0.4 events have no hashes. They are reported, not silently treated as verified.
        if not actual_hash:
            return {"ok": False, "checked": checked, "event_id": stored.event_id, "reason": "legacy_event_without_hash"}
        if actual_previous != previous:
            return {"ok": False, "checked": checked, "event_id": stored.event_id, "reason": "previous_hash_mismatch"}
        if actual_hash != expected:
            return {"ok": False, "checked": checked, "event_id": stored.event_id, "reason": "event_hash_mismatch"}
        previous = actual_hash
        checked += 1
    return {"ok": True, "checked": checked, "last_event_hash": previous, "algorithm": HASH_ALGORITHM}
