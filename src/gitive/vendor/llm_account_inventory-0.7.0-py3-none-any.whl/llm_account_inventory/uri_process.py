from __future__ import annotations

import os
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .context import TrustedExecutionContext
from .cqrs import InventoryCQRS
from .storage import command_queue
from .observability import configure, inc, set_gauge, span
from .outbox import outbox_for


ROUTES = {
    "account-inventory://scan/run": "command",
    "account-inventory://inventory/summary": "query",
    "account-inventory://scans/list": "query",
    "account-inventory://scan/get": "query",
    "account-inventory://identities/list": "query",
    "account-inventory://services/list": "query",
    "account-inventory://credential-stores/list": "query",
    "account-inventory://credential-references/list": "query",
    "account-inventory://events/read": "query",
    "account-inventory://events/verify": "query",
    "account-inventory://projections/rebuild": "command",
    "account-inventory://commands/status": "query",
    "account-inventory://outbox/status": "query",
    "account-inventory://system/health": "query",
    "account-inventory://integrity/checkpoints/create": "command",
    "account-inventory://integrity/checkpoints/verify": "query",
    "account-inventory://metadata/keyring/status": "query",
    "account-inventory://metadata/keyring/rotate": "command",
    "account-inventory://metadata/subjects/shred": "command",
    "account-inventory://projections/blue-green-rebuild": "command",
}

QUERY_ROUTE = {
    "account-inventory://inventory/summary": "summary",
    "account-inventory://scans/list": "scans",
    "account-inventory://scan/get": "scan",
    "account-inventory://identities/list": "identities",
    "account-inventory://services/list": "services",
    "account-inventory://credential-stores/list": "credential_stores",
    "account-inventory://credential-references/list": "credential_references",
    "account-inventory://events/read": "events",
    "account-inventory://events/verify": "event_integrity",
    "account-inventory://commands/status": "command_status",
    "account-inventory://outbox/status": "outbox_status",
    "account-inventory://system/health": "system_health",
    "account-inventory://integrity/checkpoints/verify": "checkpoint_verify",
    "account-inventory://metadata/keyring/status": "keyring_status",
}

SENSITIVE_KEY = re.compile(r"(?i)(password|passwd|token|api[_-]?key|secret|private[_-]?key|refresh[_-]?token|access[_-]?token)")


class UriPolicyError(PermissionError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class UriPolicy:
    allowed_homes: tuple[Path, ...]
    credential_metadata_enabled: bool = False
    manager_network_enabled: bool = False

    @classmethod
    def from_env(cls) -> "UriPolicy":
        raw = os.environ.get("ACCOUNT_INVENTORY_ALLOWED_HOMES", "").strip()
        homes = [Path(x).expanduser().resolve() for x in raw.split(os.pathsep) if x.strip()]
        if not homes:
            homes = [Path.home().resolve()]
        return cls(
            allowed_homes=tuple(homes),
            credential_metadata_enabled=_env_bool("ACCOUNT_INVENTORY_CREDENTIAL_METADATA_ENABLED", False),
            manager_network_enabled=_env_bool("ACCOUNT_INVENTORY_MANAGER_NETWORK_ENABLED", False),
        )

    def validate_scan_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        reject_secret_bearing_payload(payload)
        raw_home = str(payload.get("home") or "").strip()
        if not raw_home:
            raise UriPolicyError("home_required", "scan home is required")
        home = Path(raw_home).expanduser().resolve()
        if not any(_within(home, root) for root in self.allowed_homes):
            raise UriPolicyError("home_not_allowed", "requested home is outside ACCOUNT_INVENTORY_ALLOWED_HOMES")
        credential_access = str(payload.get("credential_access") or "none")
        if credential_access not in {"none", "metadata"}:
            raise UriPolicyError("credential_access_invalid", "credential_access must be none or metadata")
        if credential_access == "metadata" and not self.credential_metadata_enabled:
            raise UriPolicyError("credential_metadata_disabled", "credential metadata access is disabled by connector policy")
        allow_network = bool(payload.get("allow_manager_network", False))
        if allow_network and not self.manager_network_enabled:
            raise UriPolicyError("manager_network_disabled", "password-manager network access is disabled by connector policy")
        cleaned = dict(payload)
        cleaned["home"] = str(home)
        return cleaned


class UriProcessDispatcher:
    """Dispatches only with a trusted context created by the authenticated URI server.

    Actor identity and allowed URI scopes are never read from the untrusted request
    body. In Subactor deployment they are supplied by urirun-node over the authenticated
    connector hop.
    """

    def __init__(self, data_dir: str | Path, policy: UriPolicy | None = None, *, asynchronous: bool | None = None):
        self.app = InventoryCQRS(data_dir)
        self.queue = command_queue(self.app.storage)
        self.policy = policy or UriPolicy.from_env()
        self.asynchronous = _env_bool("ACCOUNT_INVENTORY_ASYNC_COMMANDS", True) if asynchronous is None else bool(asynchronous)
        self.outbox = outbox_for(self.app.storage)
        self.metrics = configure("llm-account-inventory-uri")

    def run(self, request: dict[str, Any], context: TrustedExecutionContext) -> dict[str, Any]:
        uri = str(request.get("uri") or "")
        result_label = "ok"
        try:
            if uri not in ROUTES:
                raise UriPolicyError("uri_unknown", "URI Process route is not registered")
            if not any(_uri_matches(uri, pattern) for pattern in context.allowed_uri_processes):
                raise UriPolicyError("uri_not_allowed", "URI Process is outside trusted actor contract scope")
            payload = request.get("payload") or {}
            if not isinstance(payload, dict):
                raise ValueError("payload must be an object")
            with span("account_inventory.uri_process", uri=uri, trace_id=context.trace_id, actor_id=context.actor_id):
                return self._run_authorized(uri, payload, context)
        except Exception:
            result_label = "error"
            raise
        finally:
            inc(self.metrics.uri_requests, uri or "unknown", result_label)

    def _run_authorized(self, uri: str, payload: dict[str, Any], context: TrustedExecutionContext) -> dict[str, Any]:
        if uri == "account-inventory://scan/run":
            payload = self.policy.validate_scan_payload(payload)
            scan_id = str(payload.get("scan_id") or f"scan_{uuid.uuid4().hex}")
            command = self.app.build_run_scan_command(
                home=payload["home"],
                platform=str(payload.get("platform") or "auto"),
                deep_home=bool(payload.get("deep_home", False)),
                include_credential_stores=bool(payload.get("include_credential_stores", False)),
                credential_access=str(payload.get("credential_access") or "none"),
                allow_manager_network=bool(payload.get("allow_manager_network", False)),
                max_files=int(payload.get("max_files") or 20_000),
                max_file_bytes=int(payload.get("max_file_bytes") or 1_000_000),
                max_credential_records=int(payload.get("max_credential_records") or 200),
                manager_timeout=int(payload.get("manager_timeout") or 8),
                scan_id=scan_id,
                actor_id=context.actor_id,
                principal_id=context.principal_id,
                organization_id=context.organization_id,
                subject_user_id=context.subject_user_id,
                device_id=context.device_id,
                profile_id=context.profile_id,
                installation_id=context.installation_id,
                command_id=context.command_id,
                correlation_id=context.correlation_id,
                causation_id=context.causation_id,
                trace_id=context.trace_id,
                idempotency_key=context.idempotency_key,
                expected_version=context.expected_version,
            )
            if self.asynchronous:
                queued = self.queue.enqueue(command)
                public = {k: v for k, v in queued.items() if k != "envelope"}
                result = {
                    "ok": True,
                    "status": "accepted" if queued["status"] in {"queued", "processing"} else queued["status"],
                    "command_id": command.command_id,
                    "scan_id": scan_id,
                    "stream_id": command.stream_id,
                    "trace_id": context.trace_id,
                    "status_uri": "account-inventory://commands/status",
                    "queue": public,
                }
            else:
                result = self.app.execute_command(command)
            return self._response(uri, context.trace_id, result)
        if uri == "account-inventory://projections/rebuild":
            reject_secret_bearing_payload(payload)
            return self._response(uri, context.trace_id, self.app.rebuild_projection())
        if uri == "account-inventory://projections/blue-green-rebuild":
            reject_secret_bearing_payload(payload)
            return self._response(uri, context.trace_id, self.app.blue_green_rebuild_projection())
        if uri == "account-inventory://integrity/checkpoints/create":
            reject_secret_bearing_payload(payload)
            return self._response(uri, context.trace_id, self.app.create_integrity_checkpoint())
        if uri == "account-inventory://metadata/keyring/rotate":
            reject_secret_bearing_payload(payload)
            return self._response(uri, context.trace_id, self.app.rotate_metadata_key(str(payload.get("key_id") or "")))
        if uri == "account-inventory://metadata/subjects/shred":
            reject_secret_bearing_payload(payload)
            target = str(payload.get("subject_id") or context.subject_user_id or "").strip()
            return self._response(uri, context.trace_id, self.app.crypto_shred_subject(target))

        reject_secret_bearing_payload(payload)
        query_type = QUERY_ROUTE[uri]
        if query_type == "checkpoint_verify":
            checkpoint_id = str(payload.get("checkpoint_id") or "").strip()
            checkpoint_path = None
            if checkpoint_id:
                if not re.fullmatch(r"ckpt_[0-9a-f]{32}", checkpoint_id):
                    raise ValueError("checkpoint_id is invalid")
                from .checkpoints import checkpoint_dir
                checkpoint_path = checkpoint_dir(self.app.paths.root) / f"{checkpoint_id}.json"
            result = self.app.verify_integrity_checkpoint(checkpoint_path)
        elif query_type == "keyring_status":
            result = self.app.metadata_keyring_status()
        elif query_type == "outbox_status":
            result = {"pending": self.outbox.pending_count(), "backend": self.app.storage.backend}
        elif query_type == "system_health":
            event_pos = self.app.events.max_global_position()
            projection_pos = self.app.projection.checkpoint()
            lag = max(0, event_pos - projection_pos)
            set_gauge(self.metrics.projection_lag, self.app.storage.backend, value=lag)
            result = {
                "status": "ok",
                "backend": self.app.storage.backend,
                "event_global_position": event_pos,
                "projection_checkpoint": projection_pos,
                "projection_lag": lag,
                "outbox_pending": self.outbox.pending_count(),
            }
        elif query_type == "event_integrity":
            stream_id = str(payload.get("stream_id") or "").strip()
            if not stream_id:
                raise ValueError("stream_id is required")
            result = self.app.events.verify_integrity(stream_id)
        elif query_type == "command_status":
            command_id = str(payload.get("command_id") or "").strip()
            idempotency_key = str(payload.get("idempotency_key") or "").strip()
            if not command_id and not idempotency_key:
                raise ValueError("command_id or idempotency_key is required")
            row = self.queue.get(command_id=command_id or None, idempotency_key=idempotency_key or None)
            if row and row.get("envelope") is not None:
                row = {k: v for k, v in row.items() if k != "envelope"}
            result = {"item": row}
        else:
            result = self.app.query(query_type, payload, organization_id=context.organization_id)
        return self._response(uri, context.trace_id, result)

    @staticmethod
    def _response(uri: str, trace_id: str, result: dict[str, Any]) -> dict[str, Any]:
        return {
            "ok": True,
            "uri": uri,
            "trace_id": trace_id,
            "result": result,
            "contract": "subactor.account_inventory.v1",
            "wire_format": "protobuf-events/json-uri-boundary",
            "secret_values_exported": False,
            "pii_in_event_log": False,
        }


def reject_secret_bearing_payload(value: Any, path: str = "payload") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if SENSITIVE_KEY.search(str(key)):
                raise UriPolicyError("secret_bearing_payload_rejected", f"secret-bearing field rejected at {path}")
            reject_secret_bearing_payload(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            reject_secret_bearing_payload(child, f"{path}[{index}]")


def _uri_matches(uri: str, pattern: str) -> bool:
    if pattern == uri:
        return True
    if pattern.endswith("*"):
        return uri.startswith(pattern[:-1])
    if pattern.endswith("://"):
        return uri.startswith(pattern)
    return False


def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}
