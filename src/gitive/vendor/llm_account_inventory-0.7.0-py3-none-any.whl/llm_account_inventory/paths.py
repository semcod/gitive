from __future__ import annotations

import os
import platform as platform_module
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ScanRoots:
    home: Path
    platform: str
    roots: tuple[Path, ...]
    identity_files: tuple[Path, ...]


def normalized_platform(value: str) -> str:
    if value != "auto":
        aliases = {"mac": "darwin", "macos": "darwin", "win": "windows"}
        return aliases.get(value.lower(), value.lower())
    detected = platform_module.system().lower()
    if detected.startswith("win"):
        return "windows"
    if detected == "darwin":
        return "darwin"
    return "linux"


def discover_roots(home: Path, platform_name: str) -> ScanRoots:
    home = home.expanduser().resolve()
    common = [
        home / ".codex",
        home / ".claude",
        home / ".config",
        home / ".local" / "share",
        home / ".cache",
        home / ".ollama",
        home / ".continue",
        home / ".aider",
        home / ".huggingface",
        home / ".aws",
        home / ".azure",
    ]
    if platform_name == "darwin":
        common.extend([
            home / "Library" / "Application Support",
            home / "Library" / "Preferences",
        ])
    elif platform_name == "windows":
        # When scanning an offline Windows profile, APPDATA may not exist in the
        # current process, so conventional paths are always included.
        common.extend([
            home / "AppData" / "Roaming",
            home / "AppData" / "Local",
        ])
        appdata = os.environ.get("APPDATA")
        localappdata = os.environ.get("LOCALAPPDATA")
        if appdata:
            common.append(Path(appdata))
        if localappdata:
            common.append(Path(localappdata))

    identity_files = (
        home / ".gitconfig",
        home / ".config" / "git" / "config",
        home / ".npmrc",
        home / ".pypirc",
        home / ".zshrc",
        home / ".bashrc",
        home / ".profile",
        home / ".config" / "fish" / "config.fish",
    )
    unique: list[Path] = []
    seen: set[str] = set()
    for root in common:
        key = str(root)
        if key not in seen:
            unique.append(root)
            seen.add(key)
    return ScanRoots(home=home, platform=platform_name, roots=tuple(unique), identity_files=identity_files)
