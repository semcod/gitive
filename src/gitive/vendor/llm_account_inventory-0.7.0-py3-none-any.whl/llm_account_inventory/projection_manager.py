from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .postgres import connect
from .projections import InventoryProjection
from .storage import StorageConfig


class ProjectionSwitchError(RuntimeError):
    pass


def _pointer_path(config: StorageConfig) -> Path:
    return config.data_dir / "projection-active.json"


def active_slot(config: StorageConfig) -> str:
    explicit = (os.environ.get("ACCOUNT_INVENTORY_PROJECTION_SLOT") or "").strip().lower()
    if explicit:
        if explicit not in {"legacy", "blue", "green"}:
            raise ProjectionSwitchError("ACCOUNT_INVENTORY_PROJECTION_SLOT must be legacy, blue or green")
        return explicit
    if config.backend == "sqlite":
        path = _pointer_path(config)
        if not path.exists():
            return "legacy"
        payload = json.loads(path.read_text(encoding="utf-8"))
        slot = str(payload.get("active_slot") or "legacy")
        if slot not in {"legacy", "blue", "green"}:
            raise ProjectionSwitchError("invalid SQLite projection active slot")
        return slot
    with connect(config.database_url or "", autocommit=True) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS account_inventory_projection_control (
                singleton BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK(singleton),
                active_slot TEXT NOT NULL,
                updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
            )
            """
        )
        conn.execute(
            "INSERT INTO account_inventory_projection_control(singleton, active_slot) VALUES (TRUE, 'legacy') ON CONFLICT(singleton) DO NOTHING"
        )
        row = conn.execute("SELECT active_slot FROM account_inventory_projection_control WHERE singleton=TRUE").fetchone()
    return str(row["active_slot"])


def sqlite_projection_path(config: StorageConfig, slot: str) -> Path:
    if slot == "legacy":
        return config.data_dir / "read-model.sqlite3"
    return config.data_dir / f"read-model.{slot}.sqlite3"


def postgres_projection_schema(slot: str) -> str:
    if slot == "legacy":
        return "public"
    return f"account_inventory_projection_{slot}"


def set_active_slot(config: StorageConfig, slot: str) -> None:
    if slot not in {"legacy", "blue", "green"}:
        raise ProjectionSwitchError("invalid projection slot")
    if config.backend == "sqlite":
        path = _pointer_path(config)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({"schema": "llm-account-inventory.projection-pointer/v1", "active_slot": slot}, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
        return
    with connect(config.database_url or "", autocommit=False) as conn:
        try:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS account_inventory_projection_control (
                    singleton BOOLEAN PRIMARY KEY DEFAULT TRUE CHECK(singleton),
                    active_slot TEXT NOT NULL,
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
                )
                """
            )
            conn.execute(
                """
                INSERT INTO account_inventory_projection_control(singleton, active_slot)
                VALUES (TRUE, %s)
                ON CONFLICT(singleton) DO UPDATE SET active_slot=EXCLUDED.active_slot, updated_at=now()
                """,
                (slot,),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def build_projection(config: StorageConfig, slot: str):
    if config.backend == "sqlite":
        return InventoryProjection(sqlite_projection_path(config, slot))
    from .postgres_projection import PostgresInventoryProjection
    return PostgresInventoryProjection(config.database_url, schema=postgres_projection_schema(slot))


def blue_green_rebuild(config: StorageConfig, events, current_projection) -> dict[str, Any]:
    current_slot = active_slot(config)
    candidate_slot = "green" if current_slot == "blue" else "blue"
    candidate = build_projection(config, candidate_slot)
    # Candidate is rebuildable: clear it first even if a previous failed attempt exists.
    checkpoint = candidate.rebuild(events)
    current_projection.catch_up(events)
    before = current_projection.summary()
    after = candidate.summary()
    max_position = int(events.max_global_position())
    if checkpoint != max_position:
        raise ProjectionSwitchError("candidate projection did not reach event-store head")
    if before != after:
        raise ProjectionSwitchError("candidate projection summary differs from active projection")
    set_active_slot(config, candidate_slot)
    return {
        "ok": True,
        "previous_slot": current_slot,
        "active_slot": candidate_slot,
        "checkpoint": checkpoint,
        "summary_equal": True,
        "restart_required_for_existing_processes": True,
    }
