from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from google.protobuf.message import Message

from .protobuf_contracts import EventEnvelope, encode, full_type
from .integrity import HASH_ALGORITHM, event_hash


class ConcurrencyError(RuntimeError):
    pass


class LeaseLostError(RuntimeError):
    pass


@dataclass(frozen=True)
class EventMetadata:
    actor_id: str
    correlation_id: str
    causation_id: str
    trace_id: str
    idempotency_key: str
    organization_id: str = ""
    principal_id: str = ""
    subject_user_id: str = ""
    device_id: str = ""
    profile_id: str = ""
    installation_id: str = ""


@dataclass(frozen=True)
class PendingEvent:
    event_type: str
    payload: Message
    event_id: str | None = None
    occurred_at: str | None = None


@dataclass(frozen=True)
class StoredEvent:
    global_position: int
    event_id: str
    stream_id: str
    stream_version: int
    event_type: str
    occurred_at: str
    metadata: EventMetadata
    payload_type: str
    payload: bytes
    envelope: bytes

    def event_envelope(self):
        msg = EventEnvelope()
        msg.ParseFromString(self.envelope)
        return msg


class SQLiteEventStore:
    """Append-only SQLite event store with optimistic stream concurrency.

    SQLite remains the development/single-host backend. Its API intentionally
    mirrors the production contract: stream versions, global order, idempotent
    command claims with renewable leases, receipts and protobuf envelopes.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS events (
                    global_position INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL UNIQUE,
                    stream_id TEXT NOT NULL,
                    stream_version INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    correlation_id TEXT NOT NULL,
                    causation_id TEXT NOT NULL,
                    trace_id TEXT NOT NULL,
                    idempotency_key TEXT NOT NULL,
                    payload_type TEXT NOT NULL,
                    payload BLOB NOT NULL,
                    envelope BLOB,
                    organization_id TEXT NOT NULL DEFAULT '',
                    principal_id TEXT NOT NULL DEFAULT '',
                    subject_user_id TEXT NOT NULL DEFAULT '',
                    device_id TEXT NOT NULL DEFAULT '',
                    profile_id TEXT NOT NULL DEFAULT '',
                    installation_id TEXT NOT NULL DEFAULT '',
                    previous_event_hash TEXT NOT NULL DEFAULT '',
                    event_hash TEXT NOT NULL DEFAULT '',
                    hash_algorithm TEXT NOT NULL DEFAULT '',
                    UNIQUE(stream_id, stream_version)
                );
                CREATE INDEX IF NOT EXISTS idx_events_stream ON events(stream_id, stream_version);
                CREATE INDEX IF NOT EXISTS idx_events_trace ON events(trace_id, global_position);
                CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type, global_position);
                CREATE INDEX IF NOT EXISTS idx_events_scope ON events(organization_id, device_id, profile_id, global_position);

                CREATE TABLE IF NOT EXISTS command_receipts (
                    command_id TEXT PRIMARY KEY,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    stream_id TEXT NOT NULL,
                    result_json TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS command_claims (
                    idempotency_key TEXT PRIMARY KEY,
                    command_id TEXT NOT NULL,
                    stream_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    lease_until TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS event_outbox (
                    outbox_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL UNIQUE,
                    topic TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    envelope BLOB NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    max_attempts INTEGER NOT NULL DEFAULT 10,
                    available_at TEXT NOT NULL,
                    lease_until TEXT,
                    worker_id TEXT,
                    published_at TEXT,
                    last_error_code TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_event_outbox_ready ON event_outbox(status, available_at, outbox_id);
                """
            )
            # Forward migration for 0.3 databases.
            for name in (
                "organization_id", "principal_id", "subject_user_id",
                "device_id", "profile_id", "installation_id",
                "previous_event_hash", "event_hash", "hash_algorithm",
            ):
                self._ensure_column(conn, "events", name, "TEXT NOT NULL DEFAULT ''")

    @staticmethod
    def _ensure_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
        names = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in names:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")

    def stream_version(self, stream_id: str, conn: sqlite3.Connection | None = None) -> int:
        owned = conn is None
        conn = conn or self._connect()
        try:
            row = conn.execute(
                "SELECT COALESCE(MAX(stream_version), 0) AS version FROM events WHERE stream_id=?",
                (stream_id,),
            ).fetchone()
            return int(row["version"])
        finally:
            if owned:
                conn.close()

    def append(
        self,
        stream_id: str,
        expected_version: int,
        events: Iterable[PendingEvent],
        metadata: EventMetadata,
        *,
        command_id: str | None = None,
        command_result: dict[str, Any] | None = None,
    ) -> list[StoredEvent]:
        pending = list(events)
        if not pending and command_id is None:
            return []
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                current = self.stream_version(stream_id, conn)
                if current != expected_version:
                    raise ConcurrencyError(
                        f"stream version conflict for {stream_id}: expected={expected_version} actual={current}"
                    )
                stored: list[StoredEvent] = []
                next_version = current
                previous_hash = ""
                if current > 0:
                    previous_row = conn.execute(
                        "SELECT event_hash FROM events WHERE stream_id=? AND stream_version=?",
                        (stream_id, current),
                    ).fetchone()
                    previous_hash = str(previous_row["event_hash"] or "") if previous_row else ""
                    if not previous_hash:
                        previous_hash = f"legacy-anchor:{stream_id}:{current}"
                for item in pending:
                    next_version += 1
                    event_id = item.event_id or f"evt_{uuid.uuid4().hex}"
                    occurred_at = item.occurred_at or datetime.now(timezone.utc).isoformat()
                    payload_type = full_type(item.payload)
                    payload = encode(item.payload)
                    current_hash = event_hash(
                        previous_event_hash=previous_hash, event_id=event_id, stream_id=stream_id,
                        stream_version=next_version, event_type=item.event_type, occurred_at=occurred_at,
                        metadata=metadata, payload_type=payload_type, payload=payload,
                    )
                    cur = conn.execute(
                        """
                        INSERT INTO events(
                            event_id, stream_id, stream_version, event_type, occurred_at,
                            actor_id, correlation_id, causation_id, trace_id, idempotency_key,
                            payload_type, payload, organization_id, principal_id, subject_user_id,
                            device_id, profile_id, installation_id, previous_event_hash, event_hash, hash_algorithm
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            event_id, stream_id, next_version, item.event_type, occurred_at,
                            metadata.actor_id, metadata.correlation_id, metadata.causation_id,
                            metadata.trace_id, metadata.idempotency_key, payload_type, payload,
                            metadata.organization_id, metadata.principal_id, metadata.subject_user_id,
                            metadata.device_id, metadata.profile_id, metadata.installation_id,
                            previous_hash, current_hash, HASH_ALGORITHM,
                        ),
                    )
                    global_position = int(cur.lastrowid)
                    envelope_msg = EventEnvelope(
                        event_id=event_id,
                        stream_id=stream_id,
                        stream_version=next_version,
                        global_position=global_position,
                        event_type=item.event_type,
                        occurred_at=occurred_at,
                        actor_id=metadata.actor_id,
                        correlation_id=metadata.correlation_id,
                        causation_id=metadata.causation_id,
                        trace_id=metadata.trace_id,
                        idempotency_key=metadata.idempotency_key,
                        payload_type=payload_type,
                        payload=payload,
                        organization_id=metadata.organization_id,
                        principal_id=metadata.principal_id,
                        subject_user_id=metadata.subject_user_id,
                        device_id=metadata.device_id,
                        profile_id=metadata.profile_id,
                        installation_id=metadata.installation_id,
                        previous_event_hash=previous_hash,
                        event_hash=current_hash,
                        hash_algorithm=HASH_ALGORITHM,
                    )
                    envelope = encode(envelope_msg)
                    conn.execute("UPDATE events SET envelope=? WHERE global_position=?", (envelope, global_position))
                    now_outbox = datetime.now(timezone.utc).isoformat()
                    conn.execute(
                        """
                        INSERT OR IGNORE INTO event_outbox(
                            event_id, topic, event_type, envelope, status, attempts, max_attempts,
                            available_at, created_at, updated_at
                        ) VALUES (?, 'account-inventory.events', ?, ?, 'pending', 0, 10, ?, ?, ?)
                        """,
                        (event_id, item.event_type, envelope, now_outbox, now_outbox, now_outbox),
                    )
                    stored.append(
                        StoredEvent(
                            global_position=global_position,
                            event_id=event_id,
                            stream_id=stream_id,
                            stream_version=next_version,
                            event_type=item.event_type,
                            occurred_at=occurred_at,
                            metadata=metadata,
                            payload_type=payload_type,
                            payload=payload,
                            envelope=envelope,
                        )
                    )
                    previous_hash = current_hash
                if command_id is not None:
                    if command_result is None:
                        command_result = {}
                    now = datetime.now(timezone.utc).isoformat()
                    conn.execute(
                        """
                        INSERT INTO command_receipts(command_id, idempotency_key, stream_id, result_json, created_at)
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (
                            command_id,
                            metadata.idempotency_key,
                            stream_id,
                            json.dumps(command_result, ensure_ascii=False, sort_keys=True),
                            now,
                        ),
                    )
                    conn.execute(
                        """
                        UPDATE command_claims SET status='completed', lease_until=?, updated_at=?
                        WHERE idempotency_key=? AND command_id=?
                        """,
                        (now, now, metadata.idempotency_key, command_id),
                    )
                conn.execute("COMMIT")
                return stored
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def claim_command(
        self,
        *,
        command_id: str,
        idempotency_key: str,
        stream_id: str,
        lease_seconds: int = 120,
    ) -> dict[str, Any]:
        if not idempotency_key.strip():
            raise ValueError("idempotency_key is required")
        existing = self.get_receipt(idempotency_key=idempotency_key)
        if existing:
            return {"status": "completed", "receipt": existing}
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=max(1, int(lease_seconds)))).isoformat()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT * FROM command_claims WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if row is None:
                    conn.execute(
                        "INSERT INTO command_claims(idempotency_key, command_id, stream_id, status, lease_until, updated_at) VALUES (?, ?, ?, 'processing', ?, ?)",
                        (idempotency_key, command_id, stream_id, lease_until, now),
                    )
                    conn.execute("COMMIT")
                    return {"status": "claimed", "recovered": False, "lease_until": lease_until}
                if row["status"] == "completed":
                    conn.execute("COMMIT")
                    receipt = self.get_receipt(idempotency_key=idempotency_key)
                    return {"status": "completed", "receipt": receipt}
                lease_expired = str(row["lease_until"]) <= now
                if row["status"] == "processing" and not lease_expired:
                    conn.execute("COMMIT")
                    return {
                        "status": "in_progress",
                        "owner_command_id": row["command_id"],
                        "lease_until": row["lease_until"],
                    }
                conn.execute(
                    "UPDATE command_claims SET command_id=?, stream_id=?, status='processing', lease_until=?, updated_at=? WHERE idempotency_key=?",
                    (command_id, stream_id, lease_until, now, idempotency_key),
                )
                conn.execute("COMMIT")
                return {"status": "claimed", "recovered": lease_expired or row["status"] == "failed", "lease_until": lease_until}
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def renew_claim(self, *, command_id: str, idempotency_key: str, lease_seconds: int = 120) -> str:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=max(1, int(lease_seconds)))).isoformat()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT status, command_id, lease_until FROM command_claims WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if row is None or row["status"] != "processing" or row["command_id"] != command_id:
                    raise LeaseLostError("command lease is no longer owned by this worker")
                if str(row["lease_until"]) <= now:
                    raise LeaseLostError("command lease expired before heartbeat")
                conn.execute(
                    "UPDATE command_claims SET lease_until=?, updated_at=? WHERE idempotency_key=? AND command_id=?",
                    (lease_until, now, idempotency_key, command_id),
                )
                conn.execute("COMMIT")
                return lease_until
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def mark_claim_failed(self, *, command_id: str, idempotency_key: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                "UPDATE command_claims SET status='failed', lease_until=?, updated_at=? WHERE idempotency_key=? AND command_id=?",
                (now, now, idempotency_key, command_id),
            )

    def get_receipt(self, *, command_id: str | None = None, idempotency_key: str | None = None) -> dict[str, Any] | None:
        if not command_id and not idempotency_key:
            raise ValueError("command_id or idempotency_key is required")
        clause, value = ("command_id", command_id) if command_id else ("idempotency_key", idempotency_key)
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT command_id, idempotency_key, stream_id, result_json, created_at FROM command_receipts WHERE {clause}=?",
                (value,),
            ).fetchone()
        if not row:
            return None
        return {
            "command_id": row["command_id"],
            "idempotency_key": row["idempotency_key"],
            "stream_id": row["stream_id"],
            "result": json.loads(row["result_json"]),
            "created_at": row["created_at"],
        }

    def read_stream(self, stream_id: str, *, after_version: int = 0) -> list[StoredEvent]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM events WHERE stream_id=? AND stream_version>? ORDER BY stream_version",
                (stream_id, after_version),
            ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def read_all(self, *, after_global_position: int = 0, limit: int = 1000) -> list[StoredEvent]:
        limit = max(1, min(int(limit), 10_000))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM events WHERE global_position>? ORDER BY global_position LIMIT ?",
                (after_global_position, limit),
            ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def max_global_position(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT COALESCE(MAX(global_position), 0) AS pos FROM events").fetchone()
        return int(row["pos"])

    def stream_heads(self, *, at_global_position: int | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if at_global_position is None:
                rows = conn.execute(
                    """
                    SELECT e.stream_id, e.stream_version, e.event_hash, e.global_position
                    FROM events e
                    JOIN (
                        SELECT stream_id, MAX(stream_version) AS stream_version
                        FROM events GROUP BY stream_id
                    ) h ON h.stream_id=e.stream_id AND h.stream_version=e.stream_version
                    ORDER BY e.stream_id
                    """
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT e.stream_id, e.stream_version, e.event_hash, e.global_position
                    FROM events e
                    JOIN (
                        SELECT stream_id, MAX(stream_version) AS stream_version
                        FROM events WHERE global_position<=? GROUP BY stream_id
                    ) h ON h.stream_id=e.stream_id AND h.stream_version=e.stream_version
                    WHERE e.global_position<=?
                    ORDER BY e.stream_id
                    """,
                    (int(at_global_position), int(at_global_position)),
                ).fetchall()
        return [{
            "stream_id": str(row["stream_id"]),
            "stream_version": int(row["stream_version"]),
            "event_hash": str(row["event_hash"] or ""),
            "global_position": int(row["global_position"]),
        } for row in rows]

    def verify_integrity(self, stream_id: str) -> dict[str, Any]:
        from .integrity import verify_events
        return verify_events(self.read_stream(stream_id))

    @staticmethod
    def _row_to_event(row: sqlite3.Row) -> StoredEvent:
        keys = set(row.keys())
        def value(name: str) -> str:
            return str(row[name] or "") if name in keys else ""
        return StoredEvent(
            global_position=int(row["global_position"]),
            event_id=row["event_id"],
            stream_id=row["stream_id"],
            stream_version=int(row["stream_version"]),
            event_type=row["event_type"],
            occurred_at=row["occurred_at"],
            metadata=EventMetadata(
                actor_id=row["actor_id"], correlation_id=row["correlation_id"],
                causation_id=row["causation_id"], trace_id=row["trace_id"],
                idempotency_key=row["idempotency_key"], organization_id=value("organization_id"),
                principal_id=value("principal_id"), subject_user_id=value("subject_user_id"),
                device_id=value("device_id"), profile_id=value("profile_id"),
                installation_id=value("installation_id"),
            ),
            payload_type=row["payload_type"],
            payload=bytes(row["payload"]),
            envelope=bytes(row["envelope"] or b""),
        )
