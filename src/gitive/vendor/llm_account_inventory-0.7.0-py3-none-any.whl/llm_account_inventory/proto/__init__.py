"""Packaged protobuf source/descriptor assets."""
