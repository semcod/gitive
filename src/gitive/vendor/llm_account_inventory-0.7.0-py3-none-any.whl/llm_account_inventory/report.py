from __future__ import annotations

import json
from .model import InventoryReport


def as_json(report: InventoryReport) -> str:
    return json.dumps(report.to_dict(), ensure_ascii=False, indent=2) + "\n"


def as_jsonl(report: InventoryReport) -> str:
    rows = []
    rows.extend({"type": "provider", **item.to_dict()} for item in report.findings)
    rows.extend({"type": "credential_store", **item.to_dict()} for item in report.credential_stores)
    return "".join(json.dumps(item, ensure_ascii=False) + "\n" for item in rows)


def as_subactor_json(report: InventoryReport) -> str:
    identities: dict[str, dict] = {}
    services: list[dict] = []
    links: list[dict] = []
    evidence: list[dict] = []
    secret_indicators: list[dict] = []
    credential_stores: list[dict] = []

    for finding in report.findings:
        services.append({
            "id": finding.provider_id,
            "name": finding.provider_name,
            "category": finding.category,
            "clients": sorted(finding.clients),
            "confidence": finding.confidence,
        })
        for email in sorted(finding.emails):
            identity_id = f"email:{email}"
            identities[identity_id] = {"id": identity_id, "kind": "email", "value": email}
            links.append({
                "identity_id": identity_id,
                "service_id": finding.provider_id,
                "relation": "observed_with",
                "confidence": finding.confidence,
            })
        for name in sorted(finding.secret_names):
            secret_indicators.append({"service_id": finding.provider_id, "name": name, "value_exported": False})
        for item in finding.evidence:
            evidence.append({
                "service_id": finding.provider_id,
                "source": item.source,
                "kind": item.kind,
                "detail": item.detail,
            })

    for store in report.credential_stores:
        row = store.to_dict()
        row["secret_values_exported"] = False
        credential_stores.append(row)
        for email in sorted(store.account_emails):
            identity_id = f"email:{email}"
            identities[identity_id] = {"id": identity_id, "kind": "email", "value": email}
            links.append({
                "identity_id": identity_id,
                "service_id": f"credential-store:{store.store_id}",
                "relation": "credential_store_account",
                "confidence": "high",
            })

    payload = {
        "schema": "subactor.account-inventory/v1.1",
        "source": {
            "type": "user_home",
            "home": report.home,
            "platform": report.platform,
            "generated_at": report.generated_at,
        },
        "identities": sorted(identities.values(), key=lambda x: x["id"]),
        "services": services,
        "credential_stores": credential_stores,
        "links": links,
        "secret_indicators": secret_indicators,
        "evidence": evidence,
        "scan": {
            "files_considered": report.files_considered,
            "files_scanned": report.files_scanned,
            "files_skipped": report.files_skipped,
            "warnings": report.warnings,
        },
    }
    return json.dumps(payload, ensure_ascii=False, indent=2) + "\n"


def as_markdown(report: InventoryReport) -> str:
    lines = [
        "# LLM account inventory",
        "",
        f"- Platform: `{report.platform}`",
        f"- Home: `{report.home}`",
        f"- Files scanned: `{report.files_scanned}`",
        f"- Files skipped: `{report.files_skipped}`",
        "",
        "## Providers and identities",
        "",
        "| Provider / account | Category | Emails | Secret indicators | Confidence |",
        "|---|---|---|---|---|",
    ]
    for finding in report.findings:
        mail = "<br>".join(sorted(finding.emails)) or "—"
        secrets = "<br>".join(sorted(finding.secret_names)) or "—"
        lines.append(
            f"| {finding.provider_name} | `{finding.category}` | {mail} | {secrets} | {finding.confidence} |"
        )
    if report.credential_stores:
        lines.extend([
            "", "## Credential stores", "",
            "| Store | Kind | Deployment | Accounts | Access | Records |",
            "|---|---|---|---|---|---|",
        ])
        for store in report.credential_stores:
            accounts = "<br>".join(sorted(store.account_emails)) or "—"
            access = "ok" if store.access_ok is True else ("failed" if store.access_ok is False else "not attempted")
            lines.append(
                f"| {store.name} | `{store.kind}` | `{store.deployment}` | {accounts} | {access} | {len(store.records)} |"
            )
    lines.extend(["", "## Evidence", ""])
    for finding in report.findings:
        lines.append(f"### {finding.provider_name}")
        for item in finding.evidence:
            lines.append(f"- `{item.source}` — {item.kind}: `{item.detail}`")
        lines.append("")
    if report.credential_stores:
        lines.extend(["## Credential-store evidence", ""])
        for store in report.credential_stores:
            lines.append(f"### {store.name}")
            for item in store.evidence:
                lines.append(f"- `{item.source}` — {item.kind}: `{item.detail}`")
            for warning in store.warnings:
                lines.append(f"- warning: {warning}")
            lines.append("")
    lines.append("> Secret values are never emitted. Browser/manager access is metadata-only and opt-in.")
    lines.append("")
    return "\n".join(lines)
