from __future__ import annotations

import contextlib
import os
import threading
import time
from dataclasses import dataclass
from typing import Iterator


@dataclass
class Metrics:
    commands_claimed: object | None = None
    commands_completed: object | None = None
    commands_failed: object | None = None
    command_duration: object | None = None
    uri_requests: object | None = None
    outbox_published: object | None = None
    outbox_failed: object | None = None
    projection_lag: object | None = None


_lock = threading.Lock()
_configured = False
_metrics = Metrics()
_tracer = None


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def configure(service_name: str) -> Metrics:
    global _configured, _metrics, _tracer
    with _lock:
        if _configured:
            return _metrics

        try:
            from prometheus_client import Counter, Gauge, Histogram, start_http_server

            _metrics = Metrics(
                commands_claimed=Counter("account_inventory_commands_claimed_total", "Claimed commands", ["backend"]),
                commands_completed=Counter("account_inventory_commands_completed_total", "Completed commands", ["backend"]),
                commands_failed=Counter("account_inventory_commands_failed_total", "Failed commands", ["backend", "error"]),
                command_duration=Histogram("account_inventory_command_duration_seconds", "Command execution duration", ["backend", "command_type"]),
                uri_requests=Counter("account_inventory_uri_requests_total", "URI Process requests", ["uri", "result"]),
                outbox_published=Counter("account_inventory_outbox_published_total", "Published outbox records", ["backend"]),
                outbox_failed=Counter("account_inventory_outbox_failed_total", "Failed outbox publishes", ["backend", "error"]),
                projection_lag=Gauge("account_inventory_projection_lag_events", "Event positions not yet projected", ["backend"]),
            )
            port = int(os.environ.get("ACCOUNT_INVENTORY_PROMETHEUS_PORT", "0") or 0)
            if port > 0:
                start_http_server(port, addr=os.environ.get("ACCOUNT_INVENTORY_PROMETHEUS_HOST", "0.0.0.0"))
        except Exception:
            _metrics = Metrics()

        try:
            from opentelemetry import trace
            if _env_bool("ACCOUNT_INVENTORY_OTEL_ENABLED", False):
                from opentelemetry.sdk.resources import Resource
                from opentelemetry.sdk.trace import TracerProvider
                from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

                provider = TracerProvider(resource=Resource.create({"service.name": service_name}))
                exporter = None
                endpoint = (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or "").strip()
                if endpoint:
                    try:
                        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
                        exporter = OTLPSpanExporter(endpoint=endpoint.rstrip("/") + "/v1/traces")
                    except Exception:
                        exporter = None
                if exporter is None and _env_bool("ACCOUNT_INVENTORY_OTEL_CONSOLE", False):
                    exporter = ConsoleSpanExporter()
                if exporter is not None:
                    provider.add_span_processor(BatchSpanProcessor(exporter))
                trace.set_tracer_provider(provider)
            _tracer = trace.get_tracer(service_name)
        except Exception:
            _tracer = None

        _configured = True
        return _metrics


def metrics() -> Metrics:
    return _metrics


@contextlib.contextmanager
def span(name: str, **attributes) -> Iterator[None]:
    if _tracer is None:
        yield
        return
    with _tracer.start_as_current_span(name) as current:
        for key, value in attributes.items():
            if value is not None:
                current.set_attribute(key, value)
        yield


@contextlib.contextmanager
def timed_metric(histogram, *labels) -> Iterator[None]:
    start = time.perf_counter()
    try:
        yield
    finally:
        if histogram is not None:
            try:
                histogram.labels(*labels).observe(time.perf_counter() - start)
            except Exception:
                pass


def inc(counter, *labels, amount: float = 1.0) -> None:
    if counter is None:
        return
    try:
        counter.labels(*labels).inc(amount)
    except Exception:
        pass


def set_gauge(gauge, *labels, value: float) -> None:
    if gauge is None:
        return
    try:
        gauge.labels(*labels).set(value)
    except Exception:
        pass
