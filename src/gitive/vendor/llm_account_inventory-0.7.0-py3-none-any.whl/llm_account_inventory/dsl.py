from __future__ import annotations

import re
import shlex
from dataclasses import dataclass, field
from typing import Any, Iterable


class DslError(ValueError):
    pass


@dataclass(frozen=True)
class FilterExpr:
    field: str
    operator: str
    value: Any


@dataclass(frozen=True)
class QueryStatement:
    resource: str
    filters: tuple[FilterExpr, ...] = ()
    limit: int = 200
    offset: int = 0
    stream_id: str | None = None
    after_global_position: int = 0
    after_version: int = 0
    identifier: str | None = None


@dataclass(frozen=True)
class ScanStatement:
    home: str
    platform: str = "auto"
    deep_home: bool = False
    include_credential_stores: bool = False
    credential_access: str = "none"
    allow_manager_network: bool = False
    max_files: int = 20_000
    max_file_bytes: int = 1_000_000
    max_credential_records: int = 200
    manager_timeout: int = 8
    idempotency_key: str | None = None


@dataclass(frozen=True)
class OperationStatement:
    operation: str
    args: dict[str, Any] = field(default_factory=dict)
    confirmation: str | None = None


@dataclass(frozen=True)
class HelpStatement:
    topic: str | None = None


Statement = QueryStatement | ScanStatement | OperationStatement | HelpStatement


@dataclass(frozen=True)
class CompiledStatement:
    uri: str
    payload: dict[str, Any]
    kind: str
    filters: tuple[FilterExpr, ...] = ()
    display: str = "json"
    requires_operator: bool = False
    irreversible: bool = False
    idempotency_key: str | None = None


_QUERY_URIS = {
    "summary": "account-inventory://inventory/summary",
    "services": "account-inventory://services/list",
    "identities": "account-inventory://identities/list",
    "credential_stores": "account-inventory://credential-stores/list",
    "credential_references": "account-inventory://credential-references/list",
    "scans": "account-inventory://scans/list",
    "scan": "account-inventory://scan/get",
    "events": "account-inventory://events/read",
    "command": "account-inventory://commands/status",
    "health": "account-inventory://system/health",
    "outbox": "account-inventory://outbox/status",
    "keyring": "account-inventory://metadata/keyring/status",
}

_RESOURCE_ALIASES = {
    ("SUMMARY",): "summary",
    ("SERVICES",): "services",
    ("PROVIDERS",): "services",
    ("IDENTITIES",): "identities",
    ("ACCOUNTS",): "identities",
    ("STORES",): "credential_stores",
    ("CREDENTIAL", "STORES"): "credential_stores",
    ("CREDENTIAL", "REFERENCES"): "credential_references",
    ("CREDENTIAL", "REFS"): "credential_references",
    ("SCANS",): "scans",
    ("EVENTS",): "events",
    ("HEALTH",): "health",
    ("OUTBOX",): "outbox",
    ("KEYRING",): "keyring",
}

_FILTER_OPS = {"=", "==", "!=", "~", "CONTAINS"}
_INT_RE = re.compile(r"^-?\d+$")
_FLOAT_RE = re.compile(r"^-?\d+\.\d+$")


def parse(statement: str) -> Statement:
    text = statement.strip().rstrip(";").strip()
    if not text:
        raise DslError("empty statement")
    try:
        tokens = shlex.split(text, posix=True)
    except ValueError as exc:
        raise DslError(str(exc)) from exc
    if not tokens:
        raise DslError("empty statement")
    upper = [x.upper() for x in tokens]
    if upper[0] in {"HELP", "?"}:
        return HelpStatement(" ".join(tokens[1:]) or None)
    if upper[0] == "SHOW":
        return _parse_show(tokens)
    if upper[0] == "SCAN":
        return _parse_scan(tokens)
    if upper[:2] == ["EVENTS", "VERIFY"]:
        return _parse_events_verify(tokens)
    if upper[:2] == ["CHECKPOINT", "CREATE"]:
        return OperationStatement("checkpoint_create")
    if upper[:2] == ["CHECKPOINT", "VERIFY"]:
        checkpoint_id = tokens[2] if len(tokens) > 2 else ""
        return OperationStatement("checkpoint_verify", {"checkpoint_id": checkpoint_id})
    if upper[:2] == ["PROJECTION", "REBUILD"]:
        blue_green = len(tokens) > 2 and upper[2] in {"BLUE_GREEN", "BLUE-GREEN", "BLUE/GREEN"}
        return OperationStatement("projection_blue_green" if blue_green else "projection_rebuild")
    if upper[:2] == ["KEYRING", "STATUS"]:
        return QueryStatement("keyring")
    if upper[:2] == ["KEYRING", "ROTATE"]:
        if len(tokens) != 3:
            raise DslError("KEYRING ROTATE requires a key id")
        return OperationStatement("keyring_rotate", {"key_id": tokens[2]})
    if upper[:3] == ["CRYPTO", "SHRED", "SUBJECT"]:
        if len(tokens) < 4:
            raise DslError("CRYPTO SHRED SUBJECT requires subject id")
        subject_id = tokens[3]
        confirmation = None
        if len(tokens) >= 6 and upper[4] == "CONFIRM":
            confirmation = tokens[5]
        return OperationStatement("crypto_shred", {"subject_id": subject_id}, confirmation=confirmation)
    raise DslError(f"unsupported DSL statement: {tokens[0]}")


def compile_statement(statement: Statement) -> CompiledStatement:
    if isinstance(statement, HelpStatement):
        raise DslError("HELP is handled by the shell/dashboard and is not executable")
    if isinstance(statement, QueryStatement):
        uri = _QUERY_URIS[statement.resource]
        payload: dict[str, Any] = {"limit": statement.limit, "offset": statement.offset}
        if statement.resource == "events":
            payload.update({
                "stream_id": statement.stream_id or "",
                "after_global_position": statement.after_global_position,
                "after_version": statement.after_version,
            })
        elif statement.resource == "scan":
            payload = {"scan_id": statement.identifier or ""}
        elif statement.resource == "command":
            payload = {"command_id": statement.identifier or ""}
        elif statement.resource in {"summary", "health", "outbox", "keyring"}:
            payload = {}
        return CompiledStatement(
            uri=uri,
            payload=payload,
            kind="query",
            filters=statement.filters,
            display="table" if statement.resource not in {"summary", "health", "outbox", "keyring", "scan", "command"} else "json",
            requires_operator=statement.resource in {"events", "outbox", "keyring"},
        )
    if isinstance(statement, ScanStatement):
        return CompiledStatement(
            uri="account-inventory://scan/run",
            payload={
                "home": statement.home,
                "platform": statement.platform,
                "deep_home": statement.deep_home,
                "include_credential_stores": statement.include_credential_stores,
                "credential_access": statement.credential_access,
                "allow_manager_network": statement.allow_manager_network,
                "max_files": statement.max_files,
                "max_file_bytes": statement.max_file_bytes,
                "max_credential_records": statement.max_credential_records,
                "manager_timeout": statement.manager_timeout,
            },
            kind="command",
            requires_operator=True,
            idempotency_key=statement.idempotency_key,
        )
    if isinstance(statement, OperationStatement):
        mapping = {
            "events_verify": ("account-inventory://events/verify", "query", True, False),
            "checkpoint_create": ("account-inventory://integrity/checkpoints/create", "command", True, False),
            "checkpoint_verify": ("account-inventory://integrity/checkpoints/verify", "query", True, False),
            "projection_rebuild": ("account-inventory://projections/rebuild", "command", True, False),
            "projection_blue_green": ("account-inventory://projections/blue-green-rebuild", "command", True, False),
            "keyring_rotate": ("account-inventory://metadata/keyring/rotate", "command", True, False),
            "crypto_shred": ("account-inventory://metadata/subjects/shred", "command", True, True),
        }
        uri, kind, operator, irreversible = mapping[statement.operation]
        if irreversible:
            subject = str(statement.args.get("subject_id") or "")
            if not statement.confirmation or statement.confirmation != subject:
                raise DslError(f"irreversible operation requires: CONFIRM {shlex.quote(subject)}")
        return CompiledStatement(uri, dict(statement.args), kind, requires_operator=operator, irreversible=irreversible)
    raise DslError("unsupported AST node")


def _parse_show(tokens: list[str]) -> QueryStatement:
    if len(tokens) < 2:
        raise DslError("SHOW requires a resource")
    upper = [x.upper() for x in tokens]
    if upper[1] == "SCAN":
        if len(tokens) < 3:
            raise DslError("SHOW SCAN requires scan id")
        return QueryStatement("scan", identifier=tokens[2])
    if upper[1] == "COMMAND":
        if len(tokens) < 3:
            raise DslError("SHOW COMMAND requires command id")
        return QueryStatement("command", identifier=tokens[2])

    resource = None
    consumed = 0
    for parts, canonical in sorted(_RESOURCE_ALIASES.items(), key=lambda x: len(x[0]), reverse=True):
        end = 1 + len(parts)
        if tuple(upper[1:end]) == parts:
            resource = canonical
            consumed = end
            break
    if not resource:
        raise DslError("unknown SHOW resource")

    filters: list[FilterExpr] = []
    limit, offset = 200, 0
    stream_id = None
    after_global_position, after_version = 0, 0
    i = consumed
    while i < len(tokens):
        keyword = upper[i]
        if keyword == "WHERE":
            parsed, i = _parse_filters(tokens, i + 1)
            filters.extend(parsed)
            continue
        if keyword == "LIMIT":
            limit = _positive_int(tokens, i + 1, "LIMIT")
            i += 2
            continue
        if keyword == "OFFSET":
            offset = _nonnegative_int(tokens, i + 1, "OFFSET")
            i += 2
            continue
        if keyword == "STREAM" and resource == "events":
            stream_id = _value(tokens, i + 1, "STREAM")
            i += 2
            continue
        if keyword == "AFTER" and resource == "events":
            after_global_position = _nonnegative_int(tokens, i + 1, "AFTER")
            i += 2
            continue
        if keyword == "AFTER_VERSION" and resource == "events":
            after_version = _nonnegative_int(tokens, i + 1, "AFTER_VERSION")
            i += 2
            continue
        raise DslError(f"unexpected token in SHOW: {tokens[i]}")
    return QueryStatement(
        resource,
        filters=tuple(filters),
        limit=limit,
        offset=offset,
        stream_id=stream_id,
        after_global_position=after_global_position,
        after_version=after_version,
    )


def _parse_filters(tokens: list[str], start: int) -> tuple[list[FilterExpr], int]:
    result: list[FilterExpr] = []
    i = start
    stop = {"LIMIT", "OFFSET", "STREAM", "AFTER", "AFTER_VERSION"}
    while i < len(tokens):
        if tokens[i].upper() in stop:
            break
        if i + 2 >= len(tokens):
            raise DslError("WHERE requires: field operator value")
        field = tokens[i]
        op = tokens[i + 1].upper()
        if op not in _FILTER_OPS:
            raise DslError(f"unsupported WHERE operator: {tokens[i + 1]}")
        result.append(FilterExpr(field, "=" if op == "==" else op, _literal(tokens[i + 2])))
        i += 3
        if i < len(tokens) and tokens[i].upper() == "AND":
            i += 1
            continue
        if i < len(tokens) and tokens[i].upper() not in stop:
            raise DslError(f"expected AND or clause keyword, got: {tokens[i]}")
        break
    if not result:
        raise DslError("WHERE requires at least one condition")
    return result, i


def _parse_scan(tokens: list[str]) -> ScanStatement:
    upper = [x.upper() for x in tokens]
    if len(tokens) < 3 or upper[1] != "HOME":
        raise DslError('SCAN syntax starts with: SCAN HOME "/path"')
    values: dict[str, Any] = {"home": tokens[2]}
    i = 3
    while i < len(tokens):
        keyword = upper[i]
        if keyword == "PLATFORM":
            values["platform"] = _value(tokens, i + 1, "PLATFORM").lower()
            i += 2
        elif keyword == "DEEP":
            values["deep_home"] = True
            i += 1
        elif keyword == "WITH":
            if upper[i:i+2] == ["WITH", "CREDENTIAL"] and upper[i+2:i+3] == ["STORES"]:
                values["include_credential_stores"] = True
                i += 3
                if i < len(tokens) and upper[i] == "METADATA":
                    values["credential_access"] = "metadata"
                    i += 1
            else:
                raise DslError("supported WITH clause: WITH CREDENTIAL STORES [METADATA]")
        elif keyword == "ALLOW":
            if upper[i:i+3] != ["ALLOW", "MANAGER", "NETWORK"]:
                raise DslError("supported ALLOW clause: ALLOW MANAGER NETWORK")
            values["allow_manager_network"] = True
            i += 3
        elif keyword == "MAX_FILES":
            values["max_files"] = _positive_int(tokens, i + 1, "MAX_FILES")
            i += 2
        elif keyword == "MAX_FILE_BYTES":
            values["max_file_bytes"] = _positive_int(tokens, i + 1, "MAX_FILE_BYTES")
            i += 2
        elif keyword == "MAX_CREDENTIAL_RECORDS":
            values["max_credential_records"] = _positive_int(tokens, i + 1, "MAX_CREDENTIAL_RECORDS")
            i += 2
        elif keyword == "MANAGER_TIMEOUT":
            values["manager_timeout"] = _positive_int(tokens, i + 1, "MANAGER_TIMEOUT")
            i += 2
        elif keyword == "IDEMPOTENCY":
            values["idempotency_key"] = _value(tokens, i + 1, "IDEMPOTENCY")
            i += 2
        else:
            raise DslError(f"unexpected SCAN token: {tokens[i]}")
    return ScanStatement(**values)


def _parse_events_verify(tokens: list[str]) -> OperationStatement:
    upper = [x.upper() for x in tokens]
    if len(tokens) != 4 or upper[2] != "STREAM":
        raise DslError('EVENTS VERIFY syntax: EVENTS VERIFY STREAM "stream-id"')
    return OperationStatement("events_verify", {"stream_id": tokens[3]})


def _literal(value: str) -> Any:
    lowered = value.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered in {"null", "none"}:
        return None
    if _INT_RE.fullmatch(value):
        return int(value)
    if _FLOAT_RE.fullmatch(value):
        return float(value)
    return value


def _value(tokens: list[str], index: int, clause: str) -> str:
    if index >= len(tokens):
        raise DslError(f"{clause} requires a value")
    return tokens[index]


def _positive_int(tokens: list[str], index: int, clause: str) -> int:
    value = _nonnegative_int(tokens, index, clause)
    if value <= 0:
        raise DslError(f"{clause} must be > 0")
    return value


def _nonnegative_int(tokens: list[str], index: int, clause: str) -> int:
    raw = _value(tokens, index, clause)
    try:
        value = int(raw)
    except ValueError as exc:
        raise DslError(f"{clause} must be an integer") from exc
    if value < 0:
        raise DslError(f"{clause} must be >= 0")
    return value


def help_text() -> str:
    return """Inventory CQRS/ES DSL 0.7

Read model queries:
  SHOW SUMMARY
  SHOW SERVICES [WHERE active = true] [LIMIT 50] [OFFSET 0]
  SHOW IDENTITIES [WHERE services CONTAINS openrouter]
  SHOW CREDENTIAL STORES [WHERE active = true]
  SHOW CREDENTIAL REFERENCES [WHERE store_id = 1password]
  SHOW SCANS [LIMIT 20]
  SHOW SCAN <scan_id>
  SHOW EVENTS [STREAM <stream_id>] [AFTER <global_position>] [LIMIT 100]
  SHOW COMMAND <command_id>
  SHOW HEALTH
  SHOW OUTBOX
  SHOW KEYRING

Commands / governance:
  SCAN HOME "/home/user" PLATFORM linux [DEEP]
       [WITH CREDENTIAL STORES [METADATA]] [ALLOW MANAGER NETWORK]
       [IDEMPOTENCY <key>]
  EVENTS VERIFY STREAM <stream_id>
  CHECKPOINT CREATE
  CHECKPOINT VERIFY [checkpoint_id]
  PROJECTION REBUILD
  PROJECTION REBUILD BLUE_GREEN
  KEYRING STATUS
  KEYRING ROTATE <key_id>
  CRYPTO SHRED SUBJECT <subject_id> CONFIRM <subject_id>

WHERE operators: =, !=, ~ (case-insensitive substring), CONTAINS.
Shell commands: HELP, .context, .ast <DSL>, .compile <DSL>, .exit
"""


def statement_to_dict(statement: Statement) -> dict[str, Any]:
    if isinstance(statement, QueryStatement):
        return {
            "type": "query", "resource": statement.resource,
            "filters": [vars(x) for x in statement.filters], "limit": statement.limit,
            "offset": statement.offset, "stream_id": statement.stream_id,
            "after_global_position": statement.after_global_position,
            "after_version": statement.after_version, "identifier": statement.identifier,
        }
    if isinstance(statement, ScanStatement):
        return {"type": "scan", **vars(statement)}
    if isinstance(statement, OperationStatement):
        return {"type": "operation", "operation": statement.operation, "args": statement.args,
                "confirmation": statement.confirmation}
    return {"type": "help", "topic": statement.topic}
