from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from .keyring import KeyringError, MetadataKeyring


class MetadataVaultError(RuntimeError):
    pass


class MetadataSubjectShreddedError(MetadataVaultError):
    pass


GLOBAL_SUBJECT = "subject:global"
SUBJECT_SCHEME = "subject-dek-v1"
LEGACY_SCHEME = "legacy-fernet-v1"


class MetadataVault:
    """Encrypted reversible metadata with versioned KEKs and per-subject DEKs.

    0.6 writes use envelope encryption: each subject has a random Fernet DEK,
    wrapped by the active metadata KEK. Destroying the wrapped DEK makes all
    ciphertext for that subject irrecoverable without deleting append-only events.
    Legacy 0.5 ciphertext remains readable and is migrated during KEK rotation.
    """

    def __init__(self, data_dir: str | Path):
        root = Path(data_dir).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        self.path = root / "metadata-vault.sqlite3"
        self._lock = threading.RLock()
        try:
            self.keyring = MetadataKeyring.load(
                root,
                require_external=self._env_bool("ACCOUNT_INVENTORY_REQUIRE_EXTERNAL_KEYS", False),
            )
        except KeyringError as exc:
            raise MetadataVaultError(str(exc)) from exc
        self._reference_key = self._load_reference_key(root, self.keyring.active_key)
        self._init_db()

    @staticmethod
    def _env_bool(name: str, default: bool = False) -> bool:
        raw = os.environ.get(name)
        if raw is None:
            return default
        return raw.strip().lower() in {"1", "true", "yes", "on"}

    def _load_reference_key(self, root: Path, fernet_key: bytes) -> bytes:
        env_key = os.environ.get("ACCOUNT_INVENTORY_REFERENCE_KEY", "").strip()
        if env_key:
            try:
                decoded = base64.urlsafe_b64decode(env_key.encode("ascii"))
            except Exception as exc:
                raise MetadataVaultError("ACCOUNT_INVENTORY_REFERENCE_KEY must be urlsafe-base64") from exc
            if len(decoded) < 32:
                raise MetadataVaultError("ACCOUNT_INVENTORY_REFERENCE_KEY must decode to at least 32 bytes")
            return decoded
        if self._env_bool("ACCOUNT_INVENTORY_REQUIRE_EXTERNAL_KEYS", False):
            raise MetadataVaultError("ACCOUNT_INVENTORY_REFERENCE_KEY is required in external-key mode")

        ref_path = root / ".reference.key"
        if ref_path.exists():
            try:
                decoded = base64.urlsafe_b64decode(ref_path.read_bytes().strip())
            except Exception as exc:
                raise MetadataVaultError("local reference key is invalid") from exc
            if len(decoded) < 32:
                raise MetadataVaultError("local reference key is too short")
            return decoded

        # Preserve 0.4/0.5 identifier semantics on first upgrade.
        raw_key = base64.urlsafe_b64decode(fernet_key)
        derived = hmac.new(raw_key, b"llm-account-inventory/reference-id/v1", hashlib.sha256).digest()
        encoded = base64.urlsafe_b64encode(derived)
        fd = os.open(ref_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            os.write(fd, encoded + b"\n")
        finally:
            os.close(fd)
        return derived

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    ref_id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    ciphertext BLOB NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    subject_id TEXT NOT NULL DEFAULT '',
                    encryption_scheme TEXT NOT NULL DEFAULT 'legacy-fernet-v1',
                    key_id TEXT NOT NULL DEFAULT 'legacy-v1'
                );
                CREATE INDEX IF NOT EXISTS idx_metadata_kind ON metadata(kind, ref_id);
                CREATE INDEX IF NOT EXISTS idx_metadata_subject ON metadata(subject_id, ref_id);

                CREATE TABLE IF NOT EXISTS metadata_subject_keys (
                    subject_id TEXT PRIMARY KEY,
                    wrapping_key_id TEXT NOT NULL,
                    wrapped_dek BLOB,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    shredded_at TEXT
                );
                """
            )
            self._ensure_column(conn, "metadata", "subject_id", "TEXT NOT NULL DEFAULT ''")
            self._ensure_column(conn, "metadata", "encryption_scheme", "TEXT NOT NULL DEFAULT 'legacy-fernet-v1'")
            self._ensure_column(conn, "metadata", "key_id", "TEXT NOT NULL DEFAULT 'legacy-v1'")

    @staticmethod
    def _ensure_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
        names = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in names:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")

    @staticmethod
    def _subject(subject_id: str | None) -> str:
        return str(subject_id or GLOBAL_SUBJECT).strip() or GLOBAL_SUBJECT

    def _subject_fernet(self, conn: sqlite3.Connection, subject_id: str, *, create: bool) -> Fernet | None:
        row = conn.execute(
            "SELECT wrapping_key_id, wrapped_dek, shredded_at FROM metadata_subject_keys WHERE subject_id=?",
            (subject_id,),
        ).fetchone()
        if row:
            if row["shredded_at"] or row["wrapped_dek"] is None:
                if create:
                    raise MetadataSubjectShreddedError(f"metadata subject has been crypto-shredded: {subject_id}")
                return None
            try:
                dek = self.keyring.fernet(str(row["wrapping_key_id"])).decrypt(bytes(row["wrapped_dek"]))
                return Fernet(dek)
            except (InvalidToken, KeyringError, ValueError) as exc:
                raise MetadataVaultError(f"subject DEK cannot be unwrapped: {subject_id}") from exc
        if not create:
            return None
        dek = Fernet.generate_key()
        wrapped = self.keyring.fernet().encrypt(dek)
        now = datetime.now(timezone.utc).isoformat()
        conn.execute(
            """
            INSERT INTO metadata_subject_keys(subject_id, wrapping_key_id, wrapped_dek, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (subject_id, self.keyring.active_key_id, wrapped, now, now),
        )
        return Fernet(dek)

    def pseudonym(self, kind: str, value: str, *, prefix: str | None = None) -> str:
        normalized = value.strip()
        digest = hmac.new(
            self._reference_key,
            (kind + "\x1f" + normalized).encode("utf-8", errors="replace"),
            hashlib.sha256,
        ).hexdigest()[:32]
        return f"{prefix or kind}_{digest}"

    def put(self, ref_id: str, kind: str, value: Any, *, subject_id: str | None = None) -> None:
        subject = self._subject(subject_id)
        payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                subject_fernet = self._subject_fernet(conn, subject, create=True)
                assert subject_fernet is not None
                ciphertext = subject_fernet.encrypt(payload)
                conn.execute(
                    """
                    INSERT INTO metadata(ref_id, kind, ciphertext, created_at, updated_at, subject_id, encryption_scheme, key_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(ref_id) DO UPDATE SET
                        kind=excluded.kind, ciphertext=excluded.ciphertext, updated_at=excluded.updated_at,
                        subject_id=excluded.subject_id, encryption_scheme=excluded.encryption_scheme, key_id=excluded.key_id
                    """,
                    (ref_id, kind, ciphertext, now, now, subject, SUBJECT_SCHEME, self.keyring.active_key_id),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def get(self, ref_id: str) -> Any | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT ciphertext, subject_id, encryption_scheme, key_id FROM metadata WHERE ref_id=?", (ref_id,)
            ).fetchone()
            if not row:
                return None
            try:
                if str(row["encryption_scheme"] or LEGACY_SCHEME) == SUBJECT_SCHEME:
                    subject_fernet = self._subject_fernet(conn, self._subject(row["subject_id"]), create=False)
                    if subject_fernet is None:
                        return None
                    raw = subject_fernet.decrypt(bytes(row["ciphertext"]))
                else:
                    raw = self.keyring.fernet(str(row["key_id"] or "legacy-v1")).decrypt(bytes(row["ciphertext"]))
            except (InvalidToken, KeyringError) as exc:
                raise MetadataVaultError(f"metadata cannot be decrypted for ref {ref_id}") from exc
        return json.loads(raw.decode("utf-8"))

    def put_text(self, kind: str, value: str, *, prefix: str | None = None, subject_id: str | None = None) -> str:
        ref_id = self.pseudonym(kind, value, prefix=prefix)
        self.put(ref_id, kind, {"value": value}, subject_id=subject_id)
        return ref_id

    def resolve_text(self, ref_id: str) -> str | None:
        value = self.get(ref_id)
        if isinstance(value, dict) and isinstance(value.get("value"), str):
            return value["value"]
        return None

    def credential_reference(
        self, store_id: str, record: dict[str, Any], *, subject_id: str | None = None
    ) -> tuple[str, str]:
        canonical = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        digest = hmac.new(
            self._reference_key,
            (store_id + "\x1f" + canonical).encode("utf-8", errors="replace"),
            hashlib.sha256,
        ).hexdigest()[:32]
        reference_id = f"cref_{digest}"
        reference_uri = f"credential-ref://{store_id}/{record.get('record_type') or 'record'}/{digest}"
        self.put(reference_id, "credential_reference", record, subject_id=subject_id)
        return reference_id, reference_uri

    def keyring_status(self) -> dict[str, Any]:
        status = self.keyring.status()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT wrapping_key_id, COUNT(*) AS n FROM metadata_subject_keys WHERE shredded_at IS NULL GROUP BY wrapping_key_id"
            ).fetchall()
            shredded = conn.execute(
                "SELECT COUNT(*) AS n FROM metadata_subject_keys WHERE shredded_at IS NOT NULL"
            ).fetchone()
        return {
            "active_key_id": status.active_key_id,
            "key_ids": list(status.key_ids),
            "source": status.source,
            "subject_keys_by_kek": {str(row["wrapping_key_id"]): int(row["n"]) for row in rows},
            "shredded_subjects": int(shredded["n"] if shredded else 0),
        }

    def rotate_to_key_id(self, key_id: str, *, persist_local_keyring: bool = False) -> dict[str, Any]:
        # Verify the requested KEK exists before taking the write lock.
        new_fernet = self.keyring.fernet(key_id)
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                subject_rows = conn.execute(
                    "SELECT subject_id, wrapping_key_id, wrapped_dek FROM metadata_subject_keys WHERE shredded_at IS NULL"
                ).fetchall()
                rewrapped = 0
                for row in subject_rows:
                    old = self.keyring.fernet(str(row["wrapping_key_id"]))
                    dek = old.decrypt(bytes(row["wrapped_dek"]))
                    conn.execute(
                        "UPDATE metadata_subject_keys SET wrapping_key_id=?, wrapped_dek=?, updated_at=? WHERE subject_id=?",
                        (key_id, new_fernet.encrypt(dek), datetime.now(timezone.utc).isoformat(), row["subject_id"]),
                    )
                    rewrapped += 1

                legacy_rows = conn.execute(
                    "SELECT ref_id, ciphertext, key_id FROM metadata WHERE encryption_scheme!=?", (SUBJECT_SCHEME,)
                ).fetchall()
                legacy_reencrypted = 0
                for row in legacy_rows:
                    raw = self.keyring.fernet(str(row["key_id"] or "legacy-v1")).decrypt(bytes(row["ciphertext"]))
                    conn.execute(
                        "UPDATE metadata SET ciphertext=?, key_id=?, updated_at=? WHERE ref_id=?",
                        (new_fernet.encrypt(raw), key_id, datetime.now(timezone.utc).isoformat(), row["ref_id"]),
                    )
                    legacy_reencrypted += 1
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        self.keyring.activate(key_id)
        if persist_local_keyring:
            self.keyring.persist()
        return {
            "ok": True,
            "active_key_id": key_id,
            "subject_keys_rewrapped": rewrapped,
            "legacy_records_reencrypted": legacy_reencrypted,
            "reference_ids_preserved": True,
        }

    def rotate_encryption_key(self, new_key: str | bytes, *, persist_local_key: bool = False) -> dict[str, Any]:
        key_id = "rotated-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        try:
            self.keyring.add(key_id, new_key)
        except KeyringError as exc:
            raise MetadataVaultError(str(exc)) from exc
        result = self.rotate_to_key_id(key_id, persist_local_keyring=persist_local_key)
        result["records_reencrypted"] = result["legacy_records_reencrypted"]
        return result

    def crypto_shred_subject(self, subject_id: str) -> dict[str, Any]:
        subject = self._subject(subject_id)
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT wrapped_dek, shredded_at FROM metadata_subject_keys WHERE subject_id=?", (subject,)
                ).fetchone()
                affected = conn.execute("SELECT COUNT(*) AS n FROM metadata WHERE subject_id=?", (subject,)).fetchone()
                if row is None:
                    conn.execute(
                        "INSERT INTO metadata_subject_keys(subject_id, wrapping_key_id, wrapped_dek, created_at, updated_at, shredded_at) VALUES (?, ?, NULL, ?, ?, ?)",
                        (subject, self.keyring.active_key_id, now, now, now),
                    )
                    already = False
                else:
                    already = bool(row["shredded_at"])
                    conn.execute(
                        "UPDATE metadata_subject_keys SET wrapped_dek=NULL, shredded_at=COALESCE(shredded_at, ?), updated_at=? WHERE subject_id=?",
                        (now, now, subject),
                    )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        return {
            "ok": True,
            "subject_id": subject,
            "already_shredded": already,
            "ciphertext_records_unrecoverable": int(affected["n"] if affected else 0),
            "event_log_modified": False,
        }
