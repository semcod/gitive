from __future__ import annotations

import json
import os
import re
import uuid
from dataclasses import dataclass
from typing import Mapping


_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:@/-]{0,191}$")


class TrustedContextError(ValueError):
    pass


@dataclass(frozen=True)
class TrustedExecutionContext:
    actor_id: str
    principal_id: str
    organization_id: str
    subject_user_id: str
    device_id: str
    profile_id: str
    installation_id: str
    allowed_uri_processes: tuple[str, ...]
    trace_id: str
    correlation_id: str
    causation_id: str
    command_id: str
    idempotency_key: str
    expected_version: int = 0

    @classmethod
    def from_headers(cls, headers: Mapping[str, str], *, command_route: bool) -> "TrustedExecutionContext":
        allowed_raw = str(headers.get("X-Subactor-Allowed-Uri-Processes") or "").strip()
        if not allowed_raw:
            raise TrustedContextError("missing X-Subactor-Allowed-Uri-Processes")
        try:
            parsed = json.loads(allowed_raw)
            if isinstance(parsed, str):
                allowed = (parsed,)
            elif isinstance(parsed, list) and all(isinstance(x, str) for x in parsed):
                allowed = tuple(parsed)
            else:
                raise ValueError
        except Exception:
            allowed = tuple(x.strip() for x in allowed_raw.split(",") if x.strip())
        if not allowed:
            raise TrustedContextError("trusted URI scope is empty")

        actor_id = _required_id(headers, "X-Subactor-Actor-Id")
        principal_id = _optional_id(headers, "X-Subactor-Principal-Id", actor_id)
        organization_id = _required_id(headers, "X-Subactor-Organization-Id")
        subject_user_id = _optional_id(headers, "X-Subactor-Subject-User-Id", actor_id)
        device_id = _required_id(headers, "X-Subactor-Device-Id")
        profile_id = _optional_id(headers, "X-Subactor-Profile-Id", "default")
        installation_id = _optional_id(
            headers,
            "X-Subactor-Installation-Id",
            os.environ.get("ACCOUNT_INVENTORY_INSTALLATION_ID", "installation:default"),
        )
        trace_id = _optional_id(headers, "X-Subactor-Trace-Id", f"trace_{uuid.uuid4().hex}")
        command_id = _optional_id(headers, "X-Subactor-Command-Id", f"cmd_{uuid.uuid4().hex}")
        correlation_id = _optional_id(headers, "X-Subactor-Correlation-Id", command_id)
        causation_id = _optional_id(headers, "X-Subactor-Causation-Id", "root")
        idem = str(headers.get("X-Subactor-Idempotency-Key") or "").strip()
        if command_route and not idem:
            raise TrustedContextError("missing X-Subactor-Idempotency-Key for command route")
        if not idem:
            idem = f"query:{trace_id}"
        expected_raw = str(headers.get("X-Subactor-Expected-Version") or "0").strip()
        try:
            expected = int(expected_raw)
        except ValueError as exc:
            raise TrustedContextError("X-Subactor-Expected-Version must be an integer") from exc
        if expected < 0:
            raise TrustedContextError("X-Subactor-Expected-Version must be >= 0")
        return cls(
            actor_id=actor_id,
            principal_id=principal_id,
            organization_id=organization_id,
            subject_user_id=subject_user_id,
            device_id=device_id,
            profile_id=profile_id,
            installation_id=installation_id,
            allowed_uri_processes=allowed,
            trace_id=trace_id,
            correlation_id=correlation_id,
            causation_id=causation_id,
            command_id=command_id,
            idempotency_key=idem,
            expected_version=expected,
        )


def _required_id(headers: Mapping[str, str], name: str) -> str:
    value = str(headers.get(name) or "").strip()
    if not value:
        raise TrustedContextError(f"missing {name}")
    return _validate_id(name, value)


def _optional_id(headers: Mapping[str, str], name: str, default: str) -> str:
    return _validate_id(name, str(headers.get(name) or default).strip())


def _validate_id(name: str, value: str) -> str:
    if not value or not _ID.fullmatch(value):
        raise TrustedContextError(f"invalid {name}")
    return value
