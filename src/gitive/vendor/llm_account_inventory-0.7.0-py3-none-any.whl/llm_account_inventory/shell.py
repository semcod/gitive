from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from .dsl import DslError, help_text
from .dsl_runtime import DslExecutor, DslSessionConfig

try:
    import readline  # type: ignore
except Exception:  # pragma: no cover - platform dependent
    readline = None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="llm-accounts-shell", description="Interactive CQRS/ES DSL shell.")
    parser.add_argument("--data-dir", type=Path, default=Path(".inventory-data"))
    parser.add_argument("--operator", action="store_true", help="enable command/governance URI routes")
    parser.add_argument("--actor-id", default="human:founder")
    parser.add_argument("--principal-id", default="human:founder")
    parser.add_argument("--organization-id", default="organization:local")
    parser.add_argument("--subject-user-id", default="human:founder")
    parser.add_argument("--device-id", default="device:local")
    parser.add_argument("--profile-id", default="default")
    parser.add_argument("--installation-id", default="installation:local")
    parser.add_argument("--allowed-home", action="append", type=Path, default=[])
    parser.add_argument("--credential-metadata", action="store_true")
    parser.add_argument("--manager-network", action="store_true")
    parser.add_argument("--execute", help="execute one DSL statement and exit")
    return parser


def executor_from_args(args) -> DslExecutor:
    return DslExecutor(DslSessionConfig(
        data_dir=args.data_dir,
        actor_id=args.actor_id,
        principal_id=args.principal_id,
        organization_id=args.organization_id,
        subject_user_id=args.subject_user_id,
        device_id=args.device_id,
        profile_id=args.profile_id,
        installation_id=args.installation_id,
        operator=bool(args.operator),
        allowed_homes=tuple(args.allowed_home),
        credential_metadata_enabled=bool(args.credential_metadata),
        manager_network_enabled=bool(args.manager_network),
    ))


def main() -> int:
    args = build_parser().parse_args()
    executor = executor_from_args(args)
    if args.execute:
        try:
            print(render(executor.execute(args.execute)))
            return 0
        except Exception as exc:
            print(f"ERROR: {exc}")
            return 2

    history_path = Path(os.environ.get("ACCOUNT_INVENTORY_SHELL_HISTORY", "~/.llm-account-inventory_history")).expanduser()
    _history_load(history_path)
    print("Inventory CQRS/ES Shell 0.7")
    print(f"backend data: {args.data_dir} | organization: {args.organization_id} | device: {args.device_id}")
    print(f"mode: {'operator' if args.operator else 'viewer'} | HELP for syntax | .exit to quit")
    try:
        while True:
            try:
                line = input("inventory> ").strip()
            except EOFError:
                print()
                break
            except KeyboardInterrupt:
                print("^C")
                continue
            if not line:
                continue
            if line in {".exit", ".quit", "quit", "exit"}:
                break
            if line == ".context":
                print(json.dumps(_context_dict(args), indent=2, ensure_ascii=False))
                continue
            if line.startswith(".ast "):
                try:
                    print(json.dumps(executor.inspect(line[5:]).get("ast"), indent=2, ensure_ascii=False))
                except Exception as exc:
                    print(f"ERROR: {exc}")
                continue
            if line.startswith(".compile "):
                try:
                    print(json.dumps(executor.inspect(line[9:]).get("compiled"), indent=2, ensure_ascii=False))
                except Exception as exc:
                    print(f"ERROR: {exc}")
                continue
            if line.upper() in {"HELP", "?"}:
                print(help_text())
                continue
            try:
                print(render(executor.execute(line)))
            except DslError as exc:
                print(f"DSL ERROR: {exc}")
            except Exception as exc:
                print(f"ERROR: {type(exc).__name__}: {exc}")
    finally:
        _history_save(history_path)
    return 0


def render(payload: dict[str, Any]) -> str:
    if payload.get("type") == "help":
        return str(payload.get("text") or "")
    result = payload.get("result")
    if isinstance(result, dict) and isinstance(result.get("items"), list):
        items = result["items"]
        if not items:
            return "(0 rows)"
        return _table(items)
    return json.dumps(result if result is not None else payload, indent=2, ensure_ascii=False, default=str)


def _table(items: list[dict[str, Any]]) -> str:
    priority = [
        "provider_name", "provider_id", "identity_id", "value", "name", "store_id", "reference_uri",
        "scan_id", "status", "event_type", "global_position", "active", "last_seen_at", "device_id", "profile_id",
    ]
    keys: list[str] = []
    all_keys = {k for row in items[:50] for k in row}
    for key in priority:
        if key in all_keys and key not in keys:
            keys.append(key)
    for key in sorted(all_keys):
        if key not in keys and len(keys) < 8:
            keys.append(key)
    widths = {k: min(44, max(len(k), *(len(_cell(row.get(k))) for row in items[:50]))) for k in keys}
    header = " | ".join(k.ljust(widths[k]) for k in keys)
    sep = "-+-".join("-" * widths[k] for k in keys)
    rows = [" | ".join(_cell(row.get(k))[:widths[k]].ljust(widths[k]) for k in keys) for row in items]
    return "\n".join([header, sep, *rows, f"({len(items)} rows)"])


def _cell(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if value is None:
        return ""
    return str(value).replace("\n", " ")


def _context_dict(args) -> dict[str, Any]:
    return {
        "actor_id": args.actor_id,
        "principal_id": args.principal_id,
        "organization_id": args.organization_id,
        "subject_user_id": args.subject_user_id,
        "device_id": args.device_id,
        "profile_id": args.profile_id,
        "installation_id": args.installation_id,
        "mode": "operator" if args.operator else "viewer",
        "allowed_homes": [str(x) for x in args.allowed_home],
        "credential_metadata": bool(args.credential_metadata),
        "manager_network": bool(args.manager_network),
    }


def _history_load(path: Path) -> None:
    if readline is None:
        return
    try:
        readline.read_history_file(str(path))
    except FileNotFoundError:
        pass
    readline.set_history_length(1000)


def _history_save(path: Path) -> None:
    if readline is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        readline.write_history_file(str(path))
    except OSError:
        pass


if __name__ == "__main__":
    raise SystemExit(main())
