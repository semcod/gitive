from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class Evidence:
    source: str
    kind: str
    detail: str
    line: int | None = None


@dataclass(frozen=True)
class CredentialRecord:
    """Non-secret metadata about one credential entry.

    The model intentionally has no password/token/secret field.
    """

    record_type: str
    title: str
    username: str | None = None
    urls: tuple[str, ...] = ()
    source: str | None = None
    external_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CredentialStoreFinding:
    store_id: str
    name: str
    kind: str
    deployment: str
    cloud_capable: bool = False
    detected_paths: set[str] = field(default_factory=set)
    profiles: set[str] = field(default_factory=set)
    account_emails: set[str] = field(default_factory=set)
    cli: str | None = None
    cli_available: bool = False
    access_capability: str = "detect_only"
    access_attempted: bool = False
    access_ok: bool | None = None
    records: list[CredentialRecord] = field(default_factory=list)
    evidence: list[Evidence] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def merge_record(self, record: CredentialRecord) -> None:
        key = (record.record_type, record.title, record.username, record.urls, record.source, record.external_id)
        existing = {
            (r.record_type, r.title, r.username, r.urls, r.source, r.external_id)
            for r in self.records
        }
        if key not in existing:
            self.records.append(record)

    def to_dict(self) -> dict[str, Any]:
        return {
            "store_id": self.store_id,
            "name": self.name,
            "kind": self.kind,
            "deployment": self.deployment,
            "cloud_capable": self.cloud_capable,
            "detected_paths": sorted(self.detected_paths),
            "profiles": sorted(self.profiles),
            "account_emails": sorted(self.account_emails),
            "cli": self.cli,
            "cli_available": self.cli_available,
            "access_capability": self.access_capability,
            "access_attempted": self.access_attempted,
            "access_ok": self.access_ok,
            "records": [r.to_dict() for r in self.records],
            "evidence": [asdict(e) for e in self.evidence],
            "warnings": list(self.warnings),
        }


@dataclass
class AccountFinding:
    provider_id: str
    provider_name: str
    category: str
    emails: set[str] = field(default_factory=set)
    identifiers: set[str] = field(default_factory=set)
    clients: set[str] = field(default_factory=set)
    secret_names: set[str] = field(default_factory=set)
    evidence: list[Evidence] = field(default_factory=list)
    confidence: str = "medium"

    def merge(self, other: "AccountFinding") -> None:
        self.emails.update(other.emails)
        self.identifiers.update(other.identifiers)
        self.clients.update(other.clients)
        self.secret_names.update(other.secret_names)
        seen = {(e.source, e.kind, e.detail, e.line) for e in self.evidence}
        for item in other.evidence:
            key = (item.source, item.kind, item.detail, item.line)
            if key not in seen:
                self.evidence.append(item)
                seen.add(key)
        order = {"low": 0, "medium": 1, "high": 2}
        if order.get(other.confidence, 1) > order.get(self.confidence, 1):
            self.confidence = other.confidence

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["emails"] = sorted(self.emails)
        data["identifiers"] = sorted(self.identifiers)
        data["clients"] = sorted(self.clients)
        data["secret_names"] = sorted(self.secret_names)
        return data


@dataclass
class InventoryReport:
    schema_version: str
    generated_at: str
    platform: str
    home: str
    files_considered: int
    files_scanned: int
    files_skipped: int
    findings: list[AccountFinding]
    credential_stores: list[CredentialStoreFinding] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "generated_at": self.generated_at,
            "platform": self.platform,
            "home": self.home,
            "files_considered": self.files_considered,
            "files_scanned": self.files_scanned,
            "files_skipped": self.files_skipped,
            "warnings": list(self.warnings),
            "findings": [finding.to_dict() for finding in self.findings],
            "credential_stores": [store.to_dict() for store in self.credential_stores],
        }
