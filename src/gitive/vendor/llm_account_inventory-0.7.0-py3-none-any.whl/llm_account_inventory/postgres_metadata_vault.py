from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from datetime import datetime, timezone
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

from .keyring import KeyringError, MetadataKeyring
from .metadata_vault import (
    GLOBAL_SUBJECT,
    LEGACY_SCHEME,
    SUBJECT_SCHEME,
    MetadataSubjectShreddedError,
    MetadataVaultError,
)
from .postgres import connect, database_url


class PostgresMetadataVault:
    """Shared envelope-encrypted PII store for multi-host deployments."""

    def __init__(self, dsn: str | None = None):
        self.dsn = database_url(dsn)
        try:
            self.keyring = MetadataKeyring.load(None, require_external=True, require_present=True)
        except KeyringError as exc:
            raise MetadataVaultError(str(exc)) from exc
        ref_key = os.environ.get("ACCOUNT_INVENTORY_REFERENCE_KEY", "").strip()
        if not ref_key:
            raise MetadataVaultError("ACCOUNT_INVENTORY_REFERENCE_KEY is required for postgres backend")
        try:
            self._reference_key = base64.urlsafe_b64decode(ref_key.encode("ascii"))
        except Exception as exc:
            raise MetadataVaultError("ACCOUNT_INVENTORY_REFERENCE_KEY must be urlsafe-base64") from exc
        if len(self._reference_key) < 32:
            raise MetadataVaultError("ACCOUNT_INVENTORY_REFERENCE_KEY must decode to at least 32 bytes")
        self._init_db()

    def _connect(self, *, autocommit: bool = True):
        return connect(self.dsn, autocommit=autocommit)

    def _init_db(self) -> None:
        ddl = """
        CREATE TABLE IF NOT EXISTS metadata_vault (
            ref_id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            ciphertext BYTEA NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            subject_id TEXT NOT NULL DEFAULT '',
            encryption_scheme TEXT NOT NULL DEFAULT 'legacy-fernet-v1',
            key_id TEXT NOT NULL DEFAULT 'legacy-v1'
        );
        CREATE INDEX IF NOT EXISTS idx_metadata_vault_kind ON metadata_vault(kind, ref_id);
        CREATE INDEX IF NOT EXISTS idx_metadata_vault_subject ON metadata_vault(subject_id, ref_id);
        ALTER TABLE metadata_vault ADD COLUMN IF NOT EXISTS subject_id TEXT NOT NULL DEFAULT '';
        ALTER TABLE metadata_vault ADD COLUMN IF NOT EXISTS encryption_scheme TEXT NOT NULL DEFAULT 'legacy-fernet-v1';
        ALTER TABLE metadata_vault ADD COLUMN IF NOT EXISTS key_id TEXT NOT NULL DEFAULT 'legacy-v1';

        CREATE TABLE IF NOT EXISTS metadata_subject_keys (
            subject_id TEXT PRIMARY KEY,
            wrapping_key_id TEXT NOT NULL,
            wrapped_dek BYTEA,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            shredded_at TIMESTAMPTZ
        );
        """
        with self._connect() as conn:
            for statement in (part.strip() for part in ddl.split(";")):
                if statement:
                    conn.execute(statement)

    @staticmethod
    def _subject(subject_id: str | None) -> str:
        return str(subject_id or GLOBAL_SUBJECT).strip() or GLOBAL_SUBJECT

    def _subject_fernet(self, conn, subject_id: str, *, create: bool) -> Fernet | None:
        row = conn.execute(
            "SELECT wrapping_key_id, wrapped_dek, shredded_at FROM metadata_subject_keys WHERE subject_id=%s FOR UPDATE",
            (subject_id,),
        ).fetchone()
        if row:
            if row["shredded_at"] is not None or row["wrapped_dek"] is None:
                if create:
                    raise MetadataSubjectShreddedError(f"metadata subject has been crypto-shredded: {subject_id}")
                return None
            try:
                dek = self.keyring.fernet(str(row["wrapping_key_id"])).decrypt(bytes(row["wrapped_dek"]))
                return Fernet(dek)
            except (InvalidToken, KeyringError, ValueError) as exc:
                raise MetadataVaultError(f"subject DEK cannot be unwrapped: {subject_id}") from exc
        if not create:
            return None
        dek = Fernet.generate_key()
        wrapped = self.keyring.fernet().encrypt(dek)
        inserted = conn.execute(
            """
            INSERT INTO metadata_subject_keys(subject_id, wrapping_key_id, wrapped_dek)
            VALUES (%s, %s, %s)
            ON CONFLICT(subject_id) DO NOTHING
            RETURNING subject_id
            """,
            (subject_id, self.keyring.active_key_id, wrapped),
        ).fetchone()
        if inserted is None:
            return self._subject_fernet(conn, subject_id, create=create)
        return Fernet(dek)

    def pseudonym(self, kind: str, value: str, *, prefix: str | None = None) -> str:
        normalized = value.strip()
        digest = hmac.new(
            self._reference_key,
            (kind + "\x1f" + normalized).encode("utf-8", errors="replace"),
            hashlib.sha256,
        ).hexdigest()[:32]
        return f"{prefix or kind}_{digest}"

    def put(self, ref_id: str, kind: str, value: Any, *, subject_id: str | None = None) -> None:
        subject = self._subject(subject_id)
        payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        with self._connect(autocommit=False) as conn:
            try:
                subject_fernet = self._subject_fernet(conn, subject, create=True)
                assert subject_fernet is not None
                ciphertext = subject_fernet.encrypt(payload)
                conn.execute(
                    """
                    INSERT INTO metadata_vault(ref_id, kind, ciphertext, subject_id, encryption_scheme, key_id)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT(ref_id) DO UPDATE SET
                        kind=EXCLUDED.kind, ciphertext=EXCLUDED.ciphertext, updated_at=now(),
                        subject_id=EXCLUDED.subject_id, encryption_scheme=EXCLUDED.encryption_scheme, key_id=EXCLUDED.key_id
                    """,
                    (ref_id, kind, ciphertext, subject, SUBJECT_SCHEME, self.keyring.active_key_id),
                )
                conn.commit()
            except Exception:
                conn.rollback()
                raise

    def get(self, ref_id: str) -> Any | None:
        with self._connect(autocommit=False) as conn:
            try:
                row = conn.execute(
                    "SELECT ciphertext, subject_id, encryption_scheme, key_id FROM metadata_vault WHERE ref_id=%s",
                    (ref_id,),
                ).fetchone()
                if not row:
                    conn.commit()
                    return None
                if str(row["encryption_scheme"] or LEGACY_SCHEME) == SUBJECT_SCHEME:
                    subject_fernet = self._subject_fernet(conn, self._subject(row["subject_id"]), create=False)
                    if subject_fernet is None:
                        conn.commit()
                        return None
                    raw = subject_fernet.decrypt(bytes(row["ciphertext"]))
                else:
                    raw = self.keyring.fernet(str(row["key_id"] or "legacy-v1")).decrypt(bytes(row["ciphertext"]))
                conn.commit()
            except (InvalidToken, KeyringError) as exc:
                conn.rollback()
                raise MetadataVaultError(f"metadata cannot be decrypted for ref {ref_id}") from exc
            except Exception:
                conn.rollback()
                raise
        return json.loads(raw.decode("utf-8"))

    def put_text(self, kind: str, value: str, *, prefix: str | None = None, subject_id: str | None = None) -> str:
        ref_id = self.pseudonym(kind, value, prefix=prefix)
        self.put(ref_id, kind, {"value": value}, subject_id=subject_id)
        return ref_id

    def resolve_text(self, ref_id: str) -> str | None:
        value = self.get(ref_id)
        if isinstance(value, dict) and isinstance(value.get("value"), str):
            return value["value"]
        return None

    def credential_reference(
        self, store_id: str, record: dict[str, Any], *, subject_id: str | None = None
    ) -> tuple[str, str]:
        canonical = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        digest = hmac.new(
            self._reference_key,
            (store_id + "\x1f" + canonical).encode("utf-8", errors="replace"),
            hashlib.sha256,
        ).hexdigest()[:32]
        reference_id = f"cref_{digest}"
        reference_uri = f"credential-ref://{store_id}/{record.get('record_type') or 'record'}/{digest}"
        self.put(reference_id, "credential_reference", record, subject_id=subject_id)
        return reference_id, reference_uri

    def keyring_status(self) -> dict[str, Any]:
        status = self.keyring.status()
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT wrapping_key_id, COUNT(*) AS n FROM metadata_subject_keys WHERE shredded_at IS NULL GROUP BY wrapping_key_id"
            ).fetchall()
            shredded = conn.execute(
                "SELECT COUNT(*) AS n FROM metadata_subject_keys WHERE shredded_at IS NOT NULL"
            ).fetchone()
        return {
            "active_key_id": status.active_key_id,
            "key_ids": list(status.key_ids),
            "source": status.source,
            "subject_keys_by_kek": {str(row["wrapping_key_id"]): int(row["n"]) for row in rows},
            "shredded_subjects": int(shredded["n"] if shredded else 0),
        }

    def rotate_to_key_id(self, key_id: str, *, persist_local_keyring: bool = False) -> dict[str, Any]:
        del persist_local_keyring
        new_fernet = self.keyring.fernet(key_id)
        with self._connect(autocommit=False) as conn:
            try:
                subject_rows = conn.execute(
                    "SELECT subject_id, wrapping_key_id, wrapped_dek FROM metadata_subject_keys WHERE shredded_at IS NULL FOR UPDATE"
                ).fetchall()
                rewrapped = 0
                for row in subject_rows:
                    dek = self.keyring.fernet(str(row["wrapping_key_id"])).decrypt(bytes(row["wrapped_dek"]))
                    conn.execute(
                        "UPDATE metadata_subject_keys SET wrapping_key_id=%s, wrapped_dek=%s, updated_at=now() WHERE subject_id=%s",
                        (key_id, new_fernet.encrypt(dek), row["subject_id"]),
                    )
                    rewrapped += 1
                legacy_rows = conn.execute(
                    "SELECT ref_id, ciphertext, key_id FROM metadata_vault WHERE encryption_scheme<>%s FOR UPDATE",
                    (SUBJECT_SCHEME,),
                ).fetchall()
                legacy_reencrypted = 0
                for row in legacy_rows:
                    raw = self.keyring.fernet(str(row["key_id"] or "legacy-v1")).decrypt(bytes(row["ciphertext"]))
                    conn.execute(
                        "UPDATE metadata_vault SET ciphertext=%s, key_id=%s, updated_at=now() WHERE ref_id=%s",
                        (new_fernet.encrypt(raw), key_id, row["ref_id"]),
                    )
                    legacy_reencrypted += 1
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        self.keyring.activate(key_id)
        return {
            "ok": True,
            "active_key_id": key_id,
            "subject_keys_rewrapped": rewrapped,
            "legacy_records_reencrypted": legacy_reencrypted,
            "reference_ids_preserved": True,
        }

    def rotate_encryption_key(self, new_key: str | bytes) -> dict[str, Any]:
        key_id = "rotated-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        try:
            self.keyring.add(key_id, new_key)
        except KeyringError as exc:
            raise MetadataVaultError(str(exc)) from exc
        result = self.rotate_to_key_id(key_id)
        result["records_reencrypted"] = result["legacy_records_reencrypted"]
        return result

    def crypto_shred_subject(self, subject_id: str) -> dict[str, Any]:
        subject = self._subject(subject_id)
        with self._connect(autocommit=False) as conn:
            try:
                row = conn.execute(
                    "SELECT shredded_at FROM metadata_subject_keys WHERE subject_id=%s FOR UPDATE", (subject,)
                ).fetchone()
                affected = conn.execute(
                    "SELECT COUNT(*) AS n FROM metadata_vault WHERE subject_id=%s", (subject,)
                ).fetchone()
                if row is None:
                    conn.execute(
                        "INSERT INTO metadata_subject_keys(subject_id, wrapping_key_id, wrapped_dek, shredded_at) VALUES (%s, %s, NULL, now())",
                        (subject, self.keyring.active_key_id),
                    )
                    already = False
                else:
                    already = row["shredded_at"] is not None
                    conn.execute(
                        "UPDATE metadata_subject_keys SET wrapped_dek=NULL, shredded_at=COALESCE(shredded_at, now()), updated_at=now() WHERE subject_id=%s",
                        (subject,),
                    )
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        return {
            "ok": True,
            "subject_id": subject,
            "already_shredded": already,
            "ciphertext_records_unrecoverable": int(affected["n"] if affected else 0),
            "event_log_modified": False,
        }
