from __future__ import annotations

import os
import re
from contextlib import contextmanager
from typing import Any, Iterator


class PostgresUnavailable(RuntimeError):
    pass


class PostgresConfigurationError(RuntimeError):
    pass


def database_url(explicit: str | None = None) -> str:
    value = (explicit or os.environ.get("ACCOUNT_INVENTORY_DATABASE_URL") or "").strip()
    if not value:
        raise PostgresConfigurationError("ACCOUNT_INVENTORY_DATABASE_URL is required for postgres backend")
    return value


def import_psycopg():
    try:
        import psycopg  # type: ignore
        from psycopg.rows import dict_row  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on optional installation
        raise PostgresUnavailable(
            "postgres backend requires optional dependency: pip install 'llm-account-inventory[postgres]'"
        ) from exc
    return psycopg, dict_row


def connect(dsn: str, *, autocommit: bool = True):
    psycopg, dict_row = import_psycopg()
    return psycopg.connect(dsn, autocommit=autocommit, row_factory=dict_row)


def qmark_to_pyformat(sql: str) -> str:
    # Project SQL never uses '?' inside string literals. Keep conversion deliberately
    # narrow so accidental dialect drift is visible in tests.
    return sql.replace("?", "%s")


_INSERT_IGNORE = re.compile(r"^\s*INSERT\s+OR\s+IGNORE\s+INTO\s+", re.I | re.S)
_INSERT_REPLACE = re.compile(r"^\s*INSERT\s+OR\s+REPLACE\s+INTO\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*VALUES\s*\((.*?)\)\s*$", re.I | re.S)


class PgCompatConnection:
    """Tiny compatibility adapter for the projection SQL shared with SQLite.

    It translates qmark placeholders plus the few SQLite INSERT OR forms used by
    the rebuildable read model. It is intentionally not a general SQL translator.
    """

    REPLACE_KEYS = {
        "projection_meta": ("key",),
        "evidence": ("event_id", "ordinal"),
    }

    def __init__(self, raw):
        self.raw = raw

    def execute(self, sql: str, params: tuple[Any, ...] | list[Any] = ()):
        normalized = sql.strip()
        upper = normalized.upper()
        if upper == "BEGIN IMMEDIATE":
            return self.raw.execute("BEGIN")
        if upper in {"COMMIT", "ROLLBACK"}:
            return self.raw.execute(upper)
        if _INSERT_IGNORE.match(sql):
            sql = _INSERT_IGNORE.sub("INSERT INTO ", sql).rstrip().rstrip(";") + " ON CONFLICT DO NOTHING"
        else:
            match = _INSERT_REPLACE.match(sql)
            if match:
                table = match.group(1)
                columns = [c.strip() for c in match.group(2).split(",")]
                values = match.group(3)
                keys = self.REPLACE_KEYS.get(table)
                if not keys:
                    raise RuntimeError(f"unsupported INSERT OR REPLACE table for postgres compatibility: {table}")
                updates = [c for c in columns if c not in keys]
                assignments = ", ".join(f"{c}=EXCLUDED.{c}" for c in updates)
                sql = (
                    f"INSERT INTO {table}({', '.join(columns)}) VALUES ({values}) "
                    f"ON CONFLICT({', '.join(keys)}) DO UPDATE SET {assignments}"
                )
        return self.raw.execute(qmark_to_pyformat(sql), params)

    def executescript(self, sql: str):
        result = None
        for statement in (part.strip() for part in sql.split(";")):
            if statement:
                result = self.raw.execute(statement)
        return result

    def close(self) -> None:
        self.raw.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False


@contextmanager
def compatible_connection(dsn: str) -> Iterator[PgCompatConnection]:
    raw = connect(dsn, autocommit=True)
    wrapper = PgCompatConnection(raw)
    try:
        yield wrapper
    finally:
        raw.close()
