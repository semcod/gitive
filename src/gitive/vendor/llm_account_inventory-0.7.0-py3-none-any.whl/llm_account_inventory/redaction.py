from __future__ import annotations

import re

EMAIL_RE = re.compile(r"(?<![\w.+-])([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})(?![\w.-])", re.IGNORECASE)

SECRET_NAME_RE = re.compile(
    r"(?:^|[^A-Z0-9_])([A-Z][A-Z0-9_]*(?:API_KEY|TOKEN|SECRET|PASSWORD|PRIVATE_KEY|ACCESS_KEY)[A-Z0-9_]*)",
    re.IGNORECASE,
)

# Values are intentionally never returned. The scanner only records the key name.
ASSIGNMENT_RE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_.-]*)\s*[:=]\s*(.*?)\s*$")


def emails(text: str) -> set[str]:
    return {match.group(1).lower() for match in EMAIL_RE.finditer(text)}


def secret_names(text: str) -> set[str]:
    names: set[str] = set()
    for line in text.splitlines():
        # Structured formats such as JSON may quote key names; collect the key
        # identifier only and never retain the associated value.
        for found in SECRET_NAME_RE.findall(line):
            names.add(found)
        match = ASSIGNMENT_RE.match(line)
        if not match:
            continue
        key = match.group(1)
        if SECRET_NAME_RE.search(key) or re.search(r"(?i)(api[_-]?key|token|secret|password|private[_-]?key)", key):
            names.add(key)
    return names


def safe_assignment(line: str) -> tuple[str, str] | None:
    match = ASSIGNMENT_RE.match(line)
    if not match:
        return None
    key, value = match.group(1), match.group(2).strip().strip('"\'')
    if re.search(r"(?i)(api[_-]?key|token|secret|password|private[_-]?key|access[_-]?key)", key):
        return key, "<redacted>"
    return key, value
