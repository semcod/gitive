from __future__ import annotations

import contextlib
import json
import os
import platform as platform_module
import shutil
import sqlite3
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from urllib.parse import urlparse

from .model import CredentialRecord, CredentialStoreFinding, Evidence
from .redaction import emails


@dataclass(frozen=True)
class ManagerSpec:
    id: str
    name: str
    deployment: str
    cloud_capable: bool
    cli: str | None
    paths: dict[str, tuple[str, ...]]
    markers: tuple[str, ...]
    access_capability: str


MANAGERS: tuple[ManagerSpec, ...] = (
    ManagerSpec(
        "1password", "1Password", "hybrid", True, "op",
        {
            "linux": (".config/1Password", ".config/op"),
            "darwin": ("Library/Application Support/1Password", "Library/Group Containers/2BUA8C4S2C.com.1password", ".config/op"),
            "windows": ("AppData/Local/1Password", "AppData/Roaming/1Password", ".config/op"),
        },
        ("1password", "onepassword"), "cli_metadata",
    ),
    ManagerSpec(
        "bitwarden", "Bitwarden", "hybrid", True, "bw",
        {
            "linux": (".config/Bitwarden", ".config/Bitwarden CLI"),
            "darwin": ("Library/Application Support/Bitwarden", ".config/Bitwarden CLI"),
            "windows": ("AppData/Roaming/Bitwarden", "AppData/Local/Bitwarden"),
        },
        ("bitwarden",), "account_metadata",
    ),
    ManagerSpec(
        "keepassxc", "KeePassXC / KeePass", "local", False, "keepassxc-cli",
        {
            "linux": (".config/keepassxc",),
            "darwin": ("Library/Application Support/KeePassXC",),
            "windows": ("AppData/Local/KeePassXC", "AppData/Roaming/KeePassXC"),
        },
        ("keepassxc", "keepass"), "interactive_unlock_required",
    ),
    ManagerSpec(
        "pass", "pass (password-store)", "local", False, "pass",
        {"linux": (".password-store",), "darwin": (".password-store",), "windows": ()},
        ("password-store",), "cli_metadata",
    ),
    ManagerSpec(
        "gopass", "gopass", "local", False, "gopass",
        {
            "linux": (".config/gopass", ".local/share/gopass"),
            "darwin": (".config/gopass", ".local/share/gopass"),
            "windows": ("AppData/Roaming/gopass",),
        },
        ("gopass",), "cli_metadata",
    ),
    ManagerSpec(
        "proton_pass", "Proton Pass", "cloud", True, None,
        {
            "linux": (".config/Proton Pass", ".config/proton-pass"),
            "darwin": ("Library/Application Support/Proton Pass",),
            "windows": ("AppData/Roaming/Proton Pass", "AppData/Local/Proton Pass"),
        },
        ("proton pass", "protonpass"), "detect_only",
    ),
    ManagerSpec(
        "dashlane", "Dashlane", "cloud", True, None,
        {
            "linux": (".config/Dashlane",),
            "darwin": ("Library/Application Support/Dashlane",),
            "windows": ("AppData/Local/Dashlane", "AppData/Roaming/Dashlane"),
        },
        ("dashlane",), "detect_only",
    ),
    ManagerSpec(
        "lastpass", "LastPass", "cloud", True, None,
        {
            "linux": (".config/LastPass",),
            "darwin": ("Library/Application Support/LastPass",),
            "windows": ("AppData/Local/LastPass", "AppData/Roaming/LastPass"),
        },
        ("lastpass", "last pass"), "detect_only",
    ),
    ManagerSpec(
        "nordpass", "NordPass", "cloud", True, None,
        {
            "linux": (".config/NordPass",),
            "darwin": ("Library/Application Support/NordPass",),
            "windows": ("AppData/Roaming/NordPass", "AppData/Local/NordPass"),
        },
        ("nordpass", "nord pass"), "detect_only",
    ),
    ManagerSpec(
        "keeper", "Keeper", "cloud", True, None,
        {
            "linux": (".config/Keeper",),
            "darwin": ("Library/Application Support/Keeper",),
            "windows": ("AppData/Local/Keeper", "AppData/Roaming/Keeper"),
        },
        ("keeper password", "keeper security"), "detect_only",
    ),
    ManagerSpec(
        "enpass", "Enpass", "hybrid", True, None,
        {
            "linux": (".config/sinew.in", ".config/Enpass"),
            "darwin": ("Library/Application Support/Enpass",),
            "windows": ("AppData/Local/Sinew Software Systems", "AppData/Roaming/Enpass"),
        },
        ("enpass",), "detect_only",
    ),
)


BROWSERS = {
    "linux": {
        "chrome": ("Google Chrome / Google Password Manager", ".config/google-chrome", True),
        "chromium": ("Chromium", ".config/chromium", False),
        "edge": ("Microsoft Edge / Microsoft Password Manager", ".config/microsoft-edge", True),
        "brave": ("Brave", ".config/BraveSoftware/Brave-Browser", True),
        "vivaldi": ("Vivaldi", ".config/vivaldi", True),
        "opera": ("Opera", ".config/opera", True),
        "firefox": ("Firefox / Mozilla Passwords", ".mozilla/firefox", True),
    },
    "darwin": {
        "chrome": ("Google Chrome / Google Password Manager", "Library/Application Support/Google/Chrome", True),
        "chromium": ("Chromium", "Library/Application Support/Chromium", False),
        "edge": ("Microsoft Edge / Microsoft Password Manager", "Library/Application Support/Microsoft Edge", True),
        "brave": ("Brave", "Library/Application Support/BraveSoftware/Brave-Browser", True),
        "vivaldi": ("Vivaldi", "Library/Application Support/Vivaldi", True),
        "opera": ("Opera", "Library/Application Support/com.operasoftware.Opera", True),
        "firefox": ("Firefox / Mozilla Passwords", "Library/Application Support/Firefox", True),
        "safari": ("Safari / iCloud Keychain", "Library/Safari", True),
    },
    "windows": {
        "chrome": ("Google Chrome / Google Password Manager", "AppData/Local/Google/Chrome/User Data", True),
        "chromium": ("Chromium", "AppData/Local/Chromium/User Data", False),
        "edge": ("Microsoft Edge / Microsoft Password Manager", "AppData/Local/Microsoft/Edge/User Data", True),
        "brave": ("Brave", "AppData/Local/BraveSoftware/Brave-Browser/User Data", True),
        "vivaldi": ("Vivaldi", "AppData/Local/Vivaldi/User Data", True),
        "opera": ("Opera", "AppData/Roaming/Opera Software/Opera Stable", True),
        "firefox": ("Firefox / Mozilla Passwords", "AppData/Roaming/Mozilla/Firefox", True),
    },
}


class CredentialStoreScanner:
    def __init__(
        self,
        home: Path,
        platform_name: str,
        access_mode: str = "none",
        allow_network: bool = False,
        max_records: int = 200,
        command_timeout: int = 8,
    ) -> None:
        self.home = home.expanduser().resolve()
        self.platform = platform_name
        self.access_mode = access_mode
        self.allow_network = allow_network
        self.max_records = max(1, min(max_records, 10_000))
        self.command_timeout = max(1, min(command_timeout, 60))

    def scan(self) -> list[CredentialStoreFinding]:
        findings: dict[str, CredentialStoreFinding] = {}
        self._detect_managers(findings)
        self._detect_browsers(findings)
        self._detect_os_stores(findings)
        if self.access_mode == "metadata":
            self._access_managers(findings)
            self._access_browsers(findings)
            self._access_os_stores(findings)
        return sorted(findings.values(), key=lambda x: (x.kind, x.name.lower()))

    def _detect_managers(self, findings: dict[str, CredentialStoreFinding]) -> None:
        for spec in MANAGERS:
            hit_paths = []
            for rel in spec.paths.get(self.platform, ()):
                path = self.home / rel
                if path.exists():
                    hit_paths.append(path)
            kdbx = []
            if spec.id == "keepassxc":
                # Bounded discovery only in conventional top-level document/config locations.
                for root in (self.home, self.home / "Documents", self.home / ".config"):
                    if root.exists() and root.is_dir():
                        try:
                            kdbx.extend(list(root.glob("*.kdbx"))[:20])
                        except OSError:
                            pass
            cli_path = shutil.which(spec.cli) if spec.cli else None
            if not hit_paths and not kdbx and not cli_path:
                continue
            finding = CredentialStoreFinding(
                store_id=spec.id,
                name=spec.name,
                kind="password_manager",
                deployment=spec.deployment,
                cloud_capable=spec.cloud_capable,
                cli=spec.cli,
                cli_available=bool(cli_path),
                access_capability=spec.access_capability,
            )
            for path in hit_paths + kdbx:
                finding.detected_paths.add(self._safe_rel(path))
                finding.evidence.append(Evidence(self._safe_rel(path), "path", "password-manager-data"))
            if cli_path:
                finding.evidence.append(Evidence(cli_path, "cli", spec.cli or ""))
            findings[spec.id] = finding

    def _detect_browsers(self, findings: dict[str, CredentialStoreFinding]) -> None:
        for browser_id, (name, rel, cloud_capable) in BROWSERS.get(self.platform, {}).items():
            root = self.home / rel
            if not root.exists():
                continue
            store_id = f"browser_{browser_id}"
            finding = CredentialStoreFinding(
                store_id=store_id,
                name=name,
                kind="browser_password_store",
                deployment="browser",
                cloud_capable=cloud_capable,
                access_capability="metadata_local" if browser_id != "safari" else "os_keychain_required",
            )
            finding.detected_paths.add(self._safe_rel(root))
            finding.evidence.append(Evidence(self._safe_rel(root), "path", "browser-profile-root"))
            if browser_id == "firefox":
                for profile in self._firefox_profiles(root):
                    finding.profiles.add(self._safe_rel(profile))
                    if (profile / "logins.json").exists():
                        finding.evidence.append(Evidence(self._safe_rel(profile / "logins.json"), "store", "firefox-logins"))
                    self._detect_firefox_password_manager_extensions(profile, finding, findings)
            elif browser_id == "safari":
                finding.profiles.add(self._safe_rel(root))
            else:
                for profile in self._chromium_profiles(root):
                    finding.profiles.add(self._safe_rel(profile))
                    for login_name in ("Login Data", "Login Data For Account"):
                        db = profile / login_name
                        if db.exists():
                            finding.evidence.append(Evidence(self._safe_rel(db), "store", "chromium-login-db"))
                    finding.account_emails.update(self._browser_account_emails(profile))
                    self._detect_password_manager_extensions(profile, finding, findings)
            findings[store_id] = finding

    def _detect_os_stores(self, findings: dict[str, CredentialStoreFinding]) -> None:
        if self.platform == "darwin":
            store = CredentialStoreFinding(
                store_id="os_macos_keychain", name="macOS Keychain / iCloud Keychain",
                kind="os_keychain", deployment="os", cloud_capable=True,
                cli="security", cli_available=bool(shutil.which("security")), access_capability="keychain_list_only",
            )
            store.evidence.append(Evidence("macOS", "platform", "Keychain available by platform"))
            findings[store.store_id] = store
        elif self.platform == "windows":
            store = CredentialStoreFinding(
                store_id="os_windows_credential_manager", name="Windows Credential Manager",
                kind="os_keychain", deployment="os", cloud_capable=False,
                cli="cmdkey", cli_available=bool(shutil.which("cmdkey")), access_capability="account_metadata",
            )
            store.evidence.append(Evidence("Windows", "platform", "Credential Manager available by platform"))
            findings[store.store_id] = store
        elif self.platform == "linux":
            candidates = [self.home / ".local/share/keyrings", self.home / ".config/keyrings"]
            if any(p.exists() for p in candidates) or os.environ.get("DBUS_SESSION_BUS_ADDRESS"):
                store = CredentialStoreFinding(
                    store_id="os_linux_secret_service", name="Linux Secret Service / GNOME Keyring",
                    kind="os_keychain", deployment="os", cloud_capable=False,
                    cli="secret-tool", cli_available=bool(shutil.which("secret-tool")), access_capability="detect_only",
                )
                for p in candidates:
                    if p.exists():
                        store.detected_paths.add(self._safe_rel(p))
                store.evidence.append(Evidence("linux", "platform", "secret-service/keyring detected"))
                findings[store.store_id] = store

    def _access_managers(self, findings: dict[str, CredentialStoreFinding]) -> None:
        for store_id, finding in list(findings.items()):
            if finding.kind != "password_manager" or not finding.cli_available:
                continue
            if store_id == "1password":
                self._access_1password(finding)
            elif store_id == "bitwarden":
                self._access_bitwarden(finding)
            elif store_id == "pass":
                self._access_pass(finding)
            elif store_id == "gopass":
                self._access_gopass(finding)
            elif store_id == "keepassxc":
                finding.warnings.append("metadata access requires an interactive database unlock; no password prompt is automated")

    def _access_1password(self, finding: CredentialStoreFinding) -> None:
        finding.access_attempted = True
        accounts = self._run_json(["op", "account", "list", "--format=json"], finding)
        if isinstance(accounts, list):
            finding.access_ok = True
            for account in accounts[: self.max_records]:
                if not isinstance(account, dict):
                    continue
                email = _first_text(account, "email")
                if email:
                    finding.account_emails.add(email.lower())
                title = _first_text(account, "url", "shorthand", "email") or "1Password account"
                finding.merge_record(CredentialRecord("account", title, username=email, source="op account list"))
        if self.allow_network:
            items = self._run_json(["op", "item", "list", "--format=json"], finding)
            if isinstance(items, list):
                finding.access_ok = True
                for item in items[: self.max_records]:
                    if not isinstance(item, dict):
                        continue
                    title = _first_text(item, "title") or "1Password item"
                    external_id = _first_text(item, "id")
                    category = _first_text(item, "category") or "item"
                    finding.merge_record(CredentialRecord(category.lower(), title, source="op item list", external_id=external_id))
        else:
            finding.warnings.append("1Password item inventory skipped: --allow-manager-network not enabled")

    def _access_bitwarden(self, finding: CredentialStoreFinding) -> None:
        finding.access_attempted = True
        status = self._run_json(["bw", "status"], finding)
        if isinstance(status, dict):
            finding.access_ok = True
            email = _first_text(status, "userEmail")
            if email:
                finding.account_emails.add(email.lower())
            server = _first_text(status, "serverUrl")
            state = _first_text(status, "status") or "unknown"
            title = f"Bitwarden account ({state})"
            urls = (server,) if server else ()
            finding.merge_record(CredentialRecord("account", title, username=email, urls=urls, source="bw status"))
        finding.warnings.append("Bitwarden item listing is intentionally disabled because `bw list items` includes secret fields")

    def _access_pass(self, finding: CredentialStoreFinding) -> None:
        finding.access_attempted = True
        result = self._run_text(["pass", "ls"], finding)
        if result is None:
            return
        finding.access_ok = True
        for line in result.splitlines()[: self.max_records]:
            cleaned = line.strip().lstrip("├└│─ ").strip()
            if cleaned and not cleaned.lower().startswith("password store"):
                finding.merge_record(CredentialRecord("entry_name", cleaned, source="pass ls"))

    def _access_gopass(self, finding: CredentialStoreFinding) -> None:
        finding.access_attempted = True
        result = self._run_text(["gopass", "ls", "--flat"], finding)
        if result is None:
            return
        finding.access_ok = True
        for line in result.splitlines()[: self.max_records]:
            cleaned = line.strip()
            if cleaned:
                finding.merge_record(CredentialRecord("entry_name", cleaned, source="gopass ls --flat"))

    def _access_browsers(self, findings: dict[str, CredentialStoreFinding]) -> None:
        for finding in findings.values():
            if finding.kind != "browser_password_store":
                continue
            if finding.store_id == "browser_safari":
                finding.warnings.append("Safari passwords remain in Keychain; this scanner does not request or reveal Keychain secrets")
                continue
            finding.access_attempted = True
            warning_count = len(finding.warnings)
            for profile_rel in sorted(finding.profiles):
                profile = self._from_safe_rel(profile_rel)
                if finding.store_id == "browser_firefox":
                    self._read_firefox_metadata(profile, finding)
                else:
                    self._read_chromium_metadata(profile, finding)
            finding.access_ok = len(finding.warnings) == warning_count

    def _access_os_stores(self, findings: dict[str, CredentialStoreFinding]) -> None:
        current_home = Path.home().expanduser().resolve()
        if self.home != current_home:
            for finding in findings.values():
                if finding.kind == "os_keychain":
                    finding.warnings.append("OS credential store access skipped for offline/non-current home")
            return
        if self.platform == "windows":
            finding = findings.get("os_windows_credential_manager")
            if finding and finding.cli_available:
                finding.access_attempted = True
                text = self._run_text(["cmdkey", "/list"], finding)
                if text is not None:
                    finding.access_ok = True
                    target = None
                    username = None
                    for raw in text.splitlines() + [""]:
                        line = raw.strip()
                        lower = line.lower()
                        if lower.startswith("target:"):
                            if target:
                                finding.merge_record(CredentialRecord("credential_target", target, username=username, source="cmdkey /list"))
                            target = line.split(":", 1)[1].strip()
                            username = None
                        elif lower.startswith("user:") or lower.startswith("username:"):
                            username = line.split(":", 1)[1].strip()
                        elif not line and target:
                            finding.merge_record(CredentialRecord("credential_target", target, username=username, source="cmdkey /list"))
                            target = None
                            username = None
        elif self.platform == "darwin":
            finding = findings.get("os_macos_keychain")
            if finding and finding.cli_available:
                finding.access_attempted = True
                text = self._run_text(["security", "list-keychains", "-d", "user"], finding)
                if text is not None:
                    finding.access_ok = True
                    for line in text.splitlines()[: self.max_records]:
                        value = line.strip().strip('"')
                        if value:
                            finding.merge_record(CredentialRecord("keychain", Path(value).name, source="security list-keychains"))

    @contextlib.contextmanager
    def _chromium_snapshot(self, db: Path):
        """Create a consistent temporary SQLite snapshot without selecting secret columns."""
        with tempfile.TemporaryDirectory(prefix="llm-account-browser-") as temp_dir:
            snapshot = Path(temp_dir) / "Login Data"
            try:
                source = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True, timeout=1)
                target = sqlite3.connect(snapshot)
                try:
                    source.backup(target)
                finally:
                    target.close()
                    source.close()
            except sqlite3.Error:
                # Fallback for browser/SQLite variants where backup cannot open the live DB:
                # copy the DB plus WAL/SHM sidecars so SQLite can recover a coherent snapshot.
                shutil.copy2(db, snapshot)
                for suffix in ("-wal", "-shm"):
                    sidecar = Path(str(db) + suffix)
                    if sidecar.exists():
                        shutil.copy2(sidecar, Path(str(snapshot) + suffix))
            yield snapshot

    def _read_chromium_metadata(self, profile: Path, finding: CredentialStoreFinding) -> None:
        for login_name in ("Login Data", "Login Data For Account"):
            db = profile / login_name
            if not db.exists():
                continue
            try:
                with self._chromium_snapshot(db) as snapshot:
                    conn = sqlite3.connect(f"file:{snapshot.as_posix()}?mode=ro", uri=True, timeout=1)
                    try:
                        rows = conn.execute(
                            "SELECT origin_url, username_value FROM logins ORDER BY date_last_used DESC LIMIT ?",
                            (self.max_records,),
                        ).fetchall()
                    finally:
                        conn.close()
            except (sqlite3.Error, OSError) as exc:
                finding.warnings.append(f"could not read {self._safe_rel(db)} metadata: {type(exc).__name__}")
                continue
            for origin, username in rows:
                origin = str(origin or "").strip()
                username = str(username or "").strip() or None
                title = _origin_label(origin) or "saved login"
                urls = (origin,) if origin else ()
                finding.merge_record(CredentialRecord("browser_login", title, username=username, urls=urls, source=self._safe_rel(db)))

    def _read_firefox_metadata(self, profile: Path, finding: CredentialStoreFinding) -> None:
        path = profile / "logins.json"
        if not path.exists():
            return
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            finding.warnings.append(f"could not read {self._safe_rel(path)} metadata: {type(exc).__name__}")
            return
        rows = payload.get("logins", []) if isinstance(payload, dict) else []
        for item in rows[: self.max_records]:
            if not isinstance(item, dict):
                continue
            hostname = str(item.get("hostname") or "").strip()
            # encryptedUsername/encryptedPassword are deliberately ignored.
            title = _origin_label(hostname) or "saved login"
            urls = (hostname,) if hostname else ()
            finding.merge_record(CredentialRecord("browser_login", title, urls=urls, source=self._safe_rel(path)))

    def _detect_password_manager_extensions(
        self,
        profile: Path,
        browser_finding: CredentialStoreFinding,
        findings: dict[str, CredentialStoreFinding],
    ) -> None:
        ext_root = profile / "Extensions"
        if not ext_root.exists() or not ext_root.is_dir():
            return
        manifests = []
        try:
            manifests = list(ext_root.glob("*/*/manifest.json"))[:1000]
        except OSError:
            return
        for manifest in manifests:
            try:
                text = manifest.read_text(encoding="utf-8", errors="ignore")[:200_000].lower()
            except OSError:
                continue
            for spec in MANAGERS:
                if not any(marker in text for marker in spec.markers):
                    continue
                finding = findings.get(spec.id)
                if finding is None:
                    finding = CredentialStoreFinding(
                        store_id=spec.id,
                        name=spec.name,
                        kind="password_manager",
                        deployment=spec.deployment,
                        cloud_capable=spec.cloud_capable,
                        cli=spec.cli,
                        cli_available=bool(shutil.which(spec.cli)) if spec.cli else False,
                        access_capability=spec.access_capability,
                    )
                    findings[spec.id] = finding
                rel = self._safe_rel(manifest)
                finding.detected_paths.add(rel)
                finding.evidence.append(Evidence(rel, "browser_extension", browser_finding.name))

    def _detect_firefox_password_manager_extensions(
        self,
        profile: Path,
        browser_finding: CredentialStoreFinding,
        findings: dict[str, CredentialStoreFinding],
    ) -> None:
        path = profile / "extensions.json"
        if not path.exists():
            return
        try:
            payload = json.loads(path.read_text(encoding="utf-8", errors="ignore")[:2_000_000])
        except (OSError, json.JSONDecodeError):
            return
        addons = payload.get("addons", []) if isinstance(payload, dict) else []
        for addon in addons[:1000]:
            if not isinstance(addon, dict):
                continue
            text = " ".join(
                str(addon.get(key) or "")
                for key in ("name", "description", "defaultLocale", "sourceURI")
            ).lower()
            for spec in MANAGERS:
                if not any(marker in text for marker in spec.markers):
                    continue
                finding = findings.get(spec.id)
                if finding is None:
                    finding = CredentialStoreFinding(
                        store_id=spec.id,
                        name=spec.name,
                        kind="password_manager",
                        deployment=spec.deployment,
                        cloud_capable=spec.cloud_capable,
                        cli=spec.cli,
                        cli_available=bool(shutil.which(spec.cli)) if spec.cli else False,
                        access_capability=spec.access_capability,
                    )
                    findings[spec.id] = finding
                rel = self._safe_rel(path)
                finding.detected_paths.add(rel)
                finding.evidence.append(Evidence(rel, "browser_extension", browser_finding.name))

    def _chromium_profiles(self, root: Path) -> Iterable[Path]:
        if any((root / name).exists() for name in ("Login Data", "Preferences")):
            yield root
        try:
            children = list(root.iterdir())
        except OSError:
            return
        for child in children:
            if not child.is_dir():
                continue
            if child.name == "Default" or child.name.startswith("Profile ") or (child / "Preferences").exists() or (child / "Login Data").exists():
                yield child

    def _firefox_profiles(self, root: Path) -> Iterable[Path]:
        profiles_root = root / "Profiles" if (root / "Profiles").is_dir() else root
        try:
            children = list(profiles_root.iterdir())
        except OSError:
            return
        for child in children:
            if child.is_dir() and ((child / "logins.json").exists() or (child / "prefs.js").exists()):
                yield child

    def _browser_account_emails(self, profile: Path) -> set[str]:
        result: set[str] = set()
        pref = profile / "Preferences"
        if not pref.exists():
            return result
        try:
            payload = json.loads(pref.read_text(encoding="utf-8", errors="ignore"))
        except (OSError, json.JSONDecodeError):
            return result
        if not isinstance(payload, dict):
            return result
        account_info = payload.get("account_info")
        if isinstance(account_info, list):
            for item in account_info:
                if isinstance(item, dict):
                    value = item.get("email")
                    if isinstance(value, str):
                        result.update(emails(value))
        profile_obj = payload.get("profile")
        if isinstance(profile_obj, dict):
            for key in ("user_name", "gaia_name"):
                value = profile_obj.get(key)
                if isinstance(value, str):
                    result.update(emails(value))
        return result

    def _run_json(self, command: list[str], finding: CredentialStoreFinding):
        text = self._run_text(command, finding)
        if text is None:
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            finding.warnings.append(f"{command[0]} returned non-JSON metadata")
            return None

    def _run_text(self, command: list[str], finding: CredentialStoreFinding) -> str | None:
        env = os.environ.copy()
        env.setdefault("NO_COLOR", "1")
        try:
            proc = subprocess.run(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self.command_timeout,
                env=env,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            finding.warnings.append(f"{command[0]} metadata command failed: {type(exc).__name__}")
            return None
        if proc.returncode != 0:
            finding.warnings.append(f"{command[0]} metadata command returned exit {proc.returncode}")
            return None
        # stdout is processed only by a command-specific parser; stderr is never exported.
        return proc.stdout

    def _safe_rel(self, path: Path) -> str:
        try:
            return "~/" + path.resolve().relative_to(self.home).as_posix()
        except (OSError, ValueError):
            return str(path)

    def _from_safe_rel(self, value: str) -> Path:
        if value.startswith("~/"):
            return self.home / value[2:]
        return Path(value)


def _first_text(payload: dict, *keys: str) -> str | None:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _origin_label(url: str) -> str:
    if not url:
        return ""
    try:
        parsed = urlparse(url)
        return parsed.hostname or url
    except ValueError:
        return url
