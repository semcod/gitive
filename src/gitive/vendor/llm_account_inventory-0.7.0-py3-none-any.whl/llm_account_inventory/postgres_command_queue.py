from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any

from .command_queue import QueueLeaseLost, completed_result_for_storage
from .postgres import connect, database_url
from .protobuf_contracts import CommandEnvelope, encode


def _iso(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    return str(value)


class PostgresCommandQueue:
    """Multi-worker durable queue. Claims use FOR UPDATE SKIP LOCKED."""

    def __init__(self, dsn: str | None = None):
        self.dsn = database_url(dsn)
        self._init_db()

    def _connect(self, *, autocommit: bool = True):
        return connect(self.dsn, autocommit=autocommit)

    def _init_db(self) -> None:
        ddl = """
        CREATE TABLE IF NOT EXISTS command_queue (
            command_id TEXT PRIMARY KEY,
            idempotency_key TEXT NOT NULL UNIQUE,
            stream_id TEXT NOT NULL,
            command_type TEXT NOT NULL,
            envelope BYTEA NOT NULL,
            status TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            max_attempts INTEGER NOT NULL DEFAULT 5,
            available_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            lease_until TIMESTAMPTZ,
            worker_id TEXT,
            last_error_code TEXT,
            result_json JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS idx_command_queue_ready ON command_queue(status, available_at, created_at);
        CREATE INDEX IF NOT EXISTS idx_command_queue_lease ON command_queue(status, lease_until);
        """
        # PostgreSQL's CREATE TABLE IF NOT EXISTS still has a catalog race when
        # multiple fresh workers initialize the same relation concurrently.
        # Serialize only this short schema transaction; normal queue operations
        # remain fully concurrent and use SKIP LOCKED below.
        with self._connect(autocommit=False) as conn:
            try:
                conn.execute("SELECT pg_advisory_xact_lock(%s, %s)", (120041, 1))
                for statement in (part.strip() for part in ddl.split(";")):
                    if statement:
                        conn.execute(statement)
                conn.commit()
            except Exception:
                conn.rollback()
                raise

    def enqueue(self, command: CommandEnvelope, *, max_attempts: int = 5) -> dict[str, Any]:
        if not command.idempotency_key:
            raise ValueError("idempotency_key is required")
        raw = encode(command)
        with self._connect(autocommit=False) as conn:
            try:
                # Atomic idempotency claim. Two workers may reach this code before either
                # can observe the other's row; ON CONFLICT makes the loser wait for the
                # winning transaction and then deterministically return the existing item.
                row = conn.execute(
                    """
                    INSERT INTO command_queue(
                        command_id, idempotency_key, stream_id, command_type, envelope, status,
                        attempts, max_attempts, available_at
                    ) VALUES (%s, %s, %s, %s, %s, 'queued', 0, %s, now())
                    ON CONFLICT DO NOTHING
                    RETURNING *
                    """,
                    (
                        command.command_id, command.idempotency_key, command.stream_id,
                        command.command_type, raw, max(1, int(max_attempts)),
                    ),
                ).fetchone()
                if row is not None:
                    conn.commit()
                    return self._row(row, replay=False)

                row = conn.execute(
                    "SELECT * FROM command_queue WHERE idempotency_key=%s FOR UPDATE",
                    (command.idempotency_key,),
                ).fetchone()
                if row is not None:
                    conn.commit()
                    return self._row(row, replay=True)

                command_collision = conn.execute(
                    "SELECT command_id, idempotency_key FROM command_queue WHERE command_id=%s FOR UPDATE",
                    (command.command_id,),
                ).fetchone()
                if command_collision is not None:
                    raise ValueError("command_id is already bound to a different idempotency_key")
                raise RuntimeError("queue insert conflict resolved without a matching existing row")
            except Exception:
                conn.rollback()
                raise

    def claim(self, worker_id: str, *, lease_seconds: int = 120) -> dict[str, Any] | None:
        now_dt = datetime.now(timezone.utc)
        lease_until = now_dt + timedelta(seconds=max(1, int(lease_seconds)))
        with self._connect(autocommit=False) as conn:
            try:
                # Expired leases become eligible again. This update is safe across workers.
                conn.execute(
                    """
                    UPDATE command_queue
                    SET status='queued', worker_id=NULL, lease_until=NULL, updated_at=now()
                    WHERE status='processing' AND lease_until IS NOT NULL AND lease_until<=now()
                    """
                )
                row = conn.execute(
                    """
                    SELECT * FROM command_queue
                    WHERE status='queued' AND available_at<=now()
                    ORDER BY created_at, command_id
                    FOR UPDATE SKIP LOCKED
                    LIMIT 1
                    """
                ).fetchone()
                if row is None:
                    conn.commit()
                    return None
                updated = conn.execute(
                    """
                    UPDATE command_queue
                    SET status='processing', worker_id=%s, lease_until=%s,
                        attempts=attempts+1, updated_at=now()
                    WHERE command_id=%s
                    RETURNING *
                    """,
                    (worker_id, lease_until, row["command_id"]),
                ).fetchone()
                conn.commit()
                return self._row(updated)
            except Exception:
                conn.rollback()
                raise

    def renew(self, command_id: str, worker_id: str, *, lease_seconds: int = 120) -> str:
        now_dt = datetime.now(timezone.utc)
        lease_until = now_dt + timedelta(seconds=max(1, int(lease_seconds)))
        with self._connect(autocommit=False) as conn:
            try:
                row = conn.execute(
                    "SELECT status, worker_id, lease_until FROM command_queue WHERE command_id=%s FOR UPDATE",
                    (command_id,),
                ).fetchone()
                if not row or row["status"] != "processing" or row["worker_id"] != worker_id:
                    raise QueueLeaseLost("queue lease is no longer owned by worker")
                if row["lease_until"] and row["lease_until"] <= now_dt:
                    raise QueueLeaseLost("queue lease expired")
                conn.execute(
                    "UPDATE command_queue SET lease_until=%s, updated_at=now() WHERE command_id=%s AND worker_id=%s",
                    (lease_until, command_id, worker_id),
                )
                conn.commit()
                return lease_until.isoformat()
            except Exception:
                conn.rollback()
                raise

    def complete(self, command_id: str, worker_id: str, result: dict[str, Any]) -> None:
        stored_result = completed_result_for_storage(result)
        with self._connect() as conn:
            row = conn.execute(
                """
                UPDATE command_queue SET status='completed', result_json=%s::jsonb,
                    envelope=%s, lease_until=NULL, updated_at=now()
                WHERE command_id=%s AND worker_id=%s AND status='processing'
                RETURNING command_id
                """,
                (
                    json.dumps(stored_result, ensure_ascii=False, sort_keys=True),
                    b"",
                    command_id,
                    worker_id,
                ),
            ).fetchone()
            if row is None:
                raise QueueLeaseLost("cannot complete command without active queue lease")

    def fail(self, command_id: str, worker_id: str, error_code: str) -> dict[str, Any]:
        with self._connect(autocommit=False) as conn:
            try:
                row = conn.execute(
                    "SELECT * FROM command_queue WHERE command_id=%s AND worker_id=%s AND status='processing' FOR UPDATE",
                    (command_id, worker_id),
                ).fetchone()
                if not row:
                    raise QueueLeaseLost("cannot fail command without active queue lease")
                attempts = int(row["attempts"])
                max_attempts = int(row["max_attempts"])
                if attempts >= max_attempts:
                    status = "dead_letter"
                    delay = 0
                else:
                    status = "queued"
                    delay = min(300, 2 ** min(attempts, 8))
                updated = conn.execute(
                    """
                    UPDATE command_queue
                    SET status=%s, available_at=now() + (%s * interval '1 second'),
                        lease_until=NULL, worker_id=NULL, last_error_code=%s, updated_at=now()
                    WHERE command_id=%s RETURNING *
                    """,
                    (status, delay, error_code, command_id),
                ).fetchone()
                conn.commit()
                return self._row(updated)
            except Exception:
                conn.rollback()
                raise

    def get(self, *, command_id: str | None = None, idempotency_key: str | None = None) -> dict[str, Any] | None:
        if not command_id and not idempotency_key:
            raise ValueError("command_id or idempotency_key is required")
        col, value = ("command_id", command_id) if command_id else ("idempotency_key", idempotency_key)
        with self._connect() as conn:
            row = conn.execute(f"SELECT * FROM command_queue WHERE {col}=%s", (value,)).fetchone()
        return self._row(row) if row else None

    @staticmethod
    def decode_command(row: dict[str, Any]) -> CommandEnvelope:
        msg = CommandEnvelope()
        msg.ParseFromString(row["envelope"])
        return msg

    @staticmethod
    def _row(row: dict[str, Any], replay: bool | None = None) -> dict[str, Any]:
        result_json = row.get("result_json")
        if isinstance(result_json, str):
            result_json = json.loads(result_json)
        result = {
            "command_id": row["command_id"], "idempotency_key": row["idempotency_key"],
            "stream_id": row["stream_id"], "command_type": row["command_type"],
            "status": row["status"], "attempts": int(row["attempts"]),
            "max_attempts": int(row["max_attempts"]), "available_at": _iso(row["available_at"]),
            "lease_until": _iso(row.get("lease_until")), "worker_id": row.get("worker_id"),
            "last_error_code": row.get("last_error_code"), "result": result_json,
            "created_at": _iso(row["created_at"]), "updated_at": _iso(row["updated_at"]),
            "envelope": bytes(row["envelope"]),
        }
        if replay is not None:
            result["idempotent_replay"] = replay
        return result
