from __future__ import annotations

import json
from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import Any

from .context import TrustedExecutionContext
from .uri_process import UriPolicy, UriProcessDispatcher


@dataclass(frozen=True)
class ConnectorDescriptor:
    connector_id: str
    scheme: str
    version: str
    routes: tuple[str, ...]


class AccountInventoryConnector:
    """Embedded URI Process connector entrypoint.

    This class deliberately accepts a ``TrustedExecutionContext`` object rather than
    actor/scope fields from the request body. It is intended for urirun-node style
    runtimes that have already authenticated the caller and evaluated its AQL scope.
    """

    def __init__(
        self,
        data_dir: str | Path,
        *,
        policy: UriPolicy | None = None,
        asynchronous: bool | None = None,
    ) -> None:
        self.dispatcher = UriProcessDispatcher(data_dir, policy=policy, asynchronous=asynchronous)

    def execute(
        self,
        *,
        uri: str,
        payload: dict[str, Any] | None,
        context: TrustedExecutionContext,
    ) -> dict[str, Any]:
        return self.dispatcher.run({"uri": uri, "payload": payload or {}}, context)

    @staticmethod
    def descriptor() -> ConnectorDescriptor:
        manifest_path = files("llm_account_inventory").joinpath("data/uri-process-manifest.json")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        connector = manifest["connector"]
        return ConnectorDescriptor(
            connector_id=str(connector["id"]),
            scheme=str(connector["scheme"]),
            version=str(connector["version"]),
            routes=tuple(str(row["uri"]) for row in manifest["routes"]),
        )


def execute_uri_process(
    *,
    data_dir: str | Path,
    uri: str,
    payload: dict[str, Any] | None,
    context: TrustedExecutionContext,
    policy: UriPolicy | None = None,
    asynchronous: bool | None = None,
) -> dict[str, Any]:
    """Functional adapter for runtimes that prefer a single callable entrypoint."""

    return AccountInventoryConnector(
        data_dir,
        policy=policy,
        asynchronous=asynchronous,
    ).execute(uri=uri, payload=payload, context=context)
