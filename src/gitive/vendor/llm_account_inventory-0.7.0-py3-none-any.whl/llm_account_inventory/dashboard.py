from __future__ import annotations

import argparse
import hmac
import json
import os
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
from ipaddress import ip_address
from pathlib import Path
from typing import Any

from .dsl import DslError
from .dsl_runtime import DslExecutor, DslSessionConfig


@dataclass(frozen=True)
class DashboardConfig:
    bind: str
    port: int
    token: str
    session: DslSessionConfig

    @classmethod
    def from_args(cls, args) -> "DashboardConfig":
        token = str(args.token or os.environ.get("ACCOUNT_INVENTORY_DASHBOARD_TOKEN") or "").strip()
        if not token:
            raise ValueError("dashboard requires --token or ACCOUNT_INVENTORY_DASHBOARD_TOKEN")
        if not args.allow_remote and not _is_loopback(args.bind):
            raise ValueError("non-loopback dashboard bind requires --allow-remote")
        return cls(
            bind=args.bind,
            port=args.port,
            token=token,
            session=DslSessionConfig(
                data_dir=args.data_dir,
                actor_id=args.actor_id,
                principal_id=args.principal_id,
                organization_id=args.organization_id,
                subject_user_id=args.subject_user_id,
                device_id=args.device_id,
                profile_id=args.profile_id,
                installation_id=args.installation_id,
                operator=bool(args.operator),
                allowed_homes=tuple(args.allowed_home),
                credential_metadata_enabled=bool(args.credential_metadata),
                manager_network_enabled=bool(args.manager_network),
            ),
        )


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="llm-accounts-dashboard", description="Read-model-first web dashboard with CQRS/ES DSL console.")
    p.add_argument("--data-dir", type=Path, default=Path(".inventory-data"))
    p.add_argument("--bind", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8787)
    p.add_argument("--token")
    p.add_argument("--allow-remote", action="store_true")
    p.add_argument("--operator", action="store_true", help="enable command/governance DSL in web console")
    p.add_argument("--actor-id", default="human:founder")
    p.add_argument("--principal-id", default="human:founder")
    p.add_argument("--organization-id", default="organization:local")
    p.add_argument("--subject-user-id", default="human:founder")
    p.add_argument("--device-id", default="device:local")
    p.add_argument("--profile-id", default="default")
    p.add_argument("--installation-id", default="installation:local")
    p.add_argument("--allowed-home", action="append", type=Path, default=[])
    p.add_argument("--credential-metadata", action="store_true")
    p.add_argument("--manager-network", action="store_true")
    return p


def main() -> int:
    args = build_parser().parse_args()
    config = DashboardConfig.from_args(args)
    serve(config)
    return 0


def serve(config: DashboardConfig, *, ready_hook=None) -> None:
    executor = DslExecutor(config.session)
    handler = _handler_factory(config, executor)
    server = ThreadingHTTPServer((config.bind, config.port), handler)
    if ready_hook:
        ready_hook(server.server_address)
    print(f"llm-account-inventory dashboard: http://{config.bind}:{server.server_port}/")
    print(f"mode: {'operator' if config.session.operator else 'viewer'}; token required in browser session")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


def _handler_factory(config: DashboardConfig, executor: DslExecutor):
    class Handler(BaseHTTPRequestHandler):
        server_version = "llm-account-inventory-dashboard/0.7"

        def do_GET(self):
            if self.path == "/healthz":
                return self._json(HTTPStatus.OK, {"ok": True, "status": "ok", "service": "dashboard"})
            if self.path == "/" or self.path.startswith("/?"):
                return self._asset("index.html", "text/html; charset=utf-8")
            if self.path == "/assets/app.js":
                return self._asset("app.js", "text/javascript; charset=utf-8")
            if self.path == "/assets/styles.css":
                return self._asset("styles.css", "text/css; charset=utf-8")
            if self.path == "/api/session":
                if not self._authorized():
                    return
                return self._json(HTTPStatus.OK, {
                    "ok": True,
                    "mode": "operator" if config.session.operator else "viewer",
                    "organization_id": config.session.organization_id,
                    "device_id": config.session.device_id,
                    "profile_id": config.session.profile_id,
                    "dsl_version": "0.7",
                })
            return self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found"})

        def do_POST(self):
            if self.path not in {"/api/dsl", "/api/dsl/inspect"}:
                return self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found"})
            if not self._authorized():
                return
            try:
                length = int(self.headers.get("Content-Length") or "0")
                if length <= 0 or length > 64 * 1024:
                    raise ValueError("invalid request size")
                body = json.loads(self.rfile.read(length))
                statement = str(body.get("statement") or "").strip()
                if not statement:
                    raise DslError("statement is required")
                result = executor.inspect(statement) if self.path.endswith("/inspect") else executor.execute(statement)
                return self._json(HTTPStatus.OK, result)
            except DslError as exc:
                return self._json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": "dsl_error", "message": str(exc)})
            except PermissionError as exc:
                return self._json(HTTPStatus.FORBIDDEN, {"ok": False, "error": "forbidden", "message": str(exc)})
            except Exception as exc:
                return self._json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": type(exc).__name__, "message": str(exc)})

        def _authorized(self) -> bool:
            header = str(self.headers.get("Authorization") or "")
            supplied = header[7:].strip() if header.startswith("Bearer ") else ""
            if supplied and hmac.compare_digest(supplied, config.token):
                return True
            self._json(HTTPStatus.UNAUTHORIZED, {"ok": False, "error": "unauthorized"})
            return False

        def _asset(self, name: str, content_type: str):
            data = files("llm_account_inventory.web").joinpath(name).read_bytes()
            self.send_response(HTTPStatus.OK)
            self._security_headers(content_type)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _json(self, status: HTTPStatus, payload: dict[str, Any]):
            data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
            self.send_response(status)
            self._security_headers("application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _security_headers(self, content_type: str):
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")

        def log_message(self, fmt, *args):
            if os.environ.get("ACCOUNT_INVENTORY_DASHBOARD_ACCESS_LOG", "0") == "1":
                super().log_message(fmt, *args)

    return Handler


def _is_loopback(host: str) -> bool:
    if host in {"localhost", "::1"}:
        return True
    try:
        return ip_address(host).is_loopback
    except ValueError:
        return False


if __name__ == "__main__":
    raise SystemExit(main())
