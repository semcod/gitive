from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .command_queue import SQLiteCommandQueue
from .event_store import SQLiteEventStore
from .metadata_vault import MetadataVault
from .projections import InventoryProjection


@dataclass(frozen=True)
class StorageConfig:
    backend: str
    data_dir: Path
    database_url: str | None = None

    @classmethod
    def from_env(cls, data_dir: str | Path) -> "StorageConfig":
        backend = (os.environ.get("ACCOUNT_INVENTORY_STORAGE_BACKEND") or "sqlite").strip().lower()
        if backend not in {"sqlite", "postgres"}:
            raise ValueError("ACCOUNT_INVENTORY_STORAGE_BACKEND must be sqlite or postgres")
        database_url = (os.environ.get("ACCOUNT_INVENTORY_DATABASE_URL") or "").strip() or None
        if backend == "postgres" and not database_url:
            raise ValueError("ACCOUNT_INVENTORY_DATABASE_URL is required for postgres backend")
        return cls(backend=backend, data_dir=Path(data_dir).expanduser().resolve(), database_url=database_url)


def event_store(config: StorageConfig):
    if config.backend == "sqlite":
        return SQLiteEventStore(config.data_dir / "events.sqlite3")
    from .postgres_event_store import PostgresEventStore
    return PostgresEventStore(config.database_url)


def projection(config: StorageConfig):
    from .projection_manager import active_slot, build_projection
    return build_projection(config, active_slot(config))


def metadata_vault(config: StorageConfig):
    if config.backend == "sqlite":
        return MetadataVault(config.data_dir)
    from .postgres_metadata_vault import PostgresMetadataVault
    return PostgresMetadataVault(config.database_url)


def command_queue(config: StorageConfig):
    if config.backend == "sqlite":
        return SQLiteCommandQueue(config.data_dir / "commands.sqlite3")
    from .postgres_command_queue import PostgresCommandQueue
    return PostgresCommandQueue(config.database_url)
