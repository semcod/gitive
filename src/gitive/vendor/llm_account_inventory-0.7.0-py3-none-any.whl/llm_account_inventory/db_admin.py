from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .cqrs import InventoryCQRS
from .outbox import outbox_for
from .storage import StorageConfig, command_queue


class DatabaseAdminError(RuntimeError):
    pass


def _run(args: list[str], *, env: dict[str, str] | None = None) -> None:
    try:
        subprocess.run(args, check=True, env=env)
    except FileNotFoundError as exc:
        raise DatabaseAdminError(f"required executable not found: {args[0]}") from exc
    except subprocess.CalledProcessError as exc:
        raise DatabaseAdminError(f"command failed with exit code {exc.returncode}: {args[0]}") from exc


def doctor(data_dir: Path) -> dict[str, Any]:
    app = InventoryCQRS(data_dir)
    queue = command_queue(app.storage)
    outbox = outbox_for(app.storage)
    event_pos = app.events.max_global_position()
    checkpoint = app.projection.checkpoint()
    return {
        "ok": True,
        "backend": app.storage.backend,
        "event_global_position": event_pos,
        "projection_checkpoint": checkpoint,
        "projection_lag": max(0, event_pos - checkpoint),
        "outbox_pending": outbox.pending_count(),
        "data_dir": str(app.paths.root),
        "database_configured": bool(app.storage.database_url) if app.storage.backend == "postgres" else True,
    }


def verify_rebuild(data_dir: Path) -> dict[str, Any]:
    app = InventoryCQRS(data_dir)
    before = app.projection.summary()
    max_pos = app.events.max_global_position()
    rebuilt = app.rebuild_projection()
    after = app.projection.summary()
    return {
        "ok": before == after and int(rebuilt.get("checkpoint", -1)) == max_pos,
        "backend": app.storage.backend,
        "event_global_position": max_pos,
        "checkpoint": rebuilt.get("checkpoint"),
        "summary_equal": before == after,
        "before": before,
        "after": after,
    }


def _sqlite_backup_one(source: Path, target: Path) -> None:
    if not source.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    src = sqlite3.connect(source)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def backup(data_dir: Path, output: Path) -> dict[str, Any]:
    config = StorageConfig.from_env(data_dir)
    output = output.expanduser().resolve()
    if config.backend == "sqlite":
        output.mkdir(parents=True, exist_ok=True)
        copied = []
        sqlite_names = ["events.sqlite3", "commands.sqlite3", "metadata-vault.sqlite3"]
        sqlite_names.extend(sorted(path.name for path in config.data_dir.glob("read-model*.sqlite3")))
        for name in dict.fromkeys(sqlite_names):
            src = config.data_dir / name
            if src.exists():
                _sqlite_backup_one(src, output / name)
                copied.append(name)
        pointer = config.data_dir / "projection-active.json"
        if pointer.exists():
            shutil.copy2(pointer, output / pointer.name)
            copied.append(pointer.name)
        for key_name in (".metadata.key", ".metadata-keyring.json", ".reference.key", ".checkpoint-signing.pub"):
            key = config.data_dir / key_name
            if key.exists():
                shutil.copy2(key, output / key_name)
                os.chmod(output / key_name, 0o600)
                copied.append(key_name)
        manifest = {
            "schema": "llm-account-inventory.backup/v1",
            "backend": "sqlite",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "files": copied,
        }
        (output / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
        return {"ok": True, "backend": "sqlite", "output": str(output), "files": copied}

    output.parent.mkdir(parents=True, exist_ok=True)
    _run(["pg_dump", "--format=custom", "--file", str(output), config.database_url or ""])
    return {"ok": True, "backend": "postgres", "output": str(output), "format": "pg_dump_custom"}


def restore(data_dir: Path, source: Path, *, yes: bool = False) -> dict[str, Any]:
    if not yes:
        raise DatabaseAdminError("restore is destructive; pass --yes explicitly")
    config = StorageConfig.from_env(data_dir)
    source = source.expanduser().resolve()
    if config.backend == "sqlite":
        if not source.is_dir():
            raise DatabaseAdminError("SQLite restore source must be a backup directory")
        config.data_dir.mkdir(parents=True, exist_ok=True)
        restored = []
        names = ["events.sqlite3", "commands.sqlite3", "metadata-vault.sqlite3", ".metadata.key", ".metadata-keyring.json", ".reference.key", ".checkpoint-signing.pub", "projection-active.json"]
        names.extend(sorted(path.name for path in source.glob("read-model*.sqlite3")))
        for name in dict.fromkeys(names):
            src = source / name
            if src.exists():
                shutil.copy2(src, config.data_dir / name)
                restored.append(name)
        return {"ok": True, "backend": "sqlite", "restored": restored}

    if not source.is_file():
        raise DatabaseAdminError("PostgreSQL restore source must be a pg_dump custom file")
    _run(["pg_restore", "--clean", "--if-exists", "--no-owner", "--dbname", config.database_url or "", str(source)])
    return {"ok": True, "backend": "postgres", "source": str(source)}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Database/DR operations for llm-account-inventory")
    parser.add_argument("--data-dir", type=Path, default=Path(os.environ.get("ACCOUNT_INVENTORY_DATA_DIR", ".inventory-data")))
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    sub.add_parser("verify-rebuild")
    sub.add_parser("projection-blue-green")
    sub.add_parser("keyring-status")
    rotate_cmd = sub.add_parser("keyring-rotate")
    rotate_cmd.add_argument("--key-id", required=True)
    shred_cmd = sub.add_parser("crypto-shred")
    shred_cmd.add_argument("--subject-id", required=True)
    shred_cmd.add_argument("--yes", action="store_true")
    sub.add_parser("checkpoint-create")
    checkpoint_verify = sub.add_parser("checkpoint-verify")
    checkpoint_verify.add_argument("--checkpoint", type=Path)
    backup_cmd = sub.add_parser("backup")
    backup_cmd.add_argument("--output", type=Path, required=True)
    restore_cmd = sub.add_parser("restore")
    restore_cmd.add_argument("--source", type=Path, required=True)
    restore_cmd.add_argument("--yes", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "doctor":
        result = doctor(args.data_dir)
    elif args.command == "verify-rebuild":
        result = verify_rebuild(args.data_dir)
    elif args.command == "projection-blue-green":
        result = InventoryCQRS(args.data_dir).blue_green_rebuild_projection()
    elif args.command == "keyring-status":
        result = InventoryCQRS(args.data_dir).metadata_keyring_status()
    elif args.command == "keyring-rotate":
        result = InventoryCQRS(args.data_dir).rotate_metadata_key(args.key_id)
    elif args.command == "crypto-shred":
        if not args.yes:
            raise DatabaseAdminError("crypto-shred is irreversible; pass --yes explicitly")
        result = InventoryCQRS(args.data_dir).crypto_shred_subject(args.subject_id)
    elif args.command == "checkpoint-create":
        result = InventoryCQRS(args.data_dir).create_integrity_checkpoint()
    elif args.command == "checkpoint-verify":
        result = InventoryCQRS(args.data_dir).verify_integrity_checkpoint(args.checkpoint)
    elif args.command == "backup":
        result = backup(args.data_dir, args.output)
    elif args.command == "restore":
        result = restore(args.data_dir, args.source, yes=args.yes)
    else:  # pragma: no cover
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
