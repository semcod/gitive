from __future__ import annotations

import argparse
import os
import time
import uuid
from pathlib import Path

from .cqrs import CQRSPaths, InventoryCQRS
from .storage import command_queue
from .observability import configure, inc, span, timed_metric


class InventoryCommandWorker:
    def __init__(self, data_dir: str | Path, *, worker_id: str | None = None, lease_seconds: int = 120):
        self.paths = CQRSPaths.under(data_dir)
        self.app = InventoryCQRS(self.paths.root, lease_seconds=lease_seconds)
        self.queue = command_queue(self.app.storage)
        self.worker_id = worker_id or f"worker_{uuid.uuid4().hex}"
        self.lease_seconds = lease_seconds
        self.metrics = configure("llm-account-inventory-worker")

    def process_once(self) -> bool:
        row = self.queue.claim(self.worker_id, lease_seconds=self.lease_seconds)
        if not row:
            return False
        backend = self.app.storage.backend
        inc(self.metrics.commands_claimed, backend)
        command = self.queue.decode_command(row)
        with span(
            "account_inventory.command.execute",
            command_id=command.command_id,
            command_type=command.command_type,
            trace_id=command.trace_id,
            backend=backend,
        ), timed_metric(self.metrics.command_duration, backend, command.command_type):
            try:
                result = self.app.execute_command(
                    command,
                    heartbeat_hook=lambda: self.queue.renew(
                        command.command_id, self.worker_id, lease_seconds=self.lease_seconds
                    ),
                )
                if result.get("status") == "in_progress":
                    self.queue.fail(command.command_id, self.worker_id, "domain_command_in_progress")
                    inc(self.metrics.commands_failed, backend, "domain_command_in_progress")
                else:
                    self.queue.complete(command.command_id, self.worker_id, result)
                    inc(self.metrics.commands_completed, backend)
                return True
            except Exception as exc:
                self.queue.fail(command.command_id, self.worker_id, f"{type(exc).__name__}")
                inc(self.metrics.commands_failed, backend, type(exc).__name__)
                return True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Durable llm-account-inventory command worker")
    parser.add_argument("--data-dir", type=Path, default=Path(os.environ.get("ACCOUNT_INVENTORY_DATA_DIR", ".inventory-data")))
    parser.add_argument("--worker-id")
    parser.add_argument("--lease-seconds", type=int, default=int(os.environ.get("ACCOUNT_INVENTORY_COMMAND_LEASE_SECONDS", "120")))
    parser.add_argument("--poll-seconds", type=float, default=1.0)
    parser.add_argument("--once", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    worker = InventoryCommandWorker(args.data_dir, worker_id=args.worker_id, lease_seconds=args.lease_seconds)
    if args.once:
        worker.process_once()
        return 0
    while True:
        if not worker.process_once():
            time.sleep(max(0.05, args.poll_seconds))


if __name__ == "__main__":
    raise SystemExit(main())
