from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable

from .credential_stores import CredentialStoreScanner
from .model import AccountFinding, Evidence, InventoryReport
from .paths import discover_roots, normalized_platform
from .redaction import emails, secret_names
from .registry import ProviderSpec, load_registry, specs_for_text

TEXT_EXTENSIONS = {
    "", ".json", ".jsonc", ".toml", ".yaml", ".yml", ".ini", ".cfg", ".conf",
    ".txt", ".md", ".env", ".properties", ".sh", ".bash", ".zsh", ".fish",
    ".ps1", ".xml", ".less", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".py",
}
SKIP_DIRS = {
    ".git", "node_modules", "vendor", "dist", "build", "target", "__pycache__",
    ".venv", "venv", ".tox", ".mypy_cache", ".pytest_cache", "Trash", ".Trash",
}
SKIP_FILE_HINTS = {
    "history", "cookies", "cookie", "login data", "web data", "keychain", "credentials.db",
}


@dataclass(frozen=True)
class ScanOptions:
    home: Path
    platform: str = "auto"
    deep_home: bool = False
    max_file_bytes: int = 1_000_000
    max_files: int = 20_000
    include_hidden: bool = True
    include_credential_stores: bool = False
    credential_access: str = "none"  # none | metadata
    allow_manager_network: bool = False
    max_credential_records: int = 200
    manager_timeout: int = 8


class InventoryScanner:
    def __init__(self, options: ScanOptions, heartbeat: Callable[[], None] | None = None):
        if options.credential_access not in {"none", "metadata"}:
            raise ValueError("credential_access must be 'none' or 'metadata'")
        self.options = options
        self.platform = normalized_platform(options.platform)
        self.roots = discover_roots(options.home, self.platform)
        self.registry = load_registry()
        self.heartbeat = heartbeat

    def scan(self) -> InventoryReport:
        files = list(self._candidate_files())
        findings: dict[str, AccountFinding] = {}
        skipped = 0
        scanned = 0
        warnings: list[str] = []

        for index, path in enumerate(files[: self.options.max_files]):
            if self.heartbeat and index % 100 == 0:
                self.heartbeat()
            try:
                if path.stat().st_size > self.options.max_file_bytes:
                    skipped += 1
                    continue
                text = path.read_text(encoding="utf-8", errors="ignore")
            except (OSError, UnicodeError):
                skipped += 1
                continue
            scanned += 1
            rel = self._safe_rel(path)
            mail_addresses = emails(text)
            secret_keys = secret_names(text)
            provider_matches = specs_for_text(text, rel, self.registry)
            for spec, reasons in provider_matches:
                finding = AccountFinding(
                    provider_id=spec.id,
                    provider_name=spec.name,
                    category=spec.category,
                    emails=set(mail_addresses),
                    secret_names={k for k in secret_keys if self._secret_matches_spec(k, spec)},
                    clients=set(spec.clients if any(r.startswith("path:") for r in reasons) else ()),
                    confidence=self._confidence(reasons),
                )
                for reason in reasons:
                    finding.evidence.append(Evidence(source=rel, kind=reason.split(":", 1)[0], detail=reason.split(":", 1)[1]))
                existing = findings.get(spec.id)
                if existing:
                    existing.merge(finding)
                else:
                    findings[spec.id] = finding

            if path in self.roots.identity_files and mail_addresses:
                spec = self._registry_item("developer_identity")
                finding = AccountFinding(
                    provider_id=spec.id,
                    provider_name=spec.name,
                    category=spec.category,
                    emails=set(mail_addresses),
                    confidence="high",
                    evidence=[Evidence(source=rel, kind="identity", detail="email")],
                )
                if spec.id in findings:
                    findings[spec.id].merge(finding)
                else:
                    findings[spec.id] = finding

        if len(files) > self.options.max_files:
            warnings.append(f"candidate file limit reached: {self.options.max_files}")

        if self.heartbeat:
            self.heartbeat()

        credential_stores = []
        if self.options.include_credential_stores or self.options.credential_access != "none":
            credential_stores = CredentialStoreScanner(
                self.roots.home,
                self.platform,
                access_mode=self.options.credential_access,
                allow_network=self.options.allow_manager_network,
                max_records=self.options.max_credential_records,
                command_timeout=self.options.manager_timeout,
            ).scan()
            if self.heartbeat:
                self.heartbeat()

        ordered = sorted(findings.values(), key=lambda x: (x.category, x.provider_name.lower()))
        return InventoryReport(
            schema_version="1.1",
            generated_at=datetime.now(timezone.utc).isoformat(),
            platform=self.platform,
            home=str(self.roots.home),
            files_considered=min(len(files), self.options.max_files),
            files_scanned=scanned,
            files_skipped=skipped,
            findings=ordered,
            credential_stores=credential_stores,
            warnings=warnings,
        )

    def _candidate_files(self) -> Iterable[Path]:
        seen: set[Path] = set()
        for path in self.roots.identity_files:
            if path.is_file() and path not in seen:
                seen.add(path)
                yield path

        scan_roots = list(self.roots.roots)
        if self.options.deep_home:
            scan_roots.append(self.roots.home)

        for root in scan_roots:
            if not root.exists() or not root.is_dir():
                continue
            for current, dirs, names in os.walk(root, topdown=True, followlinks=False):
                dirs[:] = [d for d in dirs if d not in SKIP_DIRS and (self.options.include_hidden or not d.startswith("."))]
                base = Path(current)
                for name in names:
                    if any(hint in name.lower() for hint in SKIP_FILE_HINTS):
                        continue
                    path = base / name
                    if path.is_symlink() or not path.is_file():
                        continue
                    if path.suffix.lower() not in TEXT_EXTENSIONS:
                        continue
                    if path not in seen:
                        seen.add(path)
                        yield path

    def _safe_rel(self, path: Path) -> str:
        try:
            return "~/" + path.resolve().relative_to(self.roots.home).as_posix()
        except (ValueError, OSError):
            return str(path)

    def _registry_item(self, provider_id: str) -> ProviderSpec:
        for item in self.registry:
            if item.id == provider_id:
                return item
        raise KeyError(provider_id)

    @staticmethod
    def _secret_matches_spec(secret_name: str, spec: ProviderSpec) -> bool:
        upper = secret_name.upper()
        return any(marker in upper for marker in spec.env_markers)

    @staticmethod
    def _confidence(reasons: list[str]) -> str:
        if any(r.startswith("env:") for r in reasons):
            return "high"
        if len(reasons) >= 2:
            return "high"
        if any(r.startswith("path:") for r in reasons):
            return "medium"
        return "low"
