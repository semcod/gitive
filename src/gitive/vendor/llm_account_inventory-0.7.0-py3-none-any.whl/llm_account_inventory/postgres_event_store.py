from __future__ import annotations

import json
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

from .event_store import ConcurrencyError, EventMetadata, LeaseLostError, PendingEvent, StoredEvent
from .postgres import connect, database_url
from .protobuf_contracts import EventEnvelope, encode, full_type
from .integrity import HASH_ALGORITHM, event_hash


def _iso(value: Any) -> str:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    return str(value or "")


class PostgresEventStore:
    """Production event store using PostgreSQL transactions and stream-head locks."""

    def __init__(self, dsn: str | None = None):
        self.dsn = database_url(dsn)
        self._init_db()

    def _connect(self, *, autocommit: bool = True):
        return connect(self.dsn, autocommit=autocommit)

    def _init_db(self) -> None:
        ddl = """
        CREATE TABLE IF NOT EXISTS event_streams (
            stream_id TEXT PRIMARY KEY,
            version BIGINT NOT NULL DEFAULT 0,
            last_event_hash TEXT NOT NULL DEFAULT '',
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS events (
            global_position BIGSERIAL PRIMARY KEY,
            event_id TEXT NOT NULL UNIQUE,
            stream_id TEXT NOT NULL,
            stream_version BIGINT NOT NULL,
            event_type TEXT NOT NULL,
            occurred_at TIMESTAMPTZ NOT NULL,
            actor_id TEXT NOT NULL,
            correlation_id TEXT NOT NULL,
            causation_id TEXT NOT NULL,
            trace_id TEXT NOT NULL,
            idempotency_key TEXT NOT NULL,
            payload_type TEXT NOT NULL,
            payload BYTEA NOT NULL,
            envelope BYTEA,
            organization_id TEXT NOT NULL DEFAULT '',
            principal_id TEXT NOT NULL DEFAULT '',
            subject_user_id TEXT NOT NULL DEFAULT '',
            device_id TEXT NOT NULL DEFAULT '',
            profile_id TEXT NOT NULL DEFAULT '',
            installation_id TEXT NOT NULL DEFAULT '',
            previous_event_hash TEXT NOT NULL DEFAULT '',
            event_hash TEXT NOT NULL DEFAULT '',
            hash_algorithm TEXT NOT NULL DEFAULT '',
            UNIQUE(stream_id, stream_version)
        );
        CREATE INDEX IF NOT EXISTS idx_events_stream ON events(stream_id, stream_version);
        CREATE INDEX IF NOT EXISTS idx_events_trace ON events(trace_id, global_position);
        CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type, global_position);
        CREATE INDEX IF NOT EXISTS idx_events_scope ON events(organization_id, device_id, profile_id, global_position);
        ALTER TABLE event_streams ADD COLUMN IF NOT EXISTS last_event_hash TEXT NOT NULL DEFAULT '';
        ALTER TABLE events ADD COLUMN IF NOT EXISTS previous_event_hash TEXT NOT NULL DEFAULT '';
        ALTER TABLE events ADD COLUMN IF NOT EXISTS event_hash TEXT NOT NULL DEFAULT '';
        ALTER TABLE events ADD COLUMN IF NOT EXISTS hash_algorithm TEXT NOT NULL DEFAULT '';

        CREATE TABLE IF NOT EXISTS command_receipts (
            command_id TEXT PRIMARY KEY,
            idempotency_key TEXT NOT NULL UNIQUE,
            stream_id TEXT NOT NULL,
            result_json JSONB NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS command_claims (
            idempotency_key TEXT PRIMARY KEY,
            command_id TEXT NOT NULL,
            stream_id TEXT NOT NULL,
            status TEXT NOT NULL,
            lease_until TIMESTAMPTZ NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS idx_command_claims_lease ON command_claims(status, lease_until);

        CREATE TABLE IF NOT EXISTS event_outbox (
            outbox_id BIGSERIAL PRIMARY KEY,
            event_id TEXT NOT NULL UNIQUE,
            topic TEXT NOT NULL,
            event_type TEXT NOT NULL,
            envelope BYTEA NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            attempts INTEGER NOT NULL DEFAULT 0,
            max_attempts INTEGER NOT NULL DEFAULT 10,
            available_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            lease_until TIMESTAMPTZ,
            worker_id TEXT,
            published_at TIMESTAMPTZ,
            last_error_code TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS idx_event_outbox_ready ON event_outbox(status, available_at, outbox_id);
        """
        with self._connect() as conn:
            for statement in (part.strip() for part in ddl.split(";")):
                if statement:
                    conn.execute(statement)

    def stream_version(self, stream_id: str, conn=None) -> int:
        owned = conn is None
        conn = conn or self._connect()
        try:
            row = conn.execute("SELECT version FROM event_streams WHERE stream_id=%s", (stream_id,)).fetchone()
            return int(row["version"]) if row else 0
        finally:
            if owned:
                conn.close()

    def append(
        self,
        stream_id: str,
        expected_version: int,
        events: Iterable[PendingEvent],
        metadata: EventMetadata,
        *,
        command_id: str | None = None,
        command_result: dict[str, Any] | None = None,
    ) -> list[StoredEvent]:
        pending = list(events)
        if not pending and command_id is None:
            return []
        with self._connect(autocommit=False) as conn:
            try:
                conn.execute(
                    "INSERT INTO event_streams(stream_id, version) VALUES (%s, 0) ON CONFLICT(stream_id) DO NOTHING",
                    (stream_id,),
                )
                head = conn.execute(
                    "SELECT version, last_event_hash FROM event_streams WHERE stream_id=%s FOR UPDATE", (stream_id,)
                ).fetchone()
                current = int(head["version"])
                previous_hash = str(head.get("last_event_hash") or "")
                if current > 0 and not previous_hash:
                    previous_hash = f"legacy-anchor:{stream_id}:{current}"
                if current != expected_version:
                    raise ConcurrencyError(
                        f"stream version conflict for {stream_id}: expected={expected_version} actual={current}"
                    )
                stored: list[StoredEvent] = []
                next_version = current
                for item in pending:
                    next_version += 1
                    event_id = item.event_id or f"evt_{uuid.uuid4().hex}"
                    occurred_at = item.occurred_at or datetime.now(timezone.utc).isoformat()
                    payload_type = full_type(item.payload)
                    payload = encode(item.payload)
                    current_hash = event_hash(
                        previous_event_hash=previous_hash, event_id=event_id, stream_id=stream_id,
                        stream_version=next_version, event_type=item.event_type, occurred_at=occurred_at,
                        metadata=metadata, payload_type=payload_type, payload=payload,
                    )
                    row = conn.execute(
                        """
                        INSERT INTO events(
                            event_id, stream_id, stream_version, event_type, occurred_at,
                            actor_id, correlation_id, causation_id, trace_id, idempotency_key,
                            payload_type, payload, organization_id, principal_id, subject_user_id,
                            device_id, profile_id, installation_id, previous_event_hash, event_hash, hash_algorithm
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        RETURNING global_position
                        """,
                        (
                            event_id, stream_id, next_version, item.event_type, occurred_at,
                            metadata.actor_id, metadata.correlation_id, metadata.causation_id,
                            metadata.trace_id, metadata.idempotency_key, payload_type, payload,
                            metadata.organization_id, metadata.principal_id, metadata.subject_user_id,
                            metadata.device_id, metadata.profile_id, metadata.installation_id,
                            previous_hash, current_hash, HASH_ALGORITHM,
                        ),
                    ).fetchone()
                    global_position = int(row["global_position"])
                    envelope_msg = EventEnvelope(
                        event_id=event_id,
                        stream_id=stream_id,
                        stream_version=next_version,
                        global_position=global_position,
                        event_type=item.event_type,
                        occurred_at=occurred_at,
                        actor_id=metadata.actor_id,
                        correlation_id=metadata.correlation_id,
                        causation_id=metadata.causation_id,
                        trace_id=metadata.trace_id,
                        idempotency_key=metadata.idempotency_key,
                        payload_type=payload_type,
                        payload=payload,
                        organization_id=metadata.organization_id,
                        principal_id=metadata.principal_id,
                        subject_user_id=metadata.subject_user_id,
                        device_id=metadata.device_id,
                        profile_id=metadata.profile_id,
                        installation_id=metadata.installation_id,
                        previous_event_hash=previous_hash,
                        event_hash=current_hash,
                        hash_algorithm=HASH_ALGORITHM,
                    )
                    envelope = encode(envelope_msg)
                    conn.execute("UPDATE events SET envelope=%s WHERE global_position=%s", (envelope, global_position))
                    conn.execute(
                        """
                        INSERT INTO event_outbox(event_id, topic, event_type, envelope)
                        VALUES (%s, %s, %s, %s)
                        ON CONFLICT(event_id) DO NOTHING
                        """,
                        (event_id, "account-inventory.events", item.event_type, envelope),
                    )
                    stored.append(
                        StoredEvent(
                            global_position=global_position,
                            event_id=event_id,
                            stream_id=stream_id,
                            stream_version=next_version,
                            event_type=item.event_type,
                            occurred_at=occurred_at,
                            metadata=metadata,
                            payload_type=payload_type,
                            payload=payload,
                            envelope=envelope,
                        )
                    )
                    previous_hash = current_hash
                conn.execute(
                    "UPDATE event_streams SET version=%s, last_event_hash=%s, updated_at=now() WHERE stream_id=%s",
                    (next_version, previous_hash, stream_id),
                )
                if command_id is not None:
                    conn.execute(
                        """
                        INSERT INTO command_receipts(command_id, idempotency_key, stream_id, result_json)
                        VALUES (%s, %s, %s, %s::jsonb)
                        """,
                        (
                            command_id, metadata.idempotency_key, stream_id,
                            json.dumps(command_result or {}, ensure_ascii=False, sort_keys=True),
                        ),
                    )
                    conn.execute(
                        """
                        UPDATE command_claims SET status='completed', lease_until=now(), updated_at=now()
                        WHERE idempotency_key=%s AND command_id=%s
                        """,
                        (metadata.idempotency_key, command_id),
                    )
                conn.commit()
                return stored
            except Exception:
                conn.rollback()
                raise

    def claim_command(
        self, *, command_id: str, idempotency_key: str, stream_id: str, lease_seconds: int = 120
    ) -> dict[str, Any]:
        if not idempotency_key.strip():
            raise ValueError("idempotency_key is required")
        existing = self.get_receipt(idempotency_key=idempotency_key)
        if existing:
            return {"status": "completed", "receipt": existing}
        now_dt = datetime.now(timezone.utc)
        lease_until = now_dt + timedelta(seconds=max(1, int(lease_seconds)))
        with self._connect(autocommit=False) as conn:
            try:
                # Atomically establish the first owner. SELECT-then-INSERT is unsafe here:
                # concurrent workers can both observe a missing row and race on the PK.
                inserted = conn.execute(
                    """
                    INSERT INTO command_claims(idempotency_key, command_id, stream_id, status, lease_until)
                    VALUES (%s, %s, %s, 'processing', %s)
                    ON CONFLICT(idempotency_key) DO NOTHING
                    RETURNING idempotency_key
                    """,
                    (idempotency_key, command_id, stream_id, lease_until),
                ).fetchone()
                if inserted is not None:
                    conn.commit()
                    return {"status": "claimed", "recovered": False, "lease_until": lease_until.isoformat()}

                row = conn.execute(
                    "SELECT * FROM command_claims WHERE idempotency_key=%s FOR UPDATE", (idempotency_key,)
                ).fetchone()
                if row is None:
                    raise RuntimeError("idempotency conflict resolved without an existing command claim")
                if row["status"] == "completed":
                    conn.commit()
                    return {"status": "completed", "receipt": self.get_receipt(idempotency_key=idempotency_key)}
                lease_expired = row["lease_until"] <= now_dt
                if row["status"] == "processing" and not lease_expired:
                    conn.commit()
                    return {
                        "status": "in_progress",
                        "owner_command_id": row["command_id"],
                        "lease_until": _iso(row["lease_until"]),
                    }
                conn.execute(
                    """
                    UPDATE command_claims SET command_id=%s, stream_id=%s, status='processing',
                        lease_until=%s, updated_at=now() WHERE idempotency_key=%s
                    """,
                    (command_id, stream_id, lease_until, idempotency_key),
                )
                conn.commit()
                return {
                    "status": "claimed",
                    "recovered": bool(lease_expired or row["status"] == "failed"),
                    "lease_until": lease_until.isoformat(),
                }
            except Exception:
                conn.rollback()
                raise

    def renew_claim(self, *, command_id: str, idempotency_key: str, lease_seconds: int = 120) -> str:
        now_dt = datetime.now(timezone.utc)
        lease_until = now_dt + timedelta(seconds=max(1, int(lease_seconds)))
        with self._connect(autocommit=False) as conn:
            try:
                row = conn.execute(
                    "SELECT status, command_id, lease_until FROM command_claims WHERE idempotency_key=%s FOR UPDATE",
                    (idempotency_key,),
                ).fetchone()
                if row is None or row["status"] != "processing" or row["command_id"] != command_id:
                    raise LeaseLostError("command lease is no longer owned by this worker")
                if row["lease_until"] <= now_dt:
                    raise LeaseLostError("command lease expired before heartbeat")
                conn.execute(
                    "UPDATE command_claims SET lease_until=%s, updated_at=now() WHERE idempotency_key=%s AND command_id=%s",
                    (lease_until, idempotency_key, command_id),
                )
                conn.commit()
                return lease_until.isoformat()
            except Exception:
                conn.rollback()
                raise

    def mark_claim_failed(self, *, command_id: str, idempotency_key: str) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE command_claims SET status='failed', lease_until=now(), updated_at=now()
                WHERE idempotency_key=%s AND command_id=%s
                """,
                (idempotency_key, command_id),
            )

    def get_receipt(self, *, command_id: str | None = None, idempotency_key: str | None = None) -> dict[str, Any] | None:
        if not command_id and not idempotency_key:
            raise ValueError("command_id or idempotency_key is required")
        col, value = ("command_id", command_id) if command_id else ("idempotency_key", idempotency_key)
        with self._connect() as conn:
            row = conn.execute(
                f"SELECT command_id, idempotency_key, stream_id, result_json, created_at FROM command_receipts WHERE {col}=%s",
                (value,),
            ).fetchone()
        if not row:
            return None
        result_value = row["result_json"]
        if isinstance(result_value, str):
            result_value = json.loads(result_value)
        return {
            "command_id": row["command_id"], "idempotency_key": row["idempotency_key"],
            "stream_id": row["stream_id"], "result": dict(result_value or {}), "created_at": _iso(row["created_at"]),
        }

    def read_stream(self, stream_id: str, *, after_version: int = 0) -> list[StoredEvent]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM events WHERE stream_id=%s AND stream_version>%s ORDER BY stream_version",
                (stream_id, after_version),
            ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def read_all(self, *, after_global_position: int = 0, limit: int = 1000) -> list[StoredEvent]:
        limit = max(1, min(int(limit), 10_000))
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM events WHERE global_position>%s ORDER BY global_position LIMIT %s",
                (after_global_position, limit),
            ).fetchall()
        return [self._row_to_event(row) for row in rows]

    def max_global_position(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT COALESCE(MAX(global_position), 0) AS pos FROM events").fetchone()
        return int(row["pos"])

    def stream_heads(self, *, at_global_position: int | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if at_global_position is None:
                rows = conn.execute(
                    """
                    SELECT DISTINCT ON (stream_id) stream_id, stream_version, event_hash, global_position
                    FROM events ORDER BY stream_id, stream_version DESC
                    """
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT DISTINCT ON (stream_id) stream_id, stream_version, event_hash, global_position
                    FROM events WHERE global_position<=%s ORDER BY stream_id, stream_version DESC
                    """,
                    (int(at_global_position),),
                ).fetchall()
        return [{
            "stream_id": str(row["stream_id"]),
            "stream_version": int(row["stream_version"]),
            "event_hash": str(row["event_hash"] or ""),
            "global_position": int(row["global_position"]),
        } for row in rows]

    def verify_integrity(self, stream_id: str) -> dict[str, Any]:
        from .integrity import verify_events
        return verify_events(self.read_stream(stream_id))

    @staticmethod
    def _row_to_event(row: dict[str, Any]) -> StoredEvent:
        metadata = EventMetadata(
            actor_id=str(row["actor_id"]), correlation_id=str(row["correlation_id"]),
            causation_id=str(row["causation_id"]), trace_id=str(row["trace_id"]),
            idempotency_key=str(row["idempotency_key"]), organization_id=str(row.get("organization_id") or ""),
            principal_id=str(row.get("principal_id") or ""), subject_user_id=str(row.get("subject_user_id") or ""),
            device_id=str(row.get("device_id") or ""), profile_id=str(row.get("profile_id") or ""),
            installation_id=str(row.get("installation_id") or ""),
        )
        return StoredEvent(
            global_position=int(row["global_position"]), event_id=str(row["event_id"]), stream_id=str(row["stream_id"]),
            stream_version=int(row["stream_version"]), event_type=str(row["event_type"]), occurred_at=_iso(row["occurred_at"]),
            metadata=metadata, payload_type=str(row["payload_type"]), payload=bytes(row["payload"]),
            envelope=bytes(row["envelope"] or b""),
        )
