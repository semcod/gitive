from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from cryptography.fernet import Fernet


_KEY_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")


class KeyringError(RuntimeError):
    pass


@dataclass(frozen=True)
class KeyringStatus:
    active_key_id: str
    key_ids: tuple[str, ...]
    source: str


class MetadataKeyring:
    """Versioned Fernet KEK keyring.

    Production should inject ACCOUNT_INVENTORY_METADATA_KEYRING_JSON from a secret
    manager. The JSON format is::

        {"active_key_id":"k2","keys":{"k1":"...","k2":"..."}}

    ACCOUNT_INVENTORY_METADATA_KEY remains a 0.5 compatibility input and is exposed
    internally as key id ``legacy-v1``. Local development persists a 0600 keyring file.
    """

    ENV_JSON = "ACCOUNT_INVENTORY_METADATA_KEYRING_JSON"
    LEGACY_ENV = "ACCOUNT_INVENTORY_METADATA_KEY"

    def __init__(self, keys: Mapping[str, bytes], active_key_id: str, *, source: str, path: Path | None = None):
        normalized: dict[str, bytes] = {}
        for key_id, value in keys.items():
            if not _KEY_ID.match(str(key_id)):
                raise KeyringError(f"invalid metadata key id: {key_id!r}")
            key = bytes(value)
            try:
                Fernet(key)
            except Exception as exc:
                raise KeyringError(f"metadata key {key_id!r} is not a valid Fernet key") from exc
            normalized[str(key_id)] = key
        if active_key_id not in normalized:
            raise KeyringError("active metadata key id is not present in keyring")
        self._keys = normalized
        self.active_key_id = active_key_id
        self.source = source
        self.path = path

    @classmethod
    def load(cls, root: Path | None, *, require_external: bool = False, require_present: bool = False) -> "MetadataKeyring":
        raw = os.environ.get(cls.ENV_JSON, "").strip()
        if raw:
            try:
                payload = json.loads(raw)
                keys = {str(k): str(v).encode("ascii") for k, v in dict(payload["keys"]).items()}
                active = str(payload["active_key_id"])
            except Exception as exc:
                raise KeyringError(f"{cls.ENV_JSON} is invalid") from exc
            return cls(keys, active, source="environment:keyring")

        legacy = os.environ.get(cls.LEGACY_ENV, "").strip()
        if legacy:
            return cls({"legacy-v1": legacy.encode("ascii")}, "legacy-v1", source="environment:legacy")

        if require_external:
            raise KeyringError(f"{cls.ENV_JSON} is required in external-key mode")
        if root is None:
            if require_present:
                raise KeyringError("metadata keyring is required")
            key = Fernet.generate_key()
            return cls({"local-v1": key}, "local-v1", source="ephemeral")

        root.mkdir(parents=True, exist_ok=True)
        path = root / ".metadata-keyring.json"
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                keys = {str(k): str(v).encode("ascii") for k, v in dict(payload["keys"]).items()}
                active = str(payload["active_key_id"])
            except Exception as exc:
                raise KeyringError("local metadata keyring is invalid") from exc
            return cls(keys, active, source="local:keyring", path=path)

        # 0.5 migration: preserve the previous local key as legacy-v1.
        legacy_path = root / ".metadata.key"
        if legacy_path.exists():
            key = legacy_path.read_bytes().strip()
            ring = cls({"legacy-v1": key}, "legacy-v1", source="local:migrated", path=path)
            ring.persist()
            return ring

        key = Fernet.generate_key()
        ring = cls({"local-v1": key}, "local-v1", source="local:generated", path=path)
        ring.persist()
        return ring

    @property
    def active_key(self) -> bytes:
        return self._keys[self.active_key_id]

    def fernet(self, key_id: str | None = None) -> Fernet:
        resolved = key_id or self.active_key_id
        try:
            return Fernet(self._keys[resolved])
        except KeyError as exc:
            raise KeyringError(f"metadata key id not available: {resolved}") from exc

    def key(self, key_id: str) -> bytes:
        try:
            return self._keys[key_id]
        except KeyError as exc:
            raise KeyringError(f"metadata key id not available: {key_id}") from exc

    def activate(self, key_id: str) -> None:
        if key_id not in self._keys:
            raise KeyringError(f"metadata key id not available: {key_id}")
        self.active_key_id = key_id

    def add(self, key_id: str, key: str | bytes, *, activate: bool = False) -> None:
        if not _KEY_ID.match(key_id):
            raise KeyringError("invalid metadata key id")
        value = key.encode("ascii") if isinstance(key, str) else bytes(key)
        try:
            Fernet(value)
        except Exception as exc:
            raise KeyringError("new metadata key is not a valid Fernet key") from exc
        self._keys[key_id] = value
        if activate:
            self.active_key_id = key_id

    def status(self) -> KeyringStatus:
        return KeyringStatus(self.active_key_id, tuple(sorted(self._keys)), self.source)

    def persist(self) -> None:
        if self.path is None:
            raise KeyringError("this keyring has no local persistence path")
        payload = {
            "schema": "llm-account-inventory.metadata-keyring/v1",
            "active_key_id": self.active_key_id,
            "keys": {key_id: value.decode("ascii") for key_id, value in sorted(self._keys.items())},
        }
        tmp = self.path.with_suffix(".json.tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            os.write(fd, (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8"))
        finally:
            os.close(fd)
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass
