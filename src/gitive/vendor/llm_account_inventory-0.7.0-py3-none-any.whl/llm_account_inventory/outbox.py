from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Protocol

from .postgres import connect, database_url
from .storage import StorageConfig
from .observability import configure, inc, span


class OutboxLeaseLost(RuntimeError):
    pass


class OutboxPublisher(Protocol):
    def publish(self, item: dict[str, Any]) -> None: ...


class JsonlPublisher:
    """Reference publisher for demos/air-gapped deployments.

    It writes only the protobuf envelope encoded as base64 plus event metadata. The
    envelope is already PII-safe by the Event Store contract.
    """

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path).expanduser().resolve() if path else None

    def publish(self, item: dict[str, Any]) -> None:
        record = {
            "outbox_id": item["outbox_id"],
            "event_id": item["event_id"],
            "topic": item["topic"],
            "event_type": item["event_type"],
            "envelope_b64": base64.b64encode(item["envelope"]).decode("ascii"),
        }
        line = json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line)
        else:
            sys.stdout.write(line)
            sys.stdout.flush()


class SQLiteOutbox:
    def __init__(self, path: str | Path):
        import sqlite3
        self.sqlite3 = sqlite3
        self.path = Path(path)

    def _connect(self):
        conn = self.sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = self.sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def claim(self, worker_id: str, *, lease_seconds: int = 120) -> dict[str, Any] | None:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=max(1, int(lease_seconds)))).isoformat()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                conn.execute(
                    """
                    UPDATE event_outbox SET status='pending', worker_id=NULL, lease_until=NULL, updated_at=?
                    WHERE status='publishing' AND lease_until IS NOT NULL AND lease_until<=?
                    """,
                    (now, now),
                )
                row = conn.execute(
                    """
                    SELECT * FROM event_outbox
                    WHERE status='pending' AND available_at<=?
                    ORDER BY outbox_id LIMIT 1
                    """,
                    (now,),
                ).fetchone()
                if not row:
                    conn.execute("COMMIT")
                    return None
                conn.execute(
                    """
                    UPDATE event_outbox SET status='publishing', worker_id=?, lease_until=?,
                        attempts=attempts+1, updated_at=? WHERE outbox_id=?
                    """,
                    (worker_id, lease_until, now, row["outbox_id"]),
                )
                claimed = conn.execute("SELECT * FROM event_outbox WHERE outbox_id=?", (row["outbox_id"],)).fetchone()
                conn.execute("COMMIT")
                return self._row(claimed)
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def complete(self, outbox_id: int, worker_id: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                """
                UPDATE event_outbox SET status='published', published_at=?, lease_until=NULL,
                    worker_id=NULL, updated_at=? WHERE outbox_id=? AND worker_id=? AND status='publishing'
                """,
                (now, now, outbox_id, worker_id),
            )
            if cur.rowcount != 1:
                raise OutboxLeaseLost("cannot complete outbox item without active lease")

    def fail(self, outbox_id: int, worker_id: str, error_code: str) -> dict[str, Any]:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT * FROM event_outbox WHERE outbox_id=? AND worker_id=? AND status='publishing'",
                    (outbox_id, worker_id),
                ).fetchone()
                if not row:
                    raise OutboxLeaseLost("cannot fail outbox item without active lease")
                attempts, max_attempts = int(row["attempts"]), int(row["max_attempts"])
                status = "dead_letter" if attempts >= max_attempts else "pending"
                delay = 0 if status == "dead_letter" else min(300, 2 ** min(attempts, 8))
                available_at = (now_dt + timedelta(seconds=delay)).isoformat()
                conn.execute(
                    """
                    UPDATE event_outbox SET status=?, available_at=?, worker_id=NULL, lease_until=NULL,
                        last_error_code=?, updated_at=? WHERE outbox_id=?
                    """,
                    (status, available_at, error_code, now, outbox_id),
                )
                updated = conn.execute("SELECT * FROM event_outbox WHERE outbox_id=?", (outbox_id,)).fetchone()
                conn.execute("COMMIT")
                return self._row(updated)
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def pending_count(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS n FROM event_outbox WHERE status IN ('pending','publishing')").fetchone()
        return int(row["n"])

    @staticmethod
    def _row(row) -> dict[str, Any]:
        return {
            "outbox_id": int(row["outbox_id"]), "event_id": row["event_id"], "topic": row["topic"],
            "event_type": row["event_type"], "envelope": bytes(row["envelope"]), "status": row["status"],
            "attempts": int(row["attempts"]), "max_attempts": int(row["max_attempts"]),
            "available_at": row["available_at"], "lease_until": row["lease_until"],
            "worker_id": row["worker_id"], "published_at": row["published_at"],
            "last_error_code": row["last_error_code"],
        }


class PostgresOutbox:
    def __init__(self, dsn: str | None = None):
        self.dsn = database_url(dsn)

    def _connect(self, *, autocommit: bool = True):
        return connect(self.dsn, autocommit=autocommit)

    def claim(self, worker_id: str, *, lease_seconds: int = 120) -> dict[str, Any] | None:
        lease_until = datetime.now(timezone.utc) + timedelta(seconds=max(1, int(lease_seconds)))
        with self._connect(autocommit=False) as conn:
            try:
                conn.execute(
                    """
                    UPDATE event_outbox SET status='pending', worker_id=NULL, lease_until=NULL, updated_at=now()
                    WHERE status='publishing' AND lease_until IS NOT NULL AND lease_until<=now()
                    """
                )
                row = conn.execute(
                    """
                    SELECT * FROM event_outbox
                    WHERE status='pending' AND available_at<=now()
                    ORDER BY outbox_id
                    FOR UPDATE SKIP LOCKED
                    LIMIT 1
                    """
                ).fetchone()
                if not row:
                    conn.commit()
                    return None
                updated = conn.execute(
                    """
                    UPDATE event_outbox SET status='publishing', worker_id=%s, lease_until=%s,
                        attempts=attempts+1, updated_at=now() WHERE outbox_id=%s RETURNING *
                    """,
                    (worker_id, lease_until, row["outbox_id"]),
                ).fetchone()
                conn.commit()
                return self._row(updated)
            except Exception:
                conn.rollback()
                raise

    def complete(self, outbox_id: int, worker_id: str) -> None:
        with self._connect() as conn:
            row = conn.execute(
                """
                UPDATE event_outbox SET status='published', published_at=now(), lease_until=NULL,
                    worker_id=NULL, updated_at=now()
                WHERE outbox_id=%s AND worker_id=%s AND status='publishing' RETURNING outbox_id
                """,
                (outbox_id, worker_id),
            ).fetchone()
            if row is None:
                raise OutboxLeaseLost("cannot complete outbox item without active lease")

    def fail(self, outbox_id: int, worker_id: str, error_code: str) -> dict[str, Any]:
        with self._connect(autocommit=False) as conn:
            try:
                row = conn.execute(
                    "SELECT * FROM event_outbox WHERE outbox_id=%s AND worker_id=%s AND status='publishing' FOR UPDATE",
                    (outbox_id, worker_id),
                ).fetchone()
                if not row:
                    raise OutboxLeaseLost("cannot fail outbox item without active lease")
                attempts, max_attempts = int(row["attempts"]), int(row["max_attempts"])
                status = "dead_letter" if attempts >= max_attempts else "pending"
                delay = 0 if status == "dead_letter" else min(300, 2 ** min(attempts, 8))
                updated = conn.execute(
                    """
                    UPDATE event_outbox SET status=%s,
                        available_at=now() + (%s * interval '1 second'), worker_id=NULL,
                        lease_until=NULL, last_error_code=%s, updated_at=now()
                    WHERE outbox_id=%s RETURNING *
                    """,
                    (status, delay, error_code, outbox_id),
                ).fetchone()
                conn.commit()
                return self._row(updated)
            except Exception:
                conn.rollback()
                raise

    def pending_count(self) -> int:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM event_outbox WHERE status IN ('pending','publishing')"
            ).fetchone()
        return int(row["n"])

    @staticmethod
    def _row(row: dict[str, Any]) -> dict[str, Any]:
        def iso(value):
            if value is None:
                return None
            return value.isoformat() if hasattr(value, "isoformat") else str(value)
        return {
            "outbox_id": int(row["outbox_id"]), "event_id": row["event_id"], "topic": row["topic"],
            "event_type": row["event_type"], "envelope": bytes(row["envelope"]), "status": row["status"],
            "attempts": int(row["attempts"]), "max_attempts": int(row["max_attempts"]),
            "available_at": iso(row["available_at"]), "lease_until": iso(row.get("lease_until")),
            "worker_id": row.get("worker_id"), "published_at": iso(row.get("published_at")),
            "last_error_code": row.get("last_error_code"),
        }


def outbox_for(config: StorageConfig):
    if config.backend == "sqlite":
        return SQLiteOutbox(config.data_dir / "events.sqlite3")
    return PostgresOutbox(config.database_url)


class OutboxRelay:
    def __init__(self, config: StorageConfig, publisher: OutboxPublisher, *, worker_id: str | None = None, lease_seconds: int = 120):
        self.repo = outbox_for(config)
        self.publisher = publisher
        self.worker_id = worker_id or f"outbox_{uuid.uuid4().hex}"
        self.lease_seconds = lease_seconds
        self.config = config
        self.metrics = configure("llm-account-inventory-outbox")

    def process_once(self) -> bool:
        item = self.repo.claim(self.worker_id, lease_seconds=self.lease_seconds)
        if not item:
            return False
        with span("account_inventory.outbox.publish", event_id=item["event_id"], event_type=item["event_type"]):
            try:
                self.publisher.publish(item)
                self.repo.complete(item["outbox_id"], self.worker_id)
                inc(self.metrics.outbox_published, self.config.backend)
            except Exception as exc:
                self.repo.fail(item["outbox_id"], self.worker_id, type(exc).__name__)
                inc(self.metrics.outbox_failed, self.config.backend, type(exc).__name__)
        return True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Transactional outbox relay")
    parser.add_argument("--data-dir", type=Path, default=Path(os.environ.get("ACCOUNT_INVENTORY_DATA_DIR", ".inventory-data")))
    parser.add_argument("--output", type=Path, default=None, help="JSONL sink; stdout when omitted")
    parser.add_argument("--worker-id")
    parser.add_argument("--lease-seconds", type=int, default=120)
    parser.add_argument("--poll-seconds", type=float, default=1.0)
    parser.add_argument("--once", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    config = StorageConfig.from_env(args.data_dir)
    relay = OutboxRelay(config, JsonlPublisher(args.output), worker_id=args.worker_id, lease_seconds=args.lease_seconds)
    if args.once:
        relay.process_once()
        return 0
    while True:
        if not relay.process_once():
            time.sleep(max(0.05, args.poll_seconds))


if __name__ == "__main__":
    raise SystemExit(main())
