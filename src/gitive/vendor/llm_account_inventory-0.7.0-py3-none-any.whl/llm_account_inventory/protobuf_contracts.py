from __future__ import annotations

"""Runtime protobuf contracts for CQRS/Event Sourcing.

The human-readable canonical contract is ``contracts/account_inventory.proto``.
This module builds equivalent descriptors without requiring ``protoc`` at
runtime, keeping the wheel portable across workstation environments.
"""

from pathlib import Path
from typing import Any

from google.protobuf import descriptor_pb2, descriptor_pool, json_format, message_factory
from google.protobuf.message import Message

PACKAGE = "subactor.account_inventory.v1"
FILE_NAME = "account_inventory.proto"

_F = descriptor_pb2.FieldDescriptorProto

TYPE = {
    "double": _F.TYPE_DOUBLE,
    "float": _F.TYPE_FLOAT,
    "int64": _F.TYPE_INT64,
    "uint64": _F.TYPE_UINT64,
    "int32": _F.TYPE_INT32,
    "fixed64": _F.TYPE_FIXED64,
    "fixed32": _F.TYPE_FIXED32,
    "bool": _F.TYPE_BOOL,
    "string": _F.TYPE_STRING,
    "bytes": _F.TYPE_BYTES,
    "uint32": _F.TYPE_UINT32,
}


def _scalar(name: str, number: int, kind: str, *, repeated: bool = False) -> tuple:
    return (name, number, TYPE[kind], None, repeated)


def _message(name: str, number: int, type_name: str, *, repeated: bool = False) -> tuple:
    return (name, number, _F.TYPE_MESSAGE, f".{PACKAGE}.{type_name}", repeated)


SCHEMA: dict[str, list[tuple]] = {
    "CommandEnvelope": [
        _scalar("command_id", 1, "string"), _scalar("command_type", 2, "string"),
        _scalar("stream_id", 3, "string"), _scalar("actor_id", 4, "string"),
        _scalar("correlation_id", 5, "string"), _scalar("causation_id", 6, "string"),
        _scalar("trace_id", 7, "string"), _scalar("idempotency_key", 8, "string"),
        _scalar("expected_version", 9, "uint64"), _scalar("payload_type", 10, "string"),
        _scalar("payload", 11, "bytes"), _scalar("organization_id", 12, "string"),
        _scalar("principal_id", 13, "string"), _scalar("subject_user_id", 14, "string"),
        _scalar("device_id", 15, "string"), _scalar("profile_id", 16, "string"),
        _scalar("installation_id", 17, "string"),
    ],
    "EventEnvelope": [
        _scalar("event_id", 1, "string"), _scalar("stream_id", 2, "string"),
        _scalar("stream_version", 3, "uint64"), _scalar("global_position", 4, "uint64"),
        _scalar("event_type", 5, "string"), _scalar("occurred_at", 6, "string"),
        _scalar("actor_id", 7, "string"), _scalar("correlation_id", 8, "string"),
        _scalar("causation_id", 9, "string"), _scalar("trace_id", 10, "string"),
        _scalar("idempotency_key", 11, "string"), _scalar("payload_type", 12, "string"),
        _scalar("payload", 13, "bytes"), _scalar("organization_id", 14, "string"),
        _scalar("principal_id", 15, "string"), _scalar("subject_user_id", 16, "string"),
        _scalar("device_id", 17, "string"), _scalar("profile_id", 18, "string"),
        _scalar("installation_id", 19, "string"),
        _scalar("previous_event_hash", 20, "string"), _scalar("event_hash", 21, "string"),
        _scalar("hash_algorithm", 22, "string"),
    ],
    "QueryEnvelope": [
        _scalar("query_id", 1, "string"), _scalar("query_type", 2, "string"),
        _scalar("actor_id", 3, "string"), _scalar("trace_id", 4, "string"),
        _scalar("payload_type", 5, "string"), _scalar("payload", 6, "bytes"),
        _scalar("organization_id", 7, "string"), _scalar("principal_id", 8, "string"),
    ],
    "EvidenceV1": [
        _scalar("source", 1, "string"), _scalar("kind", 2, "string"),
        _scalar("detail", 3, "string"), _scalar("line", 4, "uint32"),
        _scalar("source_ref", 5, "string"),
    ],
    "RunScanV1": [
        _scalar("scan_id", 1, "string"), _scalar("home", 2, "string"),
        _scalar("platform", 3, "string"), _scalar("deep_home", 4, "bool"),
        _scalar("include_credential_stores", 5, "bool"), _scalar("credential_access", 6, "string"),
        _scalar("allow_manager_network", 7, "bool"), _scalar("max_files", 8, "uint32"),
        _scalar("max_file_bytes", 9, "uint64"), _scalar("max_credential_records", 10, "uint32"),
        _scalar("manager_timeout", 11, "uint32"), _scalar("organization_id", 12, "string"),
        _scalar("principal_id", 13, "string"), _scalar("subject_user_id", 14, "string"),
        _scalar("device_id", 15, "string"), _scalar("profile_id", 16, "string"),
        _scalar("installation_id", 17, "string"),
    ],
    "ScanRequestedV1": [
        # Fields 1-7 are retained for wire compatibility. New writers leave home empty
        # and persist home_ref instead, keeping raw local paths out of the event log.
        _scalar("scan_id", 1, "string"), _scalar("home", 2, "string"),
        _scalar("platform", 3, "string"), _scalar("deep_home", 4, "bool"),
        _scalar("include_credential_stores", 5, "bool"), _scalar("credential_access", 6, "string"),
        _scalar("allow_manager_network", 7, "bool"), _scalar("home_ref", 8, "string"),
        _scalar("organization_id", 9, "string"), _scalar("principal_id", 10, "string"),
        _scalar("subject_user_id", 11, "string"), _scalar("device_id", 12, "string"),
        _scalar("profile_id", 13, "string"), _scalar("installation_id", 14, "string"),
    ],
    "ScanStartedV1": [_scalar("scan_id", 1, "string")],
    "ProviderObservedV1": [
        _scalar("scan_id", 1, "string"), _scalar("provider_id", 2, "string"),
        _scalar("provider_name", 3, "string"), _scalar("category", 4, "string"),
        _scalar("emails", 5, "string", repeated=True), _scalar("identifiers", 6, "string", repeated=True),
        _scalar("clients", 7, "string", repeated=True), _scalar("secret_names", 8, "string", repeated=True),
        _scalar("confidence", 9, "string"), _message("evidence", 10, "EvidenceV1", repeated=True),
        _scalar("identity_ids", 11, "string", repeated=True),
        _scalar("identifier_refs", 12, "string", repeated=True),
    ],
    "CredentialStoreObservedV1": [
        _scalar("scan_id", 1, "string"), _scalar("store_id", 2, "string"),
        _scalar("name", 3, "string"), _scalar("kind", 4, "string"),
        _scalar("deployment", 5, "string"), _scalar("cloud_capable", 6, "bool"),
        _scalar("detected_paths", 7, "string", repeated=True), _scalar("profiles", 8, "string", repeated=True),
        _scalar("account_emails", 9, "string", repeated=True), _scalar("cli", 10, "string"),
        _scalar("cli_available", 11, "bool"), _scalar("access_capability", 12, "string"),
        _scalar("access_attempted", 13, "bool"), _scalar("access_status", 14, "string"),
        _message("evidence", 15, "EvidenceV1", repeated=True), _scalar("warnings", 16, "string", repeated=True),
        _scalar("account_identity_ids", 17, "string", repeated=True),
        _scalar("detected_path_refs", 18, "string", repeated=True),
    ],
    "CredentialReferenceObservedV1": [
        _scalar("scan_id", 1, "string"), _scalar("reference_id", 2, "string"),
        _scalar("reference_uri", 3, "string"), _scalar("store_id", 4, "string"),
        _scalar("record_type", 5, "string"), _scalar("title", 6, "string"),
        _scalar("username", 7, "string"), _scalar("urls", 8, "string", repeated=True),
        _scalar("source", 9, "string"), _scalar("external_id", 10, "string"),
        _scalar("metadata_ref", 11, "string"), _scalar("metadata_fingerprint", 12, "string"),
    ],
    "InventoryObjectStateChangedV1": [
        _scalar("scan_id", 1, "string"), _scalar("object_type", 2, "string"),
        _scalar("object_id", 3, "string"), _scalar("state", 4, "string"),
        _scalar("consecutive_missing_scans", 5, "uint32"),
    ],
    "ScanCompletedV1": [
        _scalar("scan_id", 1, "string"), _scalar("files_considered", 2, "uint32"),
        _scalar("files_scanned", 3, "uint32"), _scalar("files_skipped", 4, "uint32"),
        _scalar("provider_count", 5, "uint32"), _scalar("credential_store_count", 6, "uint32"),
        _scalar("credential_reference_count", 7, "uint32"), _scalar("warnings", 8, "string", repeated=True),
    ],
    "ScanFailedV1": [
        _scalar("scan_id", 1, "string"), _scalar("error_code", 2, "string"),
        _scalar("error_type", 3, "string"), _scalar("safe_message", 4, "string"),
    ],
    "RebuildProjectionV1": [_scalar("projection_name", 1, "string")],
    "EmptyV1": [],
    "ListRequestV1": [_scalar("limit", 1, "uint32"), _scalar("offset", 2, "uint32")],
    "EventsRequestV1": [
        _scalar("stream_id", 1, "string"), _scalar("after_global_position", 2, "uint64"),
        _scalar("limit", 3, "uint32"),
    ],
}


def build_file_descriptor_proto() -> descriptor_pb2.FileDescriptorProto:
    file_proto = descriptor_pb2.FileDescriptorProto()
    file_proto.name = FILE_NAME
    file_proto.package = PACKAGE
    file_proto.syntax = "proto3"
    for message_name, fields in SCHEMA.items():
        msg = file_proto.message_type.add()
        msg.name = message_name
        for field_name, number, field_type, type_name, repeated in fields:
            f = msg.field.add()
            f.name = field_name
            f.number = number
            f.label = _F.LABEL_REPEATED if repeated else _F.LABEL_OPTIONAL
            f.type = field_type
            if type_name:
                f.type_name = type_name
    return file_proto


_POOL = descriptor_pool.DescriptorPool()
_POOL.Add(build_file_descriptor_proto())


def message_class(name: str):
    descriptor = _POOL.FindMessageTypeByName(f"{PACKAGE}.{name}")
    return message_factory.GetMessageClass(descriptor)


MESSAGE_CLASSES = {name: message_class(name) for name in SCHEMA}
globals().update(MESSAGE_CLASSES)


def new_message(name: str, **values: Any) -> Message:
    cls = MESSAGE_CLASSES[name]
    message = cls()
    for key, value in values.items():
        field = message.DESCRIPTOR.fields_by_name.get(key)
        if field is None or value is None:
            continue
        target = getattr(message, key)
        if field.is_repeated:
            if field.message_type:
                for item in value:
                    child = target.add()
                    if isinstance(item, Message):
                        child.CopyFrom(item)
                    else:
                        json_format.ParseDict(item, child, ignore_unknown_fields=False)
            else:
                target.extend(value)
        elif field.message_type:
            if isinstance(value, Message):
                target.CopyFrom(value)
            else:
                json_format.ParseDict(value, target, ignore_unknown_fields=False)
        else:
            setattr(message, key, value)
    return message


def encode(message: Message) -> bytes:
    return message.SerializeToString(deterministic=True)


def decode(message_type: str, payload: bytes) -> Message:
    short = message_type.rsplit(".", 1)[-1]
    if short not in MESSAGE_CLASSES:
        raise KeyError(f"unknown protobuf message type: {message_type}")
    message = MESSAGE_CLASSES[short]()
    message.ParseFromString(payload)
    return message


def full_type(message_or_name: Message | str) -> str:
    if isinstance(message_or_name, str):
        name = message_or_name.rsplit(".", 1)[-1]
    else:
        name = message_or_name.DESCRIPTOR.name
    return f"{PACKAGE}.{name}"


def to_dict(message: Message) -> dict[str, Any]:
    return json_format.MessageToDict(
        message,
        preserving_proto_field_name=True,
        always_print_fields_with_no_presence=True,
    )


def descriptor_set_bytes() -> bytes:
    file_set = descriptor_pb2.FileDescriptorSet()
    file_set.file.add().CopyFrom(build_file_descriptor_proto())
    return file_set.SerializeToString(deterministic=True)


def write_descriptor_set(path: str | Path) -> None:
    Path(path).write_bytes(descriptor_set_bytes())
