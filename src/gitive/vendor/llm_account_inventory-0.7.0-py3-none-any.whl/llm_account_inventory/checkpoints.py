from __future__ import annotations

import base64
import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


class CheckpointError(RuntimeError):
    pass


SCHEMA = "llm-account-inventory.integrity-checkpoint/v1"
ROOT_ALGORITHM = "sha256-stream-head-root-v1"
SIGNATURE_ALGORITHM = "ed25519"


def _canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def _root(stream_heads: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for item in sorted(stream_heads, key=lambda x: str(x["stream_id"])):
        stream_id = str(item["stream_id"]).encode("utf-8")
        version = str(int(item["stream_version"])).encode("ascii")
        event_hash = str(item["event_hash"]).encode("ascii")
        leaf = hashlib.sha256(
            len(stream_id).to_bytes(8, "big") + stream_id
            + len(version).to_bytes(8, "big") + version
            + len(event_hash).to_bytes(8, "big") + event_hash
        ).digest()
        digest.update(leaf)
    return digest.hexdigest()




def _verified_heads(event_store, position: int) -> list[dict[str, Any]]:
    from .integrity import verify_events
    heads = event_store.stream_heads(at_global_position=position)
    verified_heads: list[dict[str, Any]] = []
    for head in heads:
        events = [e for e in event_store.read_stream(str(head["stream_id"])) if e.global_position <= position]
        verified = verify_events(events)
        if not verified.get("ok"):
            raise CheckpointError(
                f"event stream failed integrity verification before checkpoint: {head['stream_id']}:{verified.get('reason')}"
            )
        verified_heads.append({
            "stream_id": head["stream_id"],
            "stream_version": head["stream_version"],
            "event_hash": verified.get("last_event_hash", ""),
            "global_position": head["global_position"],
        })
    return verified_heads

class CheckpointSigner:
    ENV_PRIVATE = "ACCOUNT_INVENTORY_CHECKPOINT_PRIVATE_KEY"
    ENV_PUBLIC = "ACCOUNT_INVENTORY_CHECKPOINT_PUBLIC_KEY"

    def __init__(self, private: Ed25519PrivateKey | None, public: Ed25519PublicKey, *, source: str):
        self.private = private
        self.public = public
        self.source = source

    @classmethod
    def load(cls, root: Path, *, require_private: bool = False, require_external: bool = False) -> "CheckpointSigner":
        private_env = os.environ.get(cls.ENV_PRIVATE, "").strip()
        public_env = os.environ.get(cls.ENV_PUBLIC, "").strip()
        if private_env:
            try:
                private = Ed25519PrivateKey.from_private_bytes(_unb64(private_env))
            except Exception as exc:
                raise CheckpointError(f"{cls.ENV_PRIVATE} must be urlsafe-base64 raw Ed25519 private key") from exc
            return cls(private, private.public_key(), source="environment:private")
        if public_env:
            try:
                public = Ed25519PublicKey.from_public_bytes(_unb64(public_env))
            except Exception as exc:
                raise CheckpointError(f"{cls.ENV_PUBLIC} must be urlsafe-base64 raw Ed25519 public key") from exc
            if require_private:
                raise CheckpointError("checkpoint creation requires the private signing key")
            return cls(None, public, source="environment:public")
        if require_external:
            raise CheckpointError("checkpoint signing/verification key must be provided externally")

        root.mkdir(parents=True, exist_ok=True)
        private_path = root / ".checkpoint-signing.key"
        public_path = root / ".checkpoint-signing.pub"
        if private_path.exists():
            try:
                private = Ed25519PrivateKey.from_private_bytes(_unb64(private_path.read_text(encoding="ascii").strip()))
            except Exception as exc:
                raise CheckpointError("local checkpoint signing key is invalid") from exc
            public = private.public_key()
            return cls(private, public, source="local:private")
        if public_path.exists():
            try:
                public = Ed25519PublicKey.from_public_bytes(_unb64(public_path.read_text(encoding="ascii").strip()))
            except Exception as exc:
                raise CheckpointError("local checkpoint public key is invalid") from exc
            if require_private:
                raise CheckpointError("local checkpoint private key is unavailable")
            return cls(None, public, source="local:public")
        if require_private:
            private = Ed25519PrivateKey.generate()
            private_raw = private.private_bytes(
                serialization.Encoding.Raw,
                serialization.PrivateFormat.Raw,
                serialization.NoEncryption(),
            )
            public_raw = private.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            for path, content in ((private_path, _b64(private_raw)), (public_path, _b64(public_raw))):
                fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600 if path == private_path else 0o644)
                try:
                    os.write(fd, (content + "\n").encode("ascii"))
                finally:
                    os.close(fd)
            return cls(private, private.public_key(), source="local:generated")
        raise CheckpointError("checkpoint public key is unavailable")

    def key_id(self) -> str:
        raw = self.public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return "ed25519:" + hashlib.sha256(raw).hexdigest()[:24]

    def sign(self, body: dict[str, Any]) -> str:
        if self.private is None:
            raise CheckpointError("checkpoint private key is unavailable")
        return _b64(self.private.sign(_canonical_json(body)))

    def verify(self, body: dict[str, Any], signature: str) -> bool:
        try:
            self.public.verify(_unb64(signature), _canonical_json(body))
            return True
        except Exception:
            return False


def checkpoint_dir(data_dir: str | Path) -> Path:
    configured = os.environ.get("ACCOUNT_INVENTORY_CHECKPOINT_DIR", "").strip()
    path = Path(configured).expanduser().resolve() if configured else Path(data_dir).expanduser().resolve() / "integrity-checkpoints"
    path.mkdir(parents=True, exist_ok=True)
    return path


def create_checkpoint(event_store, data_dir: str | Path) -> dict[str, Any]:
    require_external = os.environ.get("ACCOUNT_INVENTORY_REQUIRE_EXTERNAL_CHECKPOINT_KEY", "false").lower() in {"1", "true", "yes", "on"}
    signer = CheckpointSigner.load(Path(data_dir).expanduser().resolve(), require_private=True, require_external=require_external)
    position = int(event_store.max_global_position())
    heads = _verified_heads(event_store, position)
    body = {
        "schema": SCHEMA,
        "checkpoint_id": f"ckpt_{uuid.uuid4().hex}",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "event_global_position": position,
        "stream_count": len(heads),
        "stream_head_root": _root(heads),
        "root_algorithm": ROOT_ALGORITHM,
        "signature_algorithm": SIGNATURE_ALGORITHM,
        "signing_key_id": signer.key_id(),
    }
    document = dict(body)
    document["signature"] = signer.sign(body)
    directory = checkpoint_dir(data_dir)
    path = directory / f"{body['checkpoint_id']}.json"
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    latest = directory / "latest.json"
    latest_tmp = directory / ".latest.json.tmp"
    latest_tmp.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(latest_tmp, latest)
    return {"ok": True, "checkpoint": document, "path": str(path), "signer_source": signer.source}


def verify_checkpoint(event_store, data_dir: str | Path, path: str | Path | None = None) -> dict[str, Any]:
    target = Path(path).expanduser().resolve() if path else checkpoint_dir(data_dir) / "latest.json"
    if not target.exists():
        raise CheckpointError(f"checkpoint not found: {target}")
    document = json.loads(target.read_text(encoding="utf-8"))
    signature = str(document.pop("signature", ""))
    if document.get("schema") != SCHEMA:
        return {"ok": False, "reason": "unsupported_checkpoint_schema", "path": str(target)}
    signer = CheckpointSigner.load(Path(data_dir).expanduser().resolve(), require_private=False)
    if signer.key_id() != document.get("signing_key_id"):
        return {"ok": False, "reason": "signing_key_id_mismatch", "path": str(target)}
    if not signer.verify(document, signature):
        return {"ok": False, "reason": "signature_invalid", "path": str(target)}
    position = int(document["event_global_position"])
    if event_store.max_global_position() < position:
        return {"ok": False, "reason": "event_store_behind_checkpoint", "path": str(target)}
    heads = _verified_heads(event_store, position)
    computed = _root(heads)
    if computed != document.get("stream_head_root"):
        return {
            "ok": False,
            "reason": "stream_head_root_mismatch",
            "path": str(target),
            "expected": document.get("stream_head_root"),
            "actual": computed,
        }
    return {
        "ok": True,
        "path": str(target),
        "checkpoint_id": document["checkpoint_id"],
        "event_global_position": position,
        "stream_count": len(heads),
        "stream_head_root": computed,
        "signing_key_id": document["signing_key_id"],
        "signature_algorithm": SIGNATURE_ALGORITHM,
    }
