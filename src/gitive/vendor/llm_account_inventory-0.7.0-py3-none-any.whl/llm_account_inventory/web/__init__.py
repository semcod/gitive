"""Packaged assets for the read-model-first operations dashboard."""
