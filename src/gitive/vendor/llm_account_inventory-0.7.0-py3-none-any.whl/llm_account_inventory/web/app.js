(() => {
  const content = document.getElementById('content');
  const tokenInput = document.getElementById('token');
  const connectButton = document.getElementById('connect');
  const state = document.getElementById('connectionState');
  const sessionLine = document.getElementById('sessionLine');
  let token = sessionStorage.getItem('inventoryDashboardToken') || '';
  let currentView = 'overview';
  tokenInput.value = token;

  const dslForView = {
    services: 'SHOW SERVICES LIMIT 200', identities: 'SHOW IDENTITIES LIMIT 200',
    stores: 'SHOW CREDENTIAL STORES LIMIT 200', references: 'SHOW CREDENTIAL REFERENCES LIMIT 200',
    scans: 'SHOW SCANS LIMIT 100', events: 'SHOW EVENTS LIMIT 100'
  };

  connectButton.addEventListener('click', async () => {
    token = tokenInput.value.trim();
    sessionStorage.setItem('inventoryDashboardToken', token);
    await connect();
  });

  document.getElementById('nav').addEventListener('click', event => {
    const button = event.target.closest('button[data-view]');
    if (!button) return;
    currentView = button.dataset.view;
    document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('active', x === button));
    renderCurrent();
  });

  async function connect() {
    try {
      const session = await request('/api/session');
      state.textContent = 'Connected'; state.className = 'status ok';
      sessionLine.textContent = `${session.organization_id} · ${session.device_id} · ${session.profile_id} · ${session.mode}`;
      document.querySelectorAll('[data-operator="true"]').forEach(x => { x.hidden = session.mode !== 'operator'; });
      if (session.mode !== 'operator' && currentView === 'events') currentView = 'overview';
      await renderCurrent();
    } catch (error) {
      state.textContent = 'Disconnected'; state.className = 'status';
      renderError(error);
    }
  }

  async function renderCurrent() {
    if (!token) return;
    if (currentView === 'overview') return renderOverview();
    if (currentView === 'system') return renderSystem();
    if (currentView === 'console') return renderConsole();
    const payload = await dsl(dslForView[currentView]);
    renderTable(title(currentView), payload.result?.items || []);
  }

  async function renderOverview() {
    try {
      const [summary, health, services, stores, refs] = await Promise.all([
        dsl('SHOW SUMMARY'), dsl('SHOW HEALTH'), dsl('SHOW SERVICES WHERE active = true LIMIT 200'),
        dsl('SHOW CREDENTIAL STORES WHERE active = true LIMIT 200'), dsl('SHOW CREDENTIAL REFERENCES WHERE active = true LIMIT 500')
      ]);
      const s = summary.result || {}, h = health.result || {};
      const serviceItems = services.result?.items || [], storeItems = stores.result?.items || [], refItems = refs.result?.items || [];
      content.innerHTML = `<div class="cards">
        ${card('Providers', serviceItems.length)}${card('Credential stores', storeItems.length)}${card('Credential refs', refItems.length)}
        ${card('Projection lag', h.projection_lag ?? '—')}${card('Outbox pending', h.outbox_pending ?? '—')}${card('Backend', h.backend || '—')}
      </div>
      <div class="panel"><h2>Inventory health</h2>${kvTable({status:h.status, event_global_position:h.event_global_position, projection_checkpoint:h.projection_checkpoint, latest_scan:s.latest_scan?.scan_id || '—'})}</div>
      <div class="panel"><h2>Active providers</h2>${tableHtml(serviceItems.slice(0, 20))}</div>`;
    } catch (error) { renderError(error); }
  }

  async function renderSystem() {
    try {
      const [health, outbox] = await Promise.all([dsl('SHOW HEALTH'), safeDsl('SHOW OUTBOX')]);
      content.innerHTML = `<div class="panel"><h2>System health</h2>${kvTable(health.result || {})}</div>
        <div class="panel"><h2>Outbox</h2>${kvTable(outbox?.result || {note:'operator mode required'})}</div>`;
    } catch (error) { renderError(error); }
  }

  function renderConsole() {
    content.innerHTML = '';
    const node = document.getElementById('consoleTemplate').content.cloneNode(true);
    content.appendChild(node);
    const form = document.getElementById('consoleForm'), input = document.getElementById('consoleInput'), out = document.getElementById('consoleOutput');
    form.addEventListener('submit', async e => { e.preventDefault(); await runConsole(input.value, out); });
    document.querySelectorAll('.console-actions button').forEach(button => button.addEventListener('click', async () => {
      input.value = button.dataset.dsl; await runConsole(input.value, out);
    }));
  }

  async function runConsole(statement, out) {
    out.textContent = 'Running…';
    try { out.textContent = JSON.stringify(await dsl(statement), null, 2); }
    catch (error) { out.textContent = `ERROR: ${error.message}`; }
  }

  function renderTable(heading, items) { content.innerHTML = `<div class="panel"><h2>${escapeHtml(heading)}</h2>${tableHtml(items)}</div>`; }
  function renderError(error) { content.innerHTML = `<div class="error">${escapeHtml(error.message || String(error))}</div>`; }

  async function dsl(statement) { return request('/api/dsl', {statement}); }
  async function safeDsl(statement) { try { return await dsl(statement); } catch (_) { return null; } }
  async function request(path, body) {
    const response = await fetch(path, {method: body ? 'POST' : 'GET', headers: {'Authorization': `Bearer ${token}`, ...(body ? {'Content-Type':'application/json'} : {})}, body: body ? JSON.stringify(body) : undefined});
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.message || payload.error || `HTTP ${response.status}`);
    return payload;
  }

  function card(label, value) { return `<div class="card"><div class="label">${escapeHtml(label)}</div><div class="value">${escapeHtml(String(value))}</div></div>`; }
  function title(view) { return ({services:'Providers', identities:'Identities', stores:'Credential stores', references:'Credential references', scans:'Scans', events:'Events'})[view] || view; }
  function kvTable(object) { return `<table><tbody>${Object.entries(object).map(([k,v]) => `<tr><th>${escapeHtml(k)}</th><td>${format(v)}</td></tr>`).join('')}</tbody></table>`; }
  function tableHtml(items) {
    if (!items.length) return '<div class="empty">No rows</div>';
    const preferred = ['provider_name','provider_id','value','identity_id','name','store_id','reference_uri','scan_id','status','event_type','global_position','active','last_seen_at','device_id','profile_id'];
    const all = new Set(items.slice(0,50).flatMap(x => Object.keys(x)));
    const keys = [...preferred.filter(k => all.has(k)), ...[...all].filter(k => !preferred.includes(k)).sort()].slice(0,9);
    return `<table><thead><tr>${keys.map(k => `<th>${escapeHtml(k)}</th>`).join('')}</tr></thead><tbody>${items.map(row => `<tr>${keys.map(k => `<td>${format(row[k])}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  }
  function format(value) {
    if (typeof value === 'boolean') return `<span class="badge ${value ? 'good':'bad'}">${value}</span>`;
    if (value === null || value === undefined) return '';
    const text = typeof value === 'object' ? JSON.stringify(value) : String(value);
    return escapeHtml(text.length > 220 ? text.slice(0,217) + '…' : text);
  }
  function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  if (token) connect();
})();
