from __future__ import annotations

import argparse
import json
import uuid
from pathlib import Path

from .cqrs import InventoryCQRS
from .report import as_json, as_jsonl, as_markdown, as_subactor_json
from .scanner import InventoryScanner, ScanOptions
from .dsl_runtime import DslExecutor, DslSessionConfig


def _add_scan_args(scan: argparse.ArgumentParser) -> None:
    scan.add_argument("--home", type=Path, default=Path.home(), help="user home directory or mounted offline profile")
    scan.add_argument("--platform", choices=["auto", "linux", "darwin", "windows", "macos", "mac", "win"], default="auto")
    scan.add_argument("--deep-home", action="store_true", help="also recursively scan text files under the whole home directory")
    scan.add_argument("--max-file-bytes", type=int, default=1_000_000)
    scan.add_argument("--max-files", type=int, default=20_000)
    scan.add_argument(
        "--include-credential-stores",
        action="store_true",
        help="detect password managers, OS keychains and browser password stores without reading credential entries",
    )
    scan.add_argument(
        "--credential-access",
        choices=["none", "metadata"],
        default="none",
        help="explicitly permit non-secret metadata access (never password/token values)",
    )
    scan.add_argument(
        "--allow-manager-network",
        action="store_true",
        help="permit supported manager CLIs to perform metadata operations that may contact their cloud service",
    )
    scan.add_argument("--max-credential-records", type=int, default=200)
    scan.add_argument("--manager-timeout", type=int, default=8)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="llm-accounts",
        description="Read-only inventory of LLM accounts with optional CQRS/Event Sourcing + protobuf persistence.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="direct stateless scan (legacy/simple mode)")
    _add_scan_args(scan)
    scan.add_argument("--format", choices=["json", "jsonl", "markdown", "subactor"], default="json")
    scan.add_argument("--output", type=Path, help="write report to a file instead of stdout")

    cqrs = sub.add_parser("cqrs", help="CQRS/Event Sourcing commands")
    cqrs_sub = cqrs.add_subparsers(dest="cqrs_command", required=True)

    cqrs_scan = cqrs_sub.add_parser("scan", help="execute a scan command and persist protobuf events")
    _add_scan_args(cqrs_scan)
    cqrs_scan.add_argument("--data-dir", type=Path, default=Path(".inventory-data"))
    cqrs_scan.add_argument("--scan-id")
    cqrs_scan.add_argument("--actor-id", default="human:founder")
    cqrs_scan.add_argument("--principal-id")
    cqrs_scan.add_argument("--organization-id", default="organization:local")
    cqrs_scan.add_argument("--subject-user-id")
    cqrs_scan.add_argument("--device-id", default="device:local")
    cqrs_scan.add_argument("--profile-id", default="default")
    cqrs_scan.add_argument("--installation-id", default="installation:local")
    cqrs_scan.add_argument("--expected-version", type=int, default=0)
    cqrs_scan.add_argument("--trace-id")
    cqrs_scan.add_argument("--idempotency-key")

    query = cqrs_sub.add_parser("query", help="read a CQRS projection")
    query.add_argument("view", choices=["summary", "scans", "scan", "identities", "services", "credential_stores", "credential_references", "events"])
    query.add_argument("--data-dir", type=Path, default=Path(".inventory-data"))
    query.add_argument("--scan-id")
    query.add_argument("--stream-id")
    query.add_argument("--after-global-position", type=int, default=0)
    query.add_argument("--after-version", type=int, default=0)
    query.add_argument("--limit", type=int, default=200)
    query.add_argument("--offset", type=int, default=0)

    rebuild = cqrs_sub.add_parser("rebuild", help="rebuild read model from append-only protobuf event log")
    rebuild.add_argument("--data-dir", type=Path, default=Path(".inventory-data"))

    dsl = sub.add_parser("dsl", help="execute or inspect one CQRS/ES DSL statement")
    dsl.add_argument("statement")
    dsl.add_argument("--data-dir", type=Path, default=Path(".inventory-data"))
    dsl.add_argument("--operator", action="store_true")
    dsl.add_argument("--inspect", action="store_true")
    dsl.add_argument("--organization-id", default="organization:local")
    dsl.add_argument("--device-id", default="device:local")
    dsl.add_argument("--profile-id", default="default")
    dsl.add_argument("--allowed-home", action="append", type=Path, default=[])
    dsl.add_argument("--credential-metadata", action="store_true")
    dsl.add_argument("--manager-network", action="store_true")

    shell = sub.add_parser("shell", help="interactive CQRS/ES DSL REPL")
    shell.add_argument("args", nargs=argparse.REMAINDER)

    dashboard = sub.add_parser("dashboard", help="read-model-first web dashboard")
    dashboard.add_argument("args", nargs=argparse.REMAINDER)

    return parser


def main() -> int:
    import sys
    # `shell` and `dashboard` own their option sets. Dispatch before argparse so
    # `llm-accounts shell --data-dir ...` works without a sentinel `--`.
    if len(sys.argv) > 1 and sys.argv[1] in {"shell", "dashboard"}:
        surface = sys.argv[1]
        forwarded = list(sys.argv[2:])
        if forwarded[:1] == ["--"]:
            forwarded = forwarded[1:]
        old = sys.argv
        try:
            if surface == "shell":
                from .shell import main as surface_main
                sys.argv = ["llm-accounts-shell", *forwarded]
            else:
                from .dashboard import main as surface_main
                sys.argv = ["llm-accounts-dashboard", *forwarded]
            return surface_main()
        finally:
            sys.argv = old

    args = build_parser().parse_args()
    if args.command == "scan":
        report = InventoryScanner(
            ScanOptions(
                home=args.home,
                platform=args.platform,
                deep_home=args.deep_home,
                max_file_bytes=args.max_file_bytes,
                max_files=args.max_files,
                include_credential_stores=args.include_credential_stores,
                credential_access=args.credential_access,
                allow_manager_network=args.allow_manager_network,
                max_credential_records=args.max_credential_records,
                manager_timeout=args.manager_timeout,
            )
        ).scan()
        renderer = {"json": as_json, "jsonl": as_jsonl, "markdown": as_markdown, "subactor": as_subactor_json}[args.format]
        output = renderer(report)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(output, encoding="utf-8")
        else:
            print(output, end="")
        return 0

    if args.command == "dsl":
        executor = DslExecutor(DslSessionConfig(
            data_dir=args.data_dir, organization_id=args.organization_id, device_id=args.device_id,
            profile_id=args.profile_id, operator=bool(args.operator), allowed_homes=tuple(args.allowed_home),
            credential_metadata_enabled=bool(args.credential_metadata), manager_network_enabled=bool(args.manager_network),
        ))
        result = executor.inspect(args.statement) if args.inspect else executor.execute(args.statement)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0

    if args.command == "shell":
        from .shell import main as shell_main
        import sys
        old = sys.argv
        try:
            forwarded = list(args.args)
            if forwarded[:1] == ["--"]:
                forwarded = forwarded[1:]
            sys.argv = ["llm-accounts-shell", *forwarded]
            return shell_main()
        finally:
            sys.argv = old

    if args.command == "dashboard":
        from .dashboard import main as dashboard_main
        import sys
        old = sys.argv
        try:
            forwarded = list(args.args)
            if forwarded[:1] == ["--"]:
                forwarded = forwarded[1:]
            sys.argv = ["llm-accounts-dashboard", *forwarded]
            return dashboard_main()
        finally:
            sys.argv = old

    if args.command == "cqrs":
        app = InventoryCQRS(args.data_dir)
        if args.cqrs_command == "scan":
            scan_id = args.scan_id or f"scan_{uuid.uuid4().hex}"
            command = app.build_run_scan_command(
                home=args.home,
                platform=args.platform,
                deep_home=args.deep_home,
                include_credential_stores=args.include_credential_stores,
                credential_access=args.credential_access,
                allow_manager_network=args.allow_manager_network,
                max_files=args.max_files,
                max_file_bytes=args.max_file_bytes,
                max_credential_records=args.max_credential_records,
                manager_timeout=args.manager_timeout,
                scan_id=scan_id,
                actor_id=args.actor_id,
                principal_id=args.principal_id,
                organization_id=args.organization_id,
                subject_user_id=args.subject_user_id,
                device_id=args.device_id,
                profile_id=args.profile_id,
                installation_id=args.installation_id,
                trace_id=args.trace_id,
                idempotency_key=args.idempotency_key,
                expected_version=args.expected_version,
            )
            print(json.dumps(app.execute_command(command), ensure_ascii=False, indent=2))
            return 0
        if args.cqrs_command == "query":
            payload = {
                "scan_id": args.scan_id,
                "stream_id": args.stream_id,
                "after_global_position": args.after_global_position,
                "after_version": args.after_version,
                "limit": args.limit,
                "offset": args.offset,
            }
            print(json.dumps(app.query(args.view, payload), ensure_ascii=False, indent=2))
            return 0
        if args.cqrs_command == "rebuild":
            print(json.dumps(app.rebuild_projection(), ensure_ascii=False, indent=2))
            return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
