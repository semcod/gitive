from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .protobuf_contracts import CommandEnvelope, encode


class QueueLeaseLost(RuntimeError):
    pass


def completed_result_for_storage(result: dict[str, Any]) -> dict[str, Any]:
    """Return a JSON-safe receipt without transient raw scan paths."""
    stored = json.loads(json.dumps(result, ensure_ascii=False))
    read_model = stored.get("read_model")
    if isinstance(read_model, dict):
        read_model.pop("home", None)
    return stored


class SQLiteCommandQueue:
    """Durable single-host command queue with retry/backoff and DLQ state."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS command_queue (
                    command_id TEXT PRIMARY KEY,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    stream_id TEXT NOT NULL,
                    command_type TEXT NOT NULL,
                    envelope BLOB NOT NULL,
                    status TEXT NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    max_attempts INTEGER NOT NULL DEFAULT 5,
                    available_at TEXT NOT NULL,
                    lease_until TEXT,
                    worker_id TEXT,
                    last_error_code TEXT,
                    result_json TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_command_queue_ready ON command_queue(status, available_at, created_at);
                """
            )

    def enqueue(self, command: CommandEnvelope, *, max_attempts: int = 5) -> dict[str, Any]:
        if not command.idempotency_key:
            raise ValueError("idempotency_key is required")
        now = datetime.now(timezone.utc).isoformat()
        raw = encode(command)
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                existing = conn.execute(
                    "SELECT * FROM command_queue WHERE idempotency_key=?", (command.idempotency_key,)
                ).fetchone()
                if existing:
                    conn.execute("COMMIT")
                    return self._row(existing, replay=True)
                conn.execute(
                    """
                    INSERT INTO command_queue(
                        command_id, idempotency_key, stream_id, command_type, envelope, status,
                        attempts, max_attempts, available_at, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, 'queued', 0, ?, ?, ?, ?)
                    """,
                    (
                        command.command_id, command.idempotency_key, command.stream_id,
                        command.command_type, raw, max(1, int(max_attempts)), now, now, now,
                    ),
                )
                row = conn.execute("SELECT * FROM command_queue WHERE command_id=?", (command.command_id,)).fetchone()
                conn.execute("COMMIT")
                return self._row(row, replay=False)
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def claim(self, worker_id: str, *, lease_seconds: int = 120) -> dict[str, Any] | None:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=max(1, int(lease_seconds)))).isoformat()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                # Recover expired processing leases first.
                conn.execute(
                    """
                    UPDATE command_queue
                    SET status='queued', worker_id=NULL, lease_until=NULL, updated_at=?
                    WHERE status='processing' AND lease_until IS NOT NULL AND lease_until<=?
                    """,
                    (now, now),
                )
                row = conn.execute(
                    """
                    SELECT * FROM command_queue
                    WHERE status='queued' AND available_at<=?
                    ORDER BY created_at, command_id LIMIT 1
                    """,
                    (now,),
                ).fetchone()
                if row is None:
                    conn.execute("COMMIT")
                    return None
                conn.execute(
                    """
                    UPDATE command_queue SET status='processing', worker_id=?, lease_until=?,
                        attempts=attempts+1, updated_at=? WHERE command_id=?
                    """,
                    (worker_id, lease_until, now, row["command_id"]),
                )
                claimed = conn.execute(
                    "SELECT * FROM command_queue WHERE command_id=?", (row["command_id"],)
                ).fetchone()
                conn.execute("COMMIT")
                return self._row(claimed)
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def renew(self, command_id: str, worker_id: str, *, lease_seconds: int = 120) -> str:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        lease_until = (now_dt + timedelta(seconds=max(1, int(lease_seconds)))).isoformat()
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT status, worker_id, lease_until FROM command_queue WHERE command_id=?", (command_id,)
            ).fetchone()
            if not row or row["status"] != "processing" or row["worker_id"] != worker_id:
                raise QueueLeaseLost("queue lease is no longer owned by worker")
            if row["lease_until"] and str(row["lease_until"]) <= now:
                raise QueueLeaseLost("queue lease expired")
            conn.execute(
                "UPDATE command_queue SET lease_until=?, updated_at=? WHERE command_id=? AND worker_id=?",
                (lease_until, now, command_id, worker_id),
            )
        return lease_until

    def complete(self, command_id: str, worker_id: str, result: dict[str, Any]) -> None:
        now = datetime.now(timezone.utc).isoformat()
        stored_result = completed_result_for_storage(result)
        with self._connect() as conn:
            cur = conn.execute(
                """
                UPDATE command_queue SET status='completed', result_json=?, envelope=?, lease_until=NULL,
                    updated_at=? WHERE command_id=? AND worker_id=? AND status='processing'
                """,
                (
                    json.dumps(stored_result, ensure_ascii=False, sort_keys=True),
                    b"",
                    now,
                    command_id,
                    worker_id,
                ),
            )
            if cur.rowcount != 1:
                raise QueueLeaseLost("cannot complete command without active queue lease")

    def fail(self, command_id: str, worker_id: str, error_code: str) -> dict[str, Any]:
        now_dt = datetime.now(timezone.utc)
        now = now_dt.isoformat()
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                row = conn.execute(
                    "SELECT * FROM command_queue WHERE command_id=? AND worker_id=? AND status='processing'",
                    (command_id, worker_id),
                ).fetchone()
                if not row:
                    raise QueueLeaseLost("cannot fail command without active queue lease")
                attempts = int(row["attempts"])
                max_attempts = int(row["max_attempts"])
                if attempts >= max_attempts:
                    status = "dead_letter"
                    available_at = now
                else:
                    status = "queued"
                    backoff = min(300, 2 ** min(attempts, 8))
                    available_at = (now_dt + timedelta(seconds=backoff)).isoformat()
                conn.execute(
                    """
                    UPDATE command_queue SET status=?, available_at=?, lease_until=NULL, worker_id=NULL,
                        last_error_code=?, updated_at=? WHERE command_id=?
                    """,
                    (status, available_at, error_code, now, command_id),
                )
                updated = conn.execute("SELECT * FROM command_queue WHERE command_id=?", (command_id,)).fetchone()
                conn.execute("COMMIT")
                return self._row(updated)
            except Exception:
                conn.execute("ROLLBACK")
                raise

    def get(self, *, command_id: str | None = None, idempotency_key: str | None = None) -> dict[str, Any] | None:
        if not command_id and not idempotency_key:
            raise ValueError("command_id or idempotency_key is required")
        col, value = ("command_id", command_id) if command_id else ("idempotency_key", idempotency_key)
        with self._connect() as conn:
            row = conn.execute(f"SELECT * FROM command_queue WHERE {col}=?", (value,)).fetchone()
        return self._row(row) if row else None

    @staticmethod
    def decode_command(row: dict[str, Any]) -> CommandEnvelope:
        msg = CommandEnvelope()
        msg.ParseFromString(row["envelope"])
        return msg

    @staticmethod
    def _row(row: sqlite3.Row, replay: bool | None = None) -> dict[str, Any]:
        result = {
            "command_id": row["command_id"],
            "idempotency_key": row["idempotency_key"],
            "stream_id": row["stream_id"],
            "command_type": row["command_type"],
            "status": row["status"],
            "attempts": int(row["attempts"]),
            "max_attempts": int(row["max_attempts"]),
            "available_at": row["available_at"],
            "lease_until": row["lease_until"],
            "worker_id": row["worker_id"],
            "last_error_code": row["last_error_code"],
            "result": json.loads(row["result_json"]) if row["result_json"] else None,
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "envelope": bytes(row["envelope"]),
        }
        if replay is not None:
            result["idempotent_replay"] = replay
        return result
