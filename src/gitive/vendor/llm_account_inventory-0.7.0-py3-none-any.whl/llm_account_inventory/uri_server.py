from __future__ import annotations

import argparse
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .context import TrustedContextError, TrustedExecutionContext
from .uri_process import ROUTES, UriPolicyError, UriProcessDispatcher

MAX_BODY = 1_000_000


class Handler(BaseHTTPRequestHandler):
    dispatcher: UriProcessDispatcher
    token: str = ""

    server_version = "llm-account-inventory-uri/0.5"

    def do_GET(self) -> None:
        if self.path == "/health":
            configured = bool(self.token)
            healthy = configured
            payload = {
                "ok": configured,
                "service": "llm-account-inventory-uri",
                "routes": len(ROUTES),
                "auth_configured": configured,
            }
            if configured:
                try:
                    event_pos = self.dispatcher.app.events.max_global_position()
                    projection_pos = self.dispatcher.app.projection.checkpoint()
                    payload.update({
                        "backend": self.dispatcher.app.storage.backend,
                        "event_global_position": event_pos,
                        "projection_checkpoint": projection_pos,
                        "projection_lag": max(0, event_pos - projection_pos),
                    })
                except Exception as exc:
                    healthy = False
                    payload.update({"ok": False, "storage_ok": False, "error_type": type(exc).__name__})
            payload["ok"] = healthy
            self._json(200 if healthy else 503, payload)
            return
        if self.path == "/routes":
            if not self._authorized():
                return
            self._json(200, {"ok": True, "routes": [{"uri": uri, "kind": kind} for uri, kind in sorted(ROUTES.items())]})
            return
        self._json(404, {"ok": False, "code": "not_found"})

    def do_POST(self) -> None:
        if self.path != "/run":
            self._json(404, {"ok": False, "code": "not_found"})
            return
        if not self._authorized():
            return
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > MAX_BODY:
            self._json(413, {"ok": False, "code": "request_too_large"})
            return
        try:
            request = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(request, dict):
                raise ValueError("request must be an object")
            uri = str(request.get("uri") or "")
            if uri not in ROUTES:
                raise UriPolicyError("uri_unknown", "URI Process route is not registered")
            context = TrustedExecutionContext.from_headers(self.headers, command_route=ROUTES[uri] == "command")
            result = self.dispatcher.run(request, context)
            status = 202 if result.get("result", {}).get("status") == "accepted" else 200
            self._json(status, result)
        except TrustedContextError as exc:
            self._json(401, {"ok": False, "code": "trusted_context_invalid", "message": str(exc)})
        except UriPolicyError as exc:
            self._json(403, {"ok": False, "code": exc.code, "message": str(exc)})
        except (ValueError, TypeError) as exc:
            self._json(400, {"ok": False, "code": "invalid_request", "message": str(exc)})
        except Exception as exc:
            self._json(500, {"ok": False, "code": "internal_error", "error_type": type(exc).__name__})

    def _authorized(self) -> bool:
        if not self.token:
            self._json(503, {"ok": False, "code": "uri_auth_not_configured"})
            return False
        if self.headers.get("Authorization") == f"Bearer {self.token}":
            return True
        self._json(401, {"ok": False, "code": "unauthorized"})
        return False

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        body = (json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args) -> None:
        print(f"uri-http {self.address_string()} {fmt % args}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="URI Process server for llm-account-inventory")
    parser.add_argument("--host", default=os.environ.get("ACCOUNT_INVENTORY_URI_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("ACCOUNT_INVENTORY_URI_PORT", "8765")))
    parser.add_argument("--data-dir", type=Path, default=Path(os.environ.get("ACCOUNT_INVENTORY_DATA_DIR", ".inventory-data")))
    return parser


def main() -> int:
    args = build_parser().parse_args()
    token = os.environ.get("ACCOUNT_INVENTORY_URI_TOKEN", "").strip()
    if not token:
        raise SystemExit("ACCOUNT_INVENTORY_URI_TOKEN is required; URI server refuses fail-open startup")
    allowed_homes = os.environ.get("ACCOUNT_INVENTORY_ALLOWED_HOMES", "").strip()
    if not allowed_homes:
        raise SystemExit("ACCOUNT_INVENTORY_ALLOWED_HOMES is required for the URI server")
    Handler.dispatcher = UriProcessDispatcher(args.data_dir)
    Handler.token = token
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"llm-account-inventory URI Process listening on http://{args.host}:{args.port}")
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
