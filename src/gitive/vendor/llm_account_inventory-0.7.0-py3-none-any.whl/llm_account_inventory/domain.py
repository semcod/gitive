from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .event_store import StoredEvent

SCAN_REQUESTED = "account_inventory.scan.requested.v1"
SCAN_STARTED = "account_inventory.scan.started.v1"
PROVIDER_OBSERVED = "account_inventory.provider.observed.v1"
CREDENTIAL_STORE_OBSERVED = "account_inventory.credential_store.observed.v1"
CREDENTIAL_REFERENCE_OBSERVED = "account_inventory.credential_reference.observed.v1"
OBJECT_STATE_CHANGED = "account_inventory.object.state_changed.v1"
SCAN_COMPLETED = "account_inventory.scan.completed.v1"
SCAN_FAILED = "account_inventory.scan.failed.v1"


@dataclass
class ScanAggregate:
    scan_id: str
    version: int = 0
    status: str = "new"
    requested: bool = False
    started: bool = False
    completed: bool = False
    failed: bool = False

    def apply(self, event: StoredEvent) -> None:
        self.version = event.stream_version
        if event.event_type == SCAN_REQUESTED:
            self.requested = True
            self.status = "requested"
        elif event.event_type == SCAN_STARTED:
            self.started = True
            self.status = "running"
        elif event.event_type == SCAN_COMPLETED:
            self.completed = True
            self.status = "completed"
        elif event.event_type == SCAN_FAILED:
            self.failed = True
            self.status = "failed"

    @classmethod
    def rehydrate(cls, scan_id: str, events: Iterable[StoredEvent]) -> "ScanAggregate":
        aggregate = cls(scan_id=scan_id)
        for event in events:
            aggregate.apply(event)
        return aggregate
