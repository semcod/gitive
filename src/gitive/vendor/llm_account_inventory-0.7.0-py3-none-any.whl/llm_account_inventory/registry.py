from __future__ import annotations

import json
from dataclasses import dataclass
from importlib.resources import files
from typing import Iterable


@dataclass(frozen=True)
class ProviderSpec:
    id: str
    name: str
    category: str
    env_markers: tuple[str, ...]
    text_markers: tuple[str, ...]
    path_markers: tuple[str, ...]
    clients: tuple[str, ...]


def load_registry() -> list[ProviderSpec]:
    path = files("llm_account_inventory.data").joinpath("providers.json")
    raw = json.loads(path.read_text(encoding="utf-8"))
    return [
        ProviderSpec(
            id=item["id"],
            name=item["name"],
            category=item["category"],
            env_markers=tuple(item.get("env_markers", [])),
            text_markers=tuple(x.lower() for x in item.get("text_markers", [])),
            path_markers=tuple(x.lower() for x in item.get("path_markers", [])),
            clients=tuple(item.get("clients", [])),
        )
        for item in raw
    ]


def specs_for_text(text: str, path_text: str, registry: Iterable[ProviderSpec]) -> list[tuple[ProviderSpec, list[str]]]:
    lowered = text.lower()
    lower_path = path_text.lower().replace("\\", "/")
    env_names = _env_names(text)
    matches: list[tuple[ProviderSpec, list[str]]] = []
    for spec in registry:
        reasons: list[str] = []
        for marker in spec.env_markers:
            if marker in env_names:
                reasons.append(f"env:{marker}")
        for marker in spec.text_markers:
            if marker and marker in lowered:
                reasons.append(f"text:{marker}")
        for marker in spec.path_markers:
            normalized = marker.replace("\\", "/")
            if normalized and normalized in lower_path:
                reasons.append(f"path:{marker}")
        if reasons:
            matches.append((spec, reasons))
    return matches


def _env_names(text: str) -> set[str]:
    names: set[str] = set()
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("export "):
            stripped = stripped[7:].lstrip()
        if "=" in stripped:
            key = stripped.split("=", 1)[0].strip()
        elif ":" in stripped:
            key = stripped.split(":", 1)[0].strip().strip('"\'')
        else:
            continue
        if key and key.replace("_", "").replace("-", "").replace(".", "").isalnum():
            names.add(key.upper())
    return names
