from __future__ import annotations

import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .context import TrustedExecutionContext
from .dsl import CompiledStatement, DslError, FilterExpr, HelpStatement, compile_statement, help_text, parse, statement_to_dict
from .uri_process import ROUTES, UriPolicy, UriProcessDispatcher


VIEWER_ROUTES = (
    "account-inventory://inventory/summary",
    "account-inventory://scans/list",
    "account-inventory://scan/get",
    "account-inventory://identities/list",
    "account-inventory://services/list",
    "account-inventory://credential-stores/list",
    "account-inventory://credential-references/list",
    "account-inventory://commands/status",
    "account-inventory://system/health",
)

OPERATOR_ROUTES = tuple(sorted(ROUTES))


@dataclass(frozen=True)
class DslSessionConfig:
    data_dir: Path
    actor_id: str = "human:founder"
    principal_id: str = "human:founder"
    organization_id: str = "organization:local"
    subject_user_id: str = "human:founder"
    device_id: str = "device:local"
    profile_id: str = "default"
    installation_id: str = "installation:local"
    operator: bool = False
    allowed_homes: tuple[Path, ...] = ()
    credential_metadata_enabled: bool = False
    manager_network_enabled: bool = False

    @property
    def allowed_routes(self) -> tuple[str, ...]:
        return OPERATOR_ROUTES if self.operator else VIEWER_ROUTES


class DslExecutor:
    def __init__(self, config: DslSessionConfig):
        self.config = config
        homes = config.allowed_homes or (Path.home().resolve(),)
        self.dispatcher = UriProcessDispatcher(
            config.data_dir,
            policy=UriPolicy(
                tuple(Path(x).expanduser().resolve() for x in homes),
                credential_metadata_enabled=config.credential_metadata_enabled,
                manager_network_enabled=config.manager_network_enabled,
            ),
        )

    def inspect(self, text: str) -> dict[str, Any]:
        ast = parse(text)
        result: dict[str, Any] = {"ast": statement_to_dict(ast)}
        if isinstance(ast, HelpStatement):
            result["help"] = help_text()
            return result
        compiled = compile_statement(ast)
        result["compiled"] = self._compiled_dict(compiled)
        return result

    def execute(self, text: str) -> dict[str, Any]:
        ast = parse(text)
        if isinstance(ast, HelpStatement):
            return {"ok": True, "type": "help", "text": help_text()}
        compiled = compile_statement(ast)
        if compiled.requires_operator and not self.config.operator:
            raise DslError("statement requires operator mode")
        context = self._context(compiled)
        response = self.dispatcher.run({"uri": compiled.uri, "payload": compiled.payload}, context)
        result = response.get("result") or {}
        if compiled.filters:
            result = _apply_filters(result, compiled.filters)
        return {
            "ok": True,
            "dsl": text.strip(),
            "ast": statement_to_dict(ast),
            "compiled": self._compiled_dict(compiled),
            "trace_id": response.get("trace_id"),
            "result": result,
        }

    def _context(self, compiled: CompiledStatement) -> TrustedExecutionContext:
        token = uuid.uuid4().hex
        command_id = f"dsl_{token}"
        trace_id = f"trace_dsl_{token}"
        if compiled.kind == "command":
            idem = compiled.idempotency_key or f"dsl:{compiled.uri}:{token}"
        else:
            idem = f"query:{trace_id}"
        return TrustedExecutionContext(
            actor_id=self.config.actor_id,
            principal_id=self.config.principal_id,
            organization_id=self.config.organization_id,
            subject_user_id=self.config.subject_user_id,
            device_id=self.config.device_id,
            profile_id=self.config.profile_id,
            installation_id=self.config.installation_id,
            allowed_uri_processes=self.config.allowed_routes,
            trace_id=trace_id,
            correlation_id=command_id,
            causation_id="dsl:root",
            command_id=command_id,
            idempotency_key=idem,
            expected_version=0,
        )

    @staticmethod
    def _compiled_dict(compiled: CompiledStatement) -> dict[str, Any]:
        return {
            "uri": compiled.uri,
            "payload": compiled.payload,
            "kind": compiled.kind,
            "filters": [vars(x) for x in compiled.filters],
            "requires_operator": compiled.requires_operator,
            "irreversible": compiled.irreversible,
        }


def _apply_filters(result: dict[str, Any], filters: tuple[FilterExpr, ...]) -> dict[str, Any]:
    items = result.get("items")
    if not isinstance(items, list):
        if all(_matches(result, f) for f in filters):
            return result
        return {"items": []}
    filtered = [item for item in items if isinstance(item, dict) and all(_matches(item, f) for f in filters)]
    return {**result, "items": filtered, "dsl_filtered_count": len(filtered)}


def _matches(item: dict[str, Any], expr: FilterExpr) -> bool:
    current = _field(item, expr.field)
    expected = expr.value
    if expr.operator == "=":
        return _eq(current, expected)
    if expr.operator == "!=":
        return not _eq(current, expected)
    if expr.operator == "~":
        return str(expected).lower() in _flatten_text(current).lower()
    if expr.operator == "CONTAINS":
        if isinstance(current, (list, tuple, set)):
            return any(_eq(x, expected) for x in current)
        if isinstance(current, dict):
            return str(expected) in current or any(_eq(x, expected) for x in current.values())
        return str(expected).lower() in str(current or "").lower()
    return False


def _field(item: dict[str, Any], path: str) -> Any:
    current: Any = item
    for part in path.split("."):
        if not isinstance(current, dict):
            return None
        if part in current:
            current = current[part]
            continue
        lowered = {str(k).lower(): v for k, v in current.items()}
        current = lowered.get(part.lower())
    return current


def _eq(current: Any, expected: Any) -> bool:
    if isinstance(current, bool) or isinstance(expected, bool):
        return bool(current) is bool(expected)
    if current is None or expected is None:
        return current is expected
    if isinstance(current, (int, float)) and isinstance(expected, (int, float)):
        return current == expected
    return str(current).lower() == str(expected).lower()


def _flatten_text(value: Any) -> str:
    if isinstance(value, dict):
        return " ".join(f"{k} {_flatten_text(v)}" for k, v in value.items())
    if isinstance(value, (list, tuple, set)):
        return " ".join(_flatten_text(x) for x in value)
    return "" if value is None else str(value)
