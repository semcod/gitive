from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .domain import (
    CREDENTIAL_REFERENCE_OBSERVED,
    CREDENTIAL_STORE_OBSERVED,
    OBJECT_STATE_CHANGED,
    PROVIDER_OBSERVED,
    SCAN_COMPLETED,
    SCAN_FAILED,
    SCAN_REQUESTED,
    SCAN_STARTED,
    ScanAggregate,
)
from .event_store import ConcurrencyError, EventMetadata, PendingEvent
from .protobuf_contracts import (
    CommandEnvelope,
    CredentialReferenceObservedV1,
    CredentialStoreObservedV1,
    EvidenceV1,
    InventoryObjectStateChangedV1,
    ProviderObservedV1,
    RunScanV1,
    ScanCompletedV1,
    ScanFailedV1,
    ScanRequestedV1,
    ScanStartedV1,
    decode,
    encode,
    full_type,
    to_dict,
)
from .scanner import InventoryScanner, ScanOptions
from .storage import StorageConfig, event_store, metadata_vault, projection


@dataclass(frozen=True)
class CQRSPaths:
    root: Path
    event_store: Path
    read_model: Path
    metadata_vault: Path

    @classmethod
    def under(cls, root: str | Path) -> "CQRSPaths":
        base = Path(root).expanduser().resolve()
        base.mkdir(parents=True, exist_ok=True)
        return cls(
            base,
            base / "events.sqlite3",
            base / "read-model.sqlite3",
            base / "metadata-vault.sqlite3",
        )


class InventoryCQRS:
    COMMAND_RUN_SCAN = "account_inventory.command.run_scan.v1"

    def __init__(
        self,
        data_dir: str | Path,
        *,
        lease_seconds: int | None = None,
        storage_config: StorageConfig | None = None,
    ):
        self.paths = CQRSPaths.under(data_dir)
        self.storage = storage_config or StorageConfig.from_env(self.paths.root)
        self.events = event_store(self.storage)
        self.vault = metadata_vault(self.storage)
        self.projection = projection(self.storage)
        self.lease_seconds = int(lease_seconds or os.environ.get("ACCOUNT_INVENTORY_COMMAND_LEASE_SECONDS", "120"))
        self.projection.catch_up(self.events)

    def build_run_scan_command(
        self,
        *,
        home: str | Path,
        platform: str = "auto",
        deep_home: bool = False,
        include_credential_stores: bool = False,
        credential_access: str = "none",
        allow_manager_network: bool = False,
        max_files: int = 20_000,
        max_file_bytes: int = 1_000_000,
        max_credential_records: int = 200,
        manager_timeout: int = 8,
        scan_id: str | None = None,
        actor_id: str = "human:founder",
        principal_id: str | None = None,
        organization_id: str = "organization:local",
        subject_user_id: str | None = None,
        device_id: str = "device:local",
        profile_id: str = "default",
        installation_id: str = "installation:local",
        command_id: str | None = None,
        correlation_id: str | None = None,
        causation_id: str = "root",
        trace_id: str | None = None,
        idempotency_key: str | None = None,
        expected_version: int = 0,
    ):
        scan_id = scan_id or f"scan_{uuid.uuid4().hex}"
        command_id = command_id or f"cmd_{uuid.uuid4().hex}"
        correlation_id = correlation_id or command_id
        trace_id = trace_id or f"trace_{uuid.uuid4().hex}"
        idempotency_key = idempotency_key or f"account-inventory:scan:{organization_id}:{device_id}:{scan_id}"
        principal_id = principal_id or actor_id
        subject_user_id = subject_user_id or actor_id
        stream_id = f"account-inventory-scan:{organization_id}:{device_id}:{profile_id}:{scan_id}"
        payload = RunScanV1(
            scan_id=scan_id,
            home=str(Path(home).expanduser().resolve()),
            platform=platform,
            deep_home=deep_home,
            include_credential_stores=include_credential_stores,
            credential_access=credential_access,
            allow_manager_network=allow_manager_network,
            max_files=max_files,
            max_file_bytes=max_file_bytes,
            max_credential_records=max_credential_records,
            manager_timeout=manager_timeout,
            organization_id=organization_id,
            principal_id=principal_id,
            subject_user_id=subject_user_id,
            device_id=device_id,
            profile_id=profile_id,
            installation_id=installation_id,
        )
        return CommandEnvelope(
            command_id=command_id,
            command_type=self.COMMAND_RUN_SCAN,
            stream_id=stream_id,
            actor_id=actor_id,
            correlation_id=correlation_id,
            causation_id=causation_id,
            trace_id=trace_id,
            idempotency_key=idempotency_key,
            expected_version=max(0, int(expected_version)),
            payload_type=full_type(payload),
            payload=encode(payload),
            organization_id=organization_id,
            principal_id=principal_id,
            subject_user_id=subject_user_id,
            device_id=device_id,
            profile_id=profile_id,
            installation_id=installation_id,
        )

    def execute_command(self, command, heartbeat_hook=None) -> dict[str, Any]:
        if command.command_type != self.COMMAND_RUN_SCAN:
            raise ValueError(f"unsupported command type: {command.command_type}")
        if not str(command.idempotency_key).strip():
            raise ValueError("idempotency_key is required")

        claim = self.events.claim_command(
            command_id=command.command_id,
            idempotency_key=command.idempotency_key,
            stream_id=command.stream_id,
            lease_seconds=self.lease_seconds,
        )
        if claim["status"] == "completed":
            existing = claim.get("receipt") or self.events.get_receipt(idempotency_key=command.idempotency_key)
            result = dict(existing["result"] if existing else {})
            result["idempotent_replay"] = True
            return result
        if claim["status"] == "in_progress":
            return {
                "ok": False,
                "status": "in_progress",
                "stream_id": command.stream_id,
                "trace_id": command.trace_id,
                "retryable": True,
                "lease_until": claim.get("lease_until"),
            }

        current_version = self.events.stream_version(command.stream_id)
        if current_version != int(command.expected_version):
            self.events.mark_claim_failed(command_id=command.command_id, idempotency_key=command.idempotency_key)
            raise ConcurrencyError(
                f"command expected_version conflict: expected={int(command.expected_version)} actual={current_version}"
            )

        payload = decode(command.payload_type, bytes(command.payload))
        if payload.DESCRIPTOR.name != "RunScanV1":
            self.events.mark_claim_failed(command_id=command.command_id, idempotency_key=command.idempotency_key)
            raise ValueError(f"unexpected payload: {payload.DESCRIPTOR.full_name}")
        return self._run_scan(command, payload, heartbeat_hook=heartbeat_hook)

    def _heartbeat(self, command, heartbeat_hook=None) -> None:
        self.events.renew_claim(
            command_id=command.command_id,
            idempotency_key=command.idempotency_key,
            lease_seconds=self.lease_seconds,
        )
        if heartbeat_hook:
            heartbeat_hook()

    def _run_scan(self, command, payload, heartbeat_hook=None) -> dict[str, Any]:
        scan_id = payload.scan_id
        stream_id = command.stream_id
        organization_id = command.organization_id or payload.organization_id or "organization:local"
        principal_id = command.principal_id or payload.principal_id or command.actor_id
        subject_user_id = command.subject_user_id or payload.subject_user_id or command.actor_id
        device_id = command.device_id or payload.device_id or "device:local"
        profile_id = command.profile_id or payload.profile_id or "default"
        installation_id = command.installation_id or payload.installation_id or "installation:local"
        metadata = EventMetadata(
            actor_id=command.actor_id or "unknown",
            correlation_id=command.correlation_id or command.command_id,
            causation_id=command.causation_id or "root",
            trace_id=command.trace_id,
            idempotency_key=command.idempotency_key,
            organization_id=organization_id,
            principal_id=principal_id,
            subject_user_id=subject_user_id,
            device_id=device_id,
            profile_id=profile_id,
            installation_id=installation_id,
        )
        aggregate = ScanAggregate.rehydrate(scan_id, self.events.read_stream(stream_id))
        if aggregate.completed:
            self.projection.catch_up(self.events)
            read_model = self.projection.get_scan(scan_id, organization_id)
            return {
                "ok": True,
                "scan_id": scan_id,
                "stream_id": stream_id,
                "status": "completed",
                "trace_id": command.trace_id,
                "idempotent_replay": True,
                "read_model": self._enrich_scan(read_model),
            }

        previous_states = self.projection.object_states(organization_id, device_id, profile_id)
        home_ref = self.vault.put_text("home_path", payload.home, prefix="home", subject_id=subject_user_id)

        if not aggregate.requested:
            requested = ScanRequestedV1(
                scan_id=scan_id,
                home="",
                home_ref=home_ref,
                platform=payload.platform,
                deep_home=payload.deep_home,
                include_credential_stores=payload.include_credential_stores,
                credential_access=payload.credential_access,
                allow_manager_network=payload.allow_manager_network,
                organization_id=organization_id,
                principal_id=principal_id,
                subject_user_id=subject_user_id,
                device_id=device_id,
                profile_id=profile_id,
                installation_id=installation_id,
            )
            self.events.append(
                stream_id,
                aggregate.version,
                [PendingEvent(SCAN_REQUESTED, requested), PendingEvent(SCAN_STARTED, ScanStartedV1(scan_id=scan_id))],
                metadata,
            )
            aggregate = ScanAggregate.rehydrate(scan_id, self.events.read_stream(stream_id))
            self.projection.catch_up(self.events)
        elif not aggregate.started:
            self.events.append(
                stream_id, aggregate.version, [PendingEvent(SCAN_STARTED, ScanStartedV1(scan_id=scan_id))], metadata
            )
            aggregate = ScanAggregate.rehydrate(scan_id, self.events.read_stream(stream_id))
            self.projection.catch_up(self.events)

        try:
            self._heartbeat(command, heartbeat_hook)
            report = InventoryScanner(
                ScanOptions(
                    home=Path(payload.home),
                    platform=payload.platform,
                    deep_home=payload.deep_home,
                    max_file_bytes=int(payload.max_file_bytes or 1_000_000),
                    max_files=int(payload.max_files or 20_000),
                    include_credential_stores=payload.include_credential_stores,
                    credential_access=payload.credential_access or "none",
                    allow_manager_network=payload.allow_manager_network,
                    max_credential_records=int(payload.max_credential_records or 200),
                    manager_timeout=int(payload.manager_timeout or 8),
                ),
                heartbeat=lambda: self._heartbeat(command, heartbeat_hook),
            ).scan()
            pending: list[PendingEvent] = []
            seen: dict[str, set[str]] = {
                "provider": set(), "credential_store": set(), "credential_reference": set()
            }

            for finding in report.findings:
                identity_ids = []
                for email in sorted(finding.emails):
                    identity_id = self.vault.put_text("email", email.lower(), prefix="ident", subject_id=subject_user_id)
                    identity_ids.append(identity_id)
                identifier_refs = [
                    self.vault.put_text("provider_identifier", x, prefix="pid", subject_id=subject_user_id) for x in sorted(finding.identifiers)
                ]
                evidence = [self._evidence(x, subject_user_id) for x in finding.evidence]
                pending.append(PendingEvent(
                    PROVIDER_OBSERVED,
                    ProviderObservedV1(
                        scan_id=scan_id,
                        provider_id=finding.provider_id,
                        provider_name=finding.provider_name,
                        category=finding.category,
                        emails=[],
                        identifiers=[],
                        clients=sorted(finding.clients),
                        secret_names=sorted(finding.secret_names),
                        confidence=finding.confidence,
                        evidence=evidence,
                        identity_ids=identity_ids,
                        identifier_refs=identifier_refs,
                    ),
                ))
                seen["provider"].add(finding.provider_id)

            reference_count = 0
            for store in report.credential_stores:
                evidence = [self._evidence(x, subject_user_id) for x in store.evidence]
                status = "ok" if store.access_ok is True else ("failed" if store.access_ok is False else "not_attempted")
                path_refs = [self.vault.put_text("credential_store_path", x, prefix="path", subject_id=subject_user_id) for x in sorted(store.detected_paths)]
                account_emails = set(store.account_emails)
                for record in store.records:
                    if record.username and "@" in record.username:
                        account_emails.add(record.username)
                account_ids = [
                    self.vault.put_text("email", email.lower(), prefix="ident", subject_id=subject_user_id) for email in sorted(account_emails)
                ]
                pending.append(PendingEvent(
                    CREDENTIAL_STORE_OBSERVED,
                    CredentialStoreObservedV1(
                        scan_id=scan_id,
                        store_id=store.store_id,
                        name=store.name,
                        kind=store.kind,
                        deployment=store.deployment,
                        cloud_capable=store.cloud_capable,
                        detected_paths=[],
                        profiles=sorted(store.profiles),
                        account_emails=[],
                        cli=store.cli or "",
                        cli_available=store.cli_available,
                        access_capability=store.access_capability,
                        access_attempted=store.access_attempted,
                        access_status=status,
                        evidence=evidence,
                        warnings=list(store.warnings),
                        account_identity_ids=account_ids,
                        detected_path_refs=path_refs,
                    ),
                ))
                seen["credential_store"].add(store.store_id)
                for record in store.records:
                    metadata_record = {
                        "record_type": record.record_type,
                        "title": record.title,
                        "username": record.username,
                        "urls": list(record.urls),
                        "source": record.source,
                        "external_id": record.external_id,
                    }
                    reference_id, reference_uri = self.vault.credential_reference(store.store_id, metadata_record, subject_id=subject_user_id)
                    pending.append(PendingEvent(
                        CREDENTIAL_REFERENCE_OBSERVED,
                        CredentialReferenceObservedV1(
                            scan_id=scan_id,
                            reference_id=reference_id,
                            reference_uri=reference_uri,
                            store_id=store.store_id,
                            record_type=record.record_type,
                            title="",
                            username="",
                            urls=[],
                            source="",
                            external_id="",
                            metadata_ref=reference_id,
                            metadata_fingerprint=reference_id.removeprefix("cref_"),
                        ),
                    ))
                    seen["credential_reference"].add(reference_id)
                    reference_count += 1

            for object_type, objects in previous_states.items():
                for object_id, state in objects.items():
                    if object_id in seen[object_type]:
                        continue
                    pending.append(PendingEvent(
                        OBJECT_STATE_CHANGED,
                        InventoryObjectStateChangedV1(
                            scan_id=scan_id,
                            object_type=object_type,
                            object_id=object_id,
                            state="missing",
                            consecutive_missing_scans=int(state["consecutive_missing_scans"]) + 1,
                        ),
                    ))

            pending.append(PendingEvent(
                SCAN_COMPLETED,
                ScanCompletedV1(
                    scan_id=scan_id,
                    files_considered=report.files_considered,
                    files_scanned=report.files_scanned,
                    files_skipped=report.files_skipped,
                    provider_count=len(report.findings),
                    credential_store_count=len(report.credential_stores),
                    credential_reference_count=reference_count,
                    warnings=list(report.warnings),
                ),
            ))
            result = {
                "ok": True,
                "scan_id": scan_id,
                "stream_id": stream_id,
                "status": "completed",
                "trace_id": command.trace_id,
                "organization_id": organization_id,
                "device_id": device_id,
                "profile_id": profile_id,
                "provider_count": len(report.findings),
                "credential_store_count": len(report.credential_stores),
                "credential_reference_count": reference_count,
                "secret_values_exported": False,
                "pii_in_event_log": False,
                "protobuf": {
                    "command_type": command.command_type,
                    "payload_type": command.payload_type,
                    "event_contract": "subactor.account_inventory.v1.EventEnvelope",
                },
            }
            self._heartbeat(command, heartbeat_hook)
            current_version = self.events.stream_version(stream_id)
            self.events.append(
                stream_id,
                current_version,
                pending,
                metadata,
                command_id=command.command_id,
                command_result=result,
            )
            self.projection.catch_up(self.events)
            result["read_model"] = self._enrich_scan(self.projection.get_scan(scan_id, organization_id))
            return result
        except Exception as exc:
            current_version = self.events.stream_version(stream_id)
            try:
                self.events.append(
                    stream_id,
                    current_version,
                    [PendingEvent(
                        SCAN_FAILED,
                        ScanFailedV1(
                            scan_id=scan_id,
                            error_code="scan_failed",
                            error_type=type(exc).__name__,
                            safe_message="inventory scan failed; inspect local redacted diagnostics",
                        ),
                    )],
                    metadata,
                )
            finally:
                self.events.mark_claim_failed(command_id=command.command_id, idempotency_key=command.idempotency_key)
                self.projection.catch_up(self.events)
            raise

    def _evidence(self, item, subject_id: str) -> Any:
        source_ref = self.vault.put_text("evidence_source", item.source, prefix="src", subject_id=subject_id) if item.source else ""
        return EvidenceV1(source="", source_ref=source_ref, kind=item.kind, detail=item.detail, line=int(item.line or 0))

    def rebuild_projection(self) -> dict[str, Any]:
        position = self.projection.rebuild(self.events)
        return {"ok": True, "projection": self.projection.NAME, "checkpoint": position}

    def blue_green_rebuild_projection(self) -> dict[str, Any]:
        from .projection_manager import blue_green_rebuild, build_projection
        result = blue_green_rebuild(self.storage, self.events, self.projection)
        # The current process explicitly reconnects to the newly selected projection.
        self.projection = build_projection(self.storage, result["active_slot"])
        result["restart_required_for_existing_processes"] = False
        return result

    def create_integrity_checkpoint(self) -> dict[str, Any]:
        from .checkpoints import create_checkpoint
        return create_checkpoint(self.events, self.paths.root)

    def verify_integrity_checkpoint(self, path: str | Path | None = None) -> dict[str, Any]:
        from .checkpoints import verify_checkpoint
        return verify_checkpoint(self.events, self.paths.root, path)

    def metadata_keyring_status(self) -> dict[str, Any]:
        return self.vault.keyring_status()

    def rotate_metadata_key(self, key_id: str) -> dict[str, Any]:
        if not str(key_id).strip():
            raise ValueError("key_id is required")
        return self.vault.rotate_to_key_id(str(key_id).strip(), persist_local_keyring=True)

    def crypto_shred_subject(self, subject_id: str) -> dict[str, Any]:
        if not str(subject_id).strip():
            raise ValueError("subject_id is required")
        return self.vault.crypto_shred_subject(str(subject_id).strip())

    def query(
        self,
        query_type: str,
        payload: dict[str, Any] | None = None,
        *,
        organization_id: str | None = None,
    ) -> dict[str, Any]:
        payload = payload or {}
        self.projection.catch_up(self.events)
        limit = int(payload.get("limit", 200))
        offset = int(payload.get("offset", 0))
        if query_type == "summary":
            result = self.projection.summary(organization_id)
            if result.get("latest_scan"):
                result["latest_scan"] = self._enrich_scan(result["latest_scan"])
            return result
        if query_type == "scans":
            return {"items": [self._enrich_scan(x) for x in self.projection.list_scans(limit, offset, organization_id)]}
        if query_type == "scan":
            return {"item": self._enrich_scan(self.projection.get_scan(str(payload.get("scan_id") or ""), organization_id))}
        if query_type == "identities":
            items = self.projection.list_identities(limit, offset, organization_id)
            for item in items:
                item["value"] = self.vault.resolve_text(item["identity_id"])
            return {"items": items}
        if query_type == "services":
            items = self.projection.list_services(limit, offset, organization_id)
            for item in items:
                item["emails"] = [x for x in (self.vault.resolve_text(i) for i in item.pop("identity_ids")) if x]
            return {"items": items}
        if query_type == "credential_stores":
            items = self.projection.list_credential_stores(limit, offset, organization_id)
            for item in items:
                item["account_emails"] = [
                    x for x in (self.vault.resolve_text(i) for i in item.pop("account_identity_ids")) if x
                ]
                item["detected_paths"] = [
                    x for x in (self.vault.resolve_text(i) for i in item.pop("detected_path_refs")) if x
                ]
            return {"items": items}
        if query_type == "credential_references":
            items = self.projection.list_credential_references(limit, offset, organization_id)
            for item in items:
                metadata = self.vault.get(item["metadata_ref"]) or {}
                item.update({
                    "title": metadata.get("title"), "username": metadata.get("username"),
                    "urls": metadata.get("urls") or [], "source": metadata.get("source"),
                    "external_id": metadata.get("external_id"),
                })
            return {"items": items}
        if query_type == "events":
            stream_id = str(payload.get("stream_id") or "")
            if stream_id:
                events = self.events.read_stream(stream_id, after_version=int(payload.get("after_version", 0)))[:limit]
            else:
                events = self.events.read_all(
                    after_global_position=int(payload.get("after_global_position", 0)), limit=limit
                )
            if organization_id:
                events = [x for x in events if x.metadata.organization_id == organization_id]
            return {"items": [self._event_to_dict(event) for event in events]}
        raise ValueError(f"unsupported query type: {query_type}")

    def _enrich_scan(self, item: dict[str, Any] | None) -> dict[str, Any] | None:
        if not item:
            return item
        item = dict(item)
        item["home"] = self.vault.resolve_text(item.get("home_ref") or "")
        return item

    @staticmethod
    def _event_to_dict(event) -> dict[str, Any]:
        payload = decode(event.payload_type, event.payload)
        return {
            "global_position": event.global_position,
            "event_id": event.event_id,
            "stream_id": event.stream_id,
            "stream_version": event.stream_version,
            "event_type": event.event_type,
            "occurred_at": event.occurred_at,
            "actor_id": event.metadata.actor_id,
            "principal_id": event.metadata.principal_id,
            "organization_id": event.metadata.organization_id,
            "subject_user_id": event.metadata.subject_user_id,
            "device_id": event.metadata.device_id,
            "profile_id": event.metadata.profile_id,
            "installation_id": event.metadata.installation_id,
            "correlation_id": event.metadata.correlation_id,
            "causation_id": event.metadata.causation_id,
            "trace_id": event.metadata.trace_id,
            "idempotency_key": event.metadata.idempotency_key,
            "payload_type": event.payload_type,
            "payload": to_dict(payload),
            "wire_format": "application/x-protobuf",
        }
