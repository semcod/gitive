from __future__ import annotations

import re

from .postgres import PgCompatConnection, connect, database_url
from .projections import InventoryProjection


_SCHEMA = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,62}$")


class PostgresInventoryProjection(InventoryProjection):
    """PostgreSQL-backed inventory projection, optionally isolated in a schema."""

    def __init__(self, dsn: str | None = None, *, schema: str = "public"):
        self.dsn = database_url(dsn)
        if not _SCHEMA.match(schema):
            raise ValueError("invalid projection schema")
        self.schema = schema
        import threading
        self._lock = threading.RLock()
        if schema != "public":
            with connect(self.dsn, autocommit=True) as conn:
                conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{schema}"')
        self._init_db()

    def _connect(self) -> PgCompatConnection:
        raw = connect(self.dsn, autocommit=True)
        if self.schema != "public":
            raw.execute(f'SET search_path TO "{self.schema}", public')
        return PgCompatConnection(raw)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS projection_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            row = conn.execute("SELECT value FROM projection_meta WHERE key='schema_version'").fetchone()
            if row is not None and int(row["value"]) != self.SCHEMA_VERSION:
                self._drop_read_tables(conn)
            self._create_tables(conn)
            conn.execute(
                "INSERT OR REPLACE INTO projection_meta(key, value) VALUES ('schema_version', ?)",
                (str(self.SCHEMA_VERSION),),
            )
            conn.execute(
                "INSERT OR IGNORE INTO projection_checkpoint(projection_name, global_position) VALUES (?, 0)",
                (self.NAME,),
            )
