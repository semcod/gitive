from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any

from .domain import (
    CREDENTIAL_REFERENCE_OBSERVED,
    CREDENTIAL_STORE_OBSERVED,
    OBJECT_STATE_CHANGED,
    PROVIDER_OBSERVED,
    SCAN_COMPLETED,
    SCAN_FAILED,
    SCAN_REQUESTED,
    SCAN_STARTED,
)
from .event_store import SQLiteEventStore, StoredEvent
from .protobuf_contracts import decode


class InventoryProjection:
    """Rebuildable CQRS read model. Raw PII is intentionally not stored here."""

    NAME = "inventory-v2"
    SCHEMA_VERSION = 2

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute("CREATE TABLE IF NOT EXISTS projection_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            row = conn.execute("SELECT value FROM projection_meta WHERE key='schema_version'").fetchone()
            if row is not None and int(row["value"]) != self.SCHEMA_VERSION:
                self._drop_read_tables(conn)
            elif row is None:
                # 0.3 had no projection_meta. Rebuildable read model => migrate destructively.
                legacy = conn.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='scan_runs'"
                ).fetchone()
                if legacy:
                    self._drop_read_tables(conn)
            self._create_tables(conn)
            conn.execute(
                "INSERT OR REPLACE INTO projection_meta(key, value) VALUES ('schema_version', ?)",
                (str(self.SCHEMA_VERSION),),
            )
            conn.execute(
                "INSERT OR IGNORE INTO projection_checkpoint(projection_name, global_position) VALUES (?, 0)",
                (self.NAME,),
            )

    @staticmethod
    def _drop_read_tables(conn: sqlite3.Connection) -> None:
        for table in (
            "projection_checkpoint", "scan_runs", "services", "scan_services", "identities",
            "identity_service_links", "secret_indicators", "evidence", "credential_stores",
            "scan_credential_stores", "credential_store_accounts", "credential_references",
            "scan_credential_references",
        ):
            conn.execute(f"DROP TABLE IF EXISTS {table}")

    def _create_tables(self, conn: sqlite3.Connection) -> None:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS projection_checkpoint (
                projection_name TEXT PRIMARY KEY,
                global_position INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS scan_runs (
                scan_id TEXT PRIMARY KEY,
                stream_id TEXT NOT NULL,
                status TEXT NOT NULL,
                home_ref TEXT,
                platform TEXT,
                deep_home INTEGER NOT NULL DEFAULT 0,
                include_credential_stores INTEGER NOT NULL DEFAULT 0,
                credential_access TEXT,
                allow_manager_network INTEGER NOT NULL DEFAULT 0,
                actor_id TEXT,
                principal_id TEXT,
                organization_id TEXT NOT NULL,
                subject_user_id TEXT,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                installation_id TEXT,
                trace_id TEXT,
                requested_at TEXT,
                started_at TEXT,
                completed_at TEXT,
                failed_at TEXT,
                files_considered INTEGER NOT NULL DEFAULT 0,
                files_scanned INTEGER NOT NULL DEFAULT 0,
                files_skipped INTEGER NOT NULL DEFAULT 0,
                provider_count INTEGER NOT NULL DEFAULT 0,
                credential_store_count INTEGER NOT NULL DEFAULT 0,
                credential_reference_count INTEGER NOT NULL DEFAULT 0,
                warnings_json TEXT NOT NULL DEFAULT '[]',
                error_code TEXT,
                error_type TEXT,
                safe_message TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_scan_scope ON scan_runs(organization_id, device_id, profile_id, requested_at);

            CREATE TABLE IF NOT EXISTS services (
                organization_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                provider_id TEXT NOT NULL,
                provider_name TEXT NOT NULL,
                category TEXT NOT NULL,
                confidence TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                consecutive_missing_scans INTEGER NOT NULL DEFAULT 0,
                last_scan_id TEXT NOT NULL,
                last_global_position INTEGER NOT NULL,
                PRIMARY KEY(organization_id, device_id, profile_id, provider_id)
            );
            CREATE TABLE IF NOT EXISTS scan_services (
                scan_id TEXT NOT NULL,
                provider_id TEXT NOT NULL,
                provider_name TEXT NOT NULL,
                category TEXT NOT NULL,
                confidence TEXT NOT NULL,
                identifier_refs_json TEXT NOT NULL,
                clients_json TEXT NOT NULL,
                PRIMARY KEY(scan_id, provider_id)
            );
            CREATE TABLE IF NOT EXISTS identities (
                identity_id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                last_scan_id TEXT NOT NULL,
                last_global_position INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS identity_service_links (
                identity_id TEXT NOT NULL,
                organization_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                provider_id TEXT NOT NULL,
                relation TEXT NOT NULL,
                confidence TEXT NOT NULL,
                last_scan_id TEXT NOT NULL,
                PRIMARY KEY(identity_id, organization_id, device_id, profile_id, provider_id, relation)
            );
            CREATE TABLE IF NOT EXISTS secret_indicators (
                organization_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                provider_id TEXT NOT NULL,
                name TEXT NOT NULL,
                value_exported INTEGER NOT NULL DEFAULT 0,
                last_scan_id TEXT NOT NULL,
                PRIMARY KEY(organization_id, device_id, profile_id, provider_id, name)
            );
            CREATE TABLE IF NOT EXISTS evidence (
                event_id TEXT NOT NULL,
                ordinal INTEGER NOT NULL,
                subject_type TEXT NOT NULL,
                subject_id TEXT NOT NULL,
                source_ref TEXT NOT NULL,
                kind TEXT NOT NULL,
                detail TEXT NOT NULL,
                line INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(event_id, ordinal)
            );

            CREATE TABLE IF NOT EXISTS credential_stores (
                organization_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                store_id TEXT NOT NULL,
                name TEXT NOT NULL,
                kind TEXT NOT NULL,
                deployment TEXT NOT NULL,
                cloud_capable INTEGER NOT NULL,
                cli TEXT,
                cli_available INTEGER NOT NULL,
                access_capability TEXT NOT NULL,
                access_attempted INTEGER NOT NULL,
                access_status TEXT NOT NULL,
                detected_path_refs_json TEXT NOT NULL,
                profiles_json TEXT NOT NULL,
                warnings_json TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                consecutive_missing_scans INTEGER NOT NULL DEFAULT 0,
                last_scan_id TEXT NOT NULL,
                last_global_position INTEGER NOT NULL,
                PRIMARY KEY(organization_id, device_id, profile_id, store_id)
            );
            CREATE TABLE IF NOT EXISTS scan_credential_stores (
                scan_id TEXT NOT NULL,
                store_id TEXT NOT NULL,
                PRIMARY KEY(scan_id, store_id)
            );
            CREATE TABLE IF NOT EXISTS credential_store_accounts (
                organization_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                store_id TEXT NOT NULL,
                identity_id TEXT NOT NULL,
                last_scan_id TEXT NOT NULL,
                PRIMARY KEY(organization_id, device_id, profile_id, store_id, identity_id)
            );
            CREATE TABLE IF NOT EXISTS credential_references (
                organization_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                profile_id TEXT NOT NULL,
                reference_id TEXT NOT NULL,
                reference_uri TEXT NOT NULL,
                store_id TEXT NOT NULL,
                record_type TEXT NOT NULL,
                metadata_ref TEXT NOT NULL,
                metadata_fingerprint TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                consecutive_missing_scans INTEGER NOT NULL DEFAULT 0,
                last_scan_id TEXT NOT NULL,
                last_global_position INTEGER NOT NULL,
                secret_value_present INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(organization_id, device_id, profile_id, reference_id)
            );
            CREATE TABLE IF NOT EXISTS scan_credential_references (
                scan_id TEXT NOT NULL,
                reference_id TEXT NOT NULL,
                PRIMARY KEY(scan_id, reference_id)
            );
            """
        )

    def checkpoint(self) -> int:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT global_position FROM projection_checkpoint WHERE projection_name=?",
                (self.NAME,),
            ).fetchone()
        return int(row["global_position"] if row else 0)

    def catch_up(self, event_store: SQLiteEventStore, *, batch_size: int = 1000) -> int:
        with self._lock:
            while True:
                checkpoint = self.checkpoint()
                events = event_store.read_all(after_global_position=checkpoint, limit=batch_size)
                if not events:
                    return checkpoint
                with self._connect() as conn:
                    conn.execute("BEGIN IMMEDIATE")
                    try:
                        for event in events:
                            self._apply(conn, event)
                            conn.execute(
                                "UPDATE projection_checkpoint SET global_position=? WHERE projection_name=?",
                                (event.global_position, self.NAME),
                            )
                        conn.execute("COMMIT")
                    except Exception:
                        conn.execute("ROLLBACK")
                        raise
                if len(events) < batch_size:
                    return events[-1].global_position

    def rebuild(self, event_store: SQLiteEventStore) -> int:
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                for table in (
                    "scan_runs", "services", "scan_services", "identities", "identity_service_links",
                    "secret_indicators", "evidence", "credential_stores", "scan_credential_stores",
                    "credential_store_accounts", "credential_references", "scan_credential_references",
                ):
                    conn.execute(f"DELETE FROM {table}")
                conn.execute(
                    "UPDATE projection_checkpoint SET global_position=0 WHERE projection_name=?",
                    (self.NAME,),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
        return self.catch_up(event_store)

    def _scope(self, event: StoredEvent) -> tuple[str, str, str]:
        return (
            event.metadata.organization_id or "organization:legacy",
            event.metadata.device_id or "device:legacy",
            event.metadata.profile_id or "default",
        )

    def _apply(self, conn: sqlite3.Connection, event: StoredEvent) -> None:
        payload = decode(event.payload_type, event.payload)
        org, device, profile = self._scope(event)
        if event.event_type == SCAN_REQUESTED:
            home_ref = getattr(payload, "home_ref", "") or ""
            conn.execute(
                """
                INSERT INTO scan_runs(
                    scan_id, stream_id, status, home_ref, platform, deep_home,
                    include_credential_stores, credential_access, allow_manager_network,
                    actor_id, principal_id, organization_id, subject_user_id, device_id,
                    profile_id, installation_id, trace_id, requested_at
                ) VALUES (?, ?, 'requested', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(scan_id) DO UPDATE SET
                    status=excluded.status, home_ref=excluded.home_ref, platform=excluded.platform,
                    actor_id=excluded.actor_id, principal_id=excluded.principal_id,
                    organization_id=excluded.organization_id, subject_user_id=excluded.subject_user_id,
                    device_id=excluded.device_id, profile_id=excluded.profile_id,
                    installation_id=excluded.installation_id, trace_id=excluded.trace_id,
                    requested_at=excluded.requested_at
                """,
                (
                    payload.scan_id, event.stream_id, home_ref, payload.platform,
                    int(payload.deep_home), int(payload.include_credential_stores), payload.credential_access,
                    int(payload.allow_manager_network), event.metadata.actor_id, event.metadata.principal_id,
                    org, event.metadata.subject_user_id, device, profile, event.metadata.installation_id,
                    event.metadata.trace_id, event.occurred_at,
                ),
            )
        elif event.event_type == SCAN_STARTED:
            conn.execute(
                "UPDATE scan_runs SET status='running', started_at=? WHERE scan_id=?",
                (event.occurred_at, payload.scan_id),
            )
        elif event.event_type == PROVIDER_OBSERVED:
            conn.execute(
                """
                INSERT INTO services(
                    organization_id, device_id, profile_id, provider_id, provider_name, category,
                    confidence, first_seen_at, last_seen_at, active, consecutive_missing_scans,
                    last_scan_id, last_global_position
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?)
                ON CONFLICT(organization_id, device_id, profile_id, provider_id) DO UPDATE SET
                    provider_name=excluded.provider_name, category=excluded.category,
                    confidence=excluded.confidence, last_seen_at=excluded.last_seen_at,
                    active=1, consecutive_missing_scans=0, last_scan_id=excluded.last_scan_id,
                    last_global_position=excluded.last_global_position
                """,
                (
                    org, device, profile, payload.provider_id, payload.provider_name, payload.category,
                    payload.confidence, event.occurred_at, event.occurred_at, payload.scan_id,
                    event.global_position,
                ),
            )
            identifier_refs = list(getattr(payload, "identifier_refs", [])) or [f"legacy:{x}" for x in payload.identifiers]
            conn.execute(
                """
                INSERT INTO scan_services(scan_id, provider_id, provider_name, category, confidence, identifier_refs_json, clients_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(scan_id, provider_id) DO UPDATE SET
                    provider_name=excluded.provider_name, category=excluded.category,
                    confidence=excluded.confidence, identifier_refs_json=excluded.identifier_refs_json,
                    clients_json=excluded.clients_json
                """,
                (
                    payload.scan_id, payload.provider_id, payload.provider_name, payload.category,
                    payload.confidence, json.dumps(identifier_refs, ensure_ascii=False),
                    json.dumps(list(payload.clients), ensure_ascii=False),
                ),
            )
            identity_ids = list(getattr(payload, "identity_ids", [])) or [f"legacy-email:{x.lower()}" for x in payload.emails]
            for identity_id in identity_ids:
                conn.execute(
                    """
                    INSERT INTO identities(identity_id, kind, first_seen_at, last_seen_at, last_scan_id, last_global_position)
                    VALUES (?, 'email', ?, ?, ?, ?)
                    ON CONFLICT(identity_id) DO UPDATE SET
                        last_seen_at=excluded.last_seen_at, last_scan_id=excluded.last_scan_id,
                        last_global_position=excluded.last_global_position
                    """,
                    (identity_id, event.occurred_at, event.occurred_at, payload.scan_id, event.global_position),
                )
                conn.execute(
                    """
                    INSERT INTO identity_service_links(
                        identity_id, organization_id, device_id, profile_id, provider_id,
                        relation, confidence, last_scan_id
                    ) VALUES (?, ?, ?, ?, ?, 'observed_with', ?, ?)
                    ON CONFLICT(identity_id, organization_id, device_id, profile_id, provider_id, relation) DO UPDATE SET
                        confidence=excluded.confidence, last_scan_id=excluded.last_scan_id
                    """,
                    (identity_id, org, device, profile, payload.provider_id, payload.confidence, payload.scan_id),
                )
            for name in payload.secret_names:
                conn.execute(
                    """
                    INSERT INTO secret_indicators(organization_id, device_id, profile_id, provider_id, name, value_exported, last_scan_id)
                    VALUES (?, ?, ?, ?, ?, 0, ?)
                    ON CONFLICT(organization_id, device_id, profile_id, provider_id, name) DO UPDATE SET
                        last_scan_id=excluded.last_scan_id, value_exported=0
                    """,
                    (org, device, profile, payload.provider_id, name, payload.scan_id),
                )
            self._insert_evidence(conn, event, "provider", payload.provider_id, payload.evidence)
        elif event.event_type == CREDENTIAL_STORE_OBSERVED:
            path_refs = list(getattr(payload, "detected_path_refs", [])) or [f"legacy:{x}" for x in payload.detected_paths]
            conn.execute(
                """
                INSERT INTO credential_stores(
                    organization_id, device_id, profile_id, store_id, name, kind, deployment,
                    cloud_capable, cli, cli_available, access_capability, access_attempted,
                    access_status, detected_path_refs_json, profiles_json, warnings_json,
                    first_seen_at, last_seen_at, active, consecutive_missing_scans,
                    last_scan_id, last_global_position
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?)
                ON CONFLICT(organization_id, device_id, profile_id, store_id) DO UPDATE SET
                    name=excluded.name, kind=excluded.kind, deployment=excluded.deployment,
                    cloud_capable=excluded.cloud_capable, cli=excluded.cli,
                    cli_available=excluded.cli_available, access_capability=excluded.access_capability,
                    access_attempted=excluded.access_attempted, access_status=excluded.access_status,
                    detected_path_refs_json=excluded.detected_path_refs_json, profiles_json=excluded.profiles_json,
                    warnings_json=excluded.warnings_json, last_seen_at=excluded.last_seen_at,
                    active=1, consecutive_missing_scans=0, last_scan_id=excluded.last_scan_id,
                    last_global_position=excluded.last_global_position
                """,
                (
                    org, device, profile, payload.store_id, payload.name, payload.kind, payload.deployment,
                    int(payload.cloud_capable), payload.cli or None, int(payload.cli_available),
                    payload.access_capability, int(payload.access_attempted), payload.access_status,
                    json.dumps(path_refs, ensure_ascii=False), json.dumps(list(payload.profiles), ensure_ascii=False),
                    json.dumps(list(payload.warnings), ensure_ascii=False), event.occurred_at, event.occurred_at,
                    payload.scan_id, event.global_position,
                ),
            )
            conn.execute(
                "INSERT OR IGNORE INTO scan_credential_stores(scan_id, store_id) VALUES (?, ?)",
                (payload.scan_id, payload.store_id),
            )
            account_ids = list(getattr(payload, "account_identity_ids", [])) or [f"legacy-email:{x.lower()}" for x in payload.account_emails]
            for identity_id in account_ids:
                conn.execute(
                    """
                    INSERT INTO identities(identity_id, kind, first_seen_at, last_seen_at, last_scan_id, last_global_position)
                    VALUES (?, 'email', ?, ?, ?, ?)
                    ON CONFLICT(identity_id) DO UPDATE SET
                        last_seen_at=excluded.last_seen_at, last_scan_id=excluded.last_scan_id,
                        last_global_position=excluded.last_global_position
                    """,
                    (identity_id, event.occurred_at, event.occurred_at, payload.scan_id, event.global_position),
                )
                conn.execute(
                    """
                    INSERT INTO credential_store_accounts(
                        organization_id, device_id, profile_id, store_id, identity_id, last_scan_id
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(organization_id, device_id, profile_id, store_id, identity_id) DO UPDATE SET
                        last_scan_id=excluded.last_scan_id
                    """,
                    (org, device, profile, payload.store_id, identity_id, payload.scan_id),
                )
            self._insert_evidence(conn, event, "credential_store", payload.store_id, payload.evidence)
        elif event.event_type == CREDENTIAL_REFERENCE_OBSERVED:
            metadata_ref = getattr(payload, "metadata_ref", "") or payload.reference_id
            fingerprint = getattr(payload, "metadata_fingerprint", "") or payload.reference_id
            conn.execute(
                """
                INSERT INTO credential_references(
                    organization_id, device_id, profile_id, reference_id, reference_uri, store_id,
                    record_type, metadata_ref, metadata_fingerprint, first_seen_at, last_seen_at,
                    active, consecutive_missing_scans, last_scan_id, last_global_position, secret_value_present
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?, 0)
                ON CONFLICT(organization_id, device_id, profile_id, reference_id) DO UPDATE SET
                    reference_uri=excluded.reference_uri, store_id=excluded.store_id,
                    record_type=excluded.record_type, metadata_ref=excluded.metadata_ref,
                    metadata_fingerprint=excluded.metadata_fingerprint,
                    last_seen_at=excluded.last_seen_at, active=1, consecutive_missing_scans=0,
                    last_scan_id=excluded.last_scan_id, last_global_position=excluded.last_global_position,
                    secret_value_present=0
                """,
                (
                    org, device, profile, payload.reference_id, payload.reference_uri, payload.store_id,
                    payload.record_type, metadata_ref, fingerprint, event.occurred_at, event.occurred_at,
                    payload.scan_id, event.global_position,
                ),
            )
            conn.execute(
                "INSERT OR IGNORE INTO scan_credential_references(scan_id, reference_id) VALUES (?, ?)",
                (payload.scan_id, payload.reference_id),
            )
        elif event.event_type == OBJECT_STATE_CHANGED:
            table, id_col = {
                "provider": ("services", "provider_id"),
                "credential_store": ("credential_stores", "store_id"),
                "credential_reference": ("credential_references", "reference_id"),
            }.get(payload.object_type, (None, None))
            if table:
                conn.execute(
                    f"""
                    UPDATE {table} SET active=?, consecutive_missing_scans=?, last_scan_id=?
                    WHERE organization_id=? AND device_id=? AND profile_id=? AND {id_col}=?
                    """,
                    (
                        1 if payload.state == "active" else 0,
                        int(payload.consecutive_missing_scans), payload.scan_id,
                        org, device, profile, payload.object_id,
                    ),
                )
        elif event.event_type == SCAN_COMPLETED:
            conn.execute(
                """
                UPDATE scan_runs SET
                    status='completed', completed_at=?, files_considered=?, files_scanned=?, files_skipped=?,
                    provider_count=?, credential_store_count=?, credential_reference_count=?, warnings_json=?
                WHERE scan_id=?
                """,
                (
                    event.occurred_at, int(payload.files_considered), int(payload.files_scanned),
                    int(payload.files_skipped), int(payload.provider_count), int(payload.credential_store_count),
                    int(payload.credential_reference_count), json.dumps(list(payload.warnings), ensure_ascii=False),
                    payload.scan_id,
                ),
            )
        elif event.event_type == SCAN_FAILED:
            conn.execute(
                """
                UPDATE scan_runs SET status='failed', failed_at=?, error_code=?, error_type=?, safe_message=?
                WHERE scan_id=?
                """,
                (event.occurred_at, payload.error_code, payload.error_type, payload.safe_message, payload.scan_id),
            )

    @staticmethod
    def _insert_evidence(conn: sqlite3.Connection, event: StoredEvent, subject_type: str, subject_id: str, evidence) -> None:
        for index, item in enumerate(evidence):
            source_ref = getattr(item, "source_ref", "") or (f"legacy:{item.source}" if item.source else "")
            conn.execute(
                """
                INSERT OR REPLACE INTO evidence(event_id, ordinal, subject_type, subject_id, source_ref, kind, detail, line)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (event.event_id, index, subject_type, subject_id, source_ref, item.kind, item.detail, int(item.line)),
            )

    def object_states(self, organization_id: str, device_id: str, profile_id: str) -> dict[str, dict[str, dict[str, int | bool]]]:
        with self._connect() as conn:
            result: dict[str, dict[str, dict[str, int | bool]]] = {}
            for object_type, table, id_col in (
                ("provider", "services", "provider_id"),
                ("credential_store", "credential_stores", "store_id"),
                ("credential_reference", "credential_references", "reference_id"),
            ):
                rows = conn.execute(
                    f"""
                    SELECT {id_col} AS object_id, active, consecutive_missing_scans
                    FROM {table}
                    WHERE organization_id=? AND device_id=? AND profile_id=?
                    """,
                    (organization_id, device_id, profile_id),
                ).fetchall()
                result[object_type] = {
                    row["object_id"]: {
                        "active": bool(row["active"]),
                        "consecutive_missing_scans": int(row["consecutive_missing_scans"]),
                    }
                    for row in rows
                }
        return result

    def active_object_ids(self, organization_id: str, device_id: str, profile_id: str) -> dict[str, dict[str, int]]:
        states = self.object_states(organization_id, device_id, profile_id)
        return {
            kind: {object_id: int(state["consecutive_missing_scans"]) for object_id, state in values.items() if state["active"]}
            for kind, values in states.items()
        }

    def summary(self, organization_id: str | None = None) -> dict[str, Any]:
        where = " WHERE organization_id=?" if organization_id else ""
        args = (organization_id,) if organization_id else ()
        with self._connect() as conn:
            counts = {
                "scans": int(conn.execute(f"SELECT COUNT(*) AS n FROM scan_runs{where}", args).fetchone()["n"]),
                "services": int(conn.execute(f"SELECT COUNT(*) AS n FROM services{where}", args).fetchone()["n"]),
                "credential_stores": int(conn.execute(
                    f"SELECT COUNT(*) AS n FROM credential_stores{where}", args
                ).fetchone()["n"]),
                "credential_references": int(conn.execute(
                    f"SELECT COUNT(*) AS n FROM credential_references{where}", args
                ).fetchone()["n"]),
            }
            if organization_id:
                counts["identities"] = int(conn.execute(
                    """
                    SELECT COUNT(DISTINCT identity_id) AS n
                    FROM identity_service_links WHERE organization_id=?
                    """,
                    (organization_id,),
                ).fetchone()["n"])
            else:
                counts["identities"] = int(
                    conn.execute("SELECT COUNT(*) AS n FROM identities").fetchone()["n"]
                )
            status_rows = conn.execute(
                f"SELECT status, COUNT(*) AS n FROM scan_runs{where} GROUP BY status", args
            ).fetchall()
            latest = conn.execute(
                f"""
                SELECT * FROM scan_runs{where}
                ORDER BY COALESCE(completed_at, failed_at, started_at, requested_at) DESC LIMIT 1
                """,
                args,
            ).fetchone()
        return {
            "projection": self.NAME,
            "checkpoint": self.checkpoint(),
            "counts": counts,
            "scan_status": {row["status"]: int(row["n"]) for row in status_rows},
            "latest_scan": self._scan_row(latest) if latest else None,
        }

    def get_scan(self, scan_id: str, organization_id: str | None = None) -> dict[str, Any] | None:
        with self._connect() as conn:
            if organization_id:
                row = conn.execute(
                    "SELECT * FROM scan_runs WHERE scan_id=? AND organization_id=?", (scan_id, organization_id)
                ).fetchone()
            else:
                row = conn.execute("SELECT * FROM scan_runs WHERE scan_id=?", (scan_id,)).fetchone()
        return self._scan_row(row) if row else None

    def list_scans(self, limit: int = 100, offset: int = 0, organization_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if organization_id:
                rows = conn.execute(
                    "SELECT * FROM scan_runs WHERE organization_id=? ORDER BY requested_at DESC LIMIT ? OFFSET ?",
                    (organization_id, self._limit(limit), max(0, int(offset))),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM scan_runs ORDER BY requested_at DESC LIMIT ? OFFSET ?",
                    (self._limit(limit), max(0, int(offset))),
                ).fetchall()
        return [self._scan_row(row) for row in rows]

    def list_identities(self, limit: int = 200, offset: int = 0, organization_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if organization_id:
                rows = conn.execute(
                    """
                    SELECT DISTINCT i.identity_id, i.kind, i.last_scan_id, i.first_seen_at, i.last_seen_at
                    FROM identities i
                    WHERE EXISTS (
                        SELECT 1 FROM identity_service_links l
                        WHERE l.identity_id=i.identity_id AND l.organization_id=?
                    ) OR EXISTS (
                        SELECT 1 FROM credential_store_accounts a
                        WHERE a.identity_id=i.identity_id AND a.organization_id=?
                    )
                    ORDER BY i.identity_id LIMIT ? OFFSET ?
                    """,
                    (organization_id, organization_id, self._limit(limit), max(0, int(offset))),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT identity_id, kind, last_scan_id, first_seen_at, last_seen_at FROM identities ORDER BY identity_id LIMIT ? OFFSET ?",
                    (self._limit(limit), max(0, int(offset))),
                ).fetchall()
            result = []
            for row in rows:
                if organization_id:
                    links = conn.execute(
                        "SELECT provider_id FROM identity_service_links WHERE identity_id=? AND organization_id=?",
                        (row["identity_id"], organization_id),
                    ).fetchall()
                else:
                    links = conn.execute(
                        "SELECT provider_id FROM identity_service_links WHERE identity_id=?", (row["identity_id"],)
                    ).fetchall()
                result.append({
                    "identity_id": row["identity_id"], "kind": row["kind"], "last_scan_id": row["last_scan_id"],
                    "first_seen_at": row["first_seen_at"], "last_seen_at": row["last_seen_at"],
                    "services": sorted({x["provider_id"] for x in links}),
                })
        return result

    def list_services(self, limit: int = 200, offset: int = 0, organization_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if organization_id:
                rows = conn.execute(
                    "SELECT * FROM services WHERE organization_id=? ORDER BY provider_name LIMIT ? OFFSET ?",
                    (organization_id, self._limit(limit), max(0, int(offset))),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM services ORDER BY provider_name LIMIT ? OFFSET ?",
                    (self._limit(limit), max(0, int(offset))),
                ).fetchall()
            result = []
            for row in rows:
                ids = conn.execute(
                    """
                    SELECT identity_id FROM identity_service_links
                    WHERE organization_id=? AND device_id=? AND profile_id=? AND provider_id=?
                    ORDER BY identity_id
                    """,
                    (row["organization_id"], row["device_id"], row["profile_id"], row["provider_id"]),
                ).fetchall()
                indicators = conn.execute(
                    """
                    SELECT name FROM secret_indicators
                    WHERE organization_id=? AND device_id=? AND profile_id=? AND provider_id=? ORDER BY name
                    """,
                    (row["organization_id"], row["device_id"], row["profile_id"], row["provider_id"]),
                ).fetchall()
                result.append({
                    "organization_id": row["organization_id"], "device_id": row["device_id"],
                    "profile_id": row["profile_id"], "provider_id": row["provider_id"],
                    "provider_name": row["provider_name"], "category": row["category"],
                    "confidence": row["confidence"], "last_scan_id": row["last_scan_id"],
                    "identity_ids": [x["identity_id"] for x in ids],
                    "secret_indicators": [x["name"] for x in indicators],
                    "first_seen_at": row["first_seen_at"], "last_seen_at": row["last_seen_at"],
                    "active": bool(row["active"]), "consecutive_missing_scans": int(row["consecutive_missing_scans"]),
                })
        return result

    def list_credential_stores(self, limit: int = 200, offset: int = 0, organization_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if organization_id:
                rows = conn.execute(
                    "SELECT * FROM credential_stores WHERE organization_id=? ORDER BY name LIMIT ? OFFSET ?",
                    (organization_id, self._limit(limit), max(0, int(offset))),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM credential_stores ORDER BY name LIMIT ? OFFSET ?",
                    (self._limit(limit), max(0, int(offset))),
                ).fetchall()
            result = []
            for row in rows:
                accounts = conn.execute(
                    """
                    SELECT identity_id FROM credential_store_accounts
                    WHERE organization_id=? AND device_id=? AND profile_id=? AND store_id=? ORDER BY identity_id
                    """,
                    (row["organization_id"], row["device_id"], row["profile_id"], row["store_id"]),
                ).fetchall()
                result.append({
                    "organization_id": row["organization_id"], "device_id": row["device_id"],
                    "profile_id": row["profile_id"], "store_id": row["store_id"], "name": row["name"],
                    "kind": row["kind"], "deployment": row["deployment"],
                    "cloud_capable": bool(row["cloud_capable"]), "cli": row["cli"],
                    "cli_available": bool(row["cli_available"]), "access_capability": row["access_capability"],
                    "access_attempted": bool(row["access_attempted"]), "access_status": row["access_status"],
                    "detected_path_refs": json.loads(row["detected_path_refs_json"]),
                    "profiles": json.loads(row["profiles_json"]), "warnings": json.loads(row["warnings_json"]),
                    "account_identity_ids": [x["identity_id"] for x in accounts], "last_scan_id": row["last_scan_id"],
                    "first_seen_at": row["first_seen_at"], "last_seen_at": row["last_seen_at"],
                    "active": bool(row["active"]), "consecutive_missing_scans": int(row["consecutive_missing_scans"]),
                })
        return result

    def list_credential_references(self, limit: int = 200, offset: int = 0, organization_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if organization_id:
                rows = conn.execute(
                    "SELECT * FROM credential_references WHERE organization_id=? ORDER BY reference_uri LIMIT ? OFFSET ?",
                    (organization_id, self._limit(limit), max(0, int(offset))),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM credential_references ORDER BY reference_uri LIMIT ? OFFSET ?",
                    (self._limit(limit), max(0, int(offset))),
                ).fetchall()
        return [{
            "organization_id": row["organization_id"], "device_id": row["device_id"],
            "profile_id": row["profile_id"], "reference_id": row["reference_id"],
            "reference_uri": row["reference_uri"], "store_id": row["store_id"],
            "record_type": row["record_type"], "metadata_ref": row["metadata_ref"],
            "metadata_fingerprint": row["metadata_fingerprint"], "last_scan_id": row["last_scan_id"],
            "secret_value_present": bool(row["secret_value_present"]), "first_seen_at": row["first_seen_at"],
            "last_seen_at": row["last_seen_at"], "active": bool(row["active"]),
            "consecutive_missing_scans": int(row["consecutive_missing_scans"]),
        } for row in rows]

    @staticmethod
    def _limit(value: int) -> int:
        return max(1, min(int(value), 1000))

    @staticmethod
    def _scan_row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "scan_id": row["scan_id"], "stream_id": row["stream_id"], "status": row["status"],
            "home_ref": row["home_ref"], "platform": row["platform"], "deep_home": bool(row["deep_home"]),
            "include_credential_stores": bool(row["include_credential_stores"]),
            "credential_access": row["credential_access"], "allow_manager_network": bool(row["allow_manager_network"]),
            "actor_id": row["actor_id"], "principal_id": row["principal_id"],
            "organization_id": row["organization_id"], "subject_user_id": row["subject_user_id"],
            "device_id": row["device_id"], "profile_id": row["profile_id"],
            "installation_id": row["installation_id"], "trace_id": row["trace_id"],
            "requested_at": row["requested_at"], "started_at": row["started_at"],
            "completed_at": row["completed_at"], "failed_at": row["failed_at"],
            "files_considered": int(row["files_considered"]), "files_scanned": int(row["files_scanned"]),
            "files_skipped": int(row["files_skipped"]), "provider_count": int(row["provider_count"]),
            "credential_store_count": int(row["credential_store_count"]),
            "credential_reference_count": int(row["credential_reference_count"]),
            "warnings": json.loads(row["warnings_json"]), "error_code": row["error_code"],
            "error_type": row["error_type"], "safe_message": row["safe_message"],
        }
