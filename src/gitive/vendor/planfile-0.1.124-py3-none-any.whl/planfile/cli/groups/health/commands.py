"""Health check CLI commands."""

import typer
from rich.console import Console

console = Console()


def create_health_app() -> typer.Typer:
    """Create and return the health sub-app."""
    app = typer.Typer(help="Health check commands")

    @app.command("check")
    def health_cmd(
        project_path: str = typer.Argument(".", help="Project path to check"),
    ) -> None:
        """Check project health and suggest improvements."""
        try:
            from planfile.analysis.generator import generator

            console.print("[bold]Analyzing project health...[/bold]")

            # Quick analysis
            strategy = generator.generate_from_current_project(
                project_path=project_path,
                max_sprints=2
            )

            # Show health metrics
            summary = strategy.get('summary', {})

            console.print("\n[bold]Health Metrics:[/bold]")

            # Issues
            total_issues = summary.get('total_issues', 0)
            if total_issues == 0:
                console.print("  [green]✓ No issues found[/green]")
            else:
                console.print(f"  [yellow]⚠ {total_issues} issues found[/yellow]")

            # Complexity
            avg_cc = summary.get('avg_complexity', 0)
            if avg_cc > 10:
                console.print(f"  [red]✓ High complexity: {avg_cc:.1f}[/red]")
            else:
                console.print(f"  [green]✓ Acceptable complexity: {avg_cc:.1f}[/green]")

            # Duplication
            duplication = summary.get('duplication', 0)
            if duplication > 5:
                console.print(f"  [red]✓ High duplication: {duplication}%[/red]")
            else:
                console.print(f"  [green]✓ Low duplication: {duplication}%[/green]")

            # Recommendations
            console.print("\n[bold]Recommendations:[/bold]")
            for rec in summary.get('recommendations', []):
                console.print(f"  • {rec}")

            # Show top issues
            issues = strategy.get('tickets', [])
            if isinstance(issues, dict):
                ordered = []
                for bucket in ("critical", "high", "medium", "low"):
                    ordered.extend(issues.get(bucket, []))
                issues = ordered
            if issues:
                console.print("\n[bold]Top Issues:[/bold]")
                for issue in issues[:5]:
                    priority = issue.get('priority', 'normal')
                    title = issue.get('name') or issue.get('title') or 'Unknown'
                    if priority == 'critical':
                        console.print(f"  [red]✗[/red] {title}")
                    elif priority == 'high':
                        console.print(f"  [yellow]⚠[/yellow] {title}")
                    else:
                        console.print(f"  [blue]•[/blue] {title}")

        except Exception as e:
            console.print(f"[red]✗[/red] Error analyzing project: {e}")
            raise typer.Exit(1)

    @app.command("cache")
    def cache_cmd(
        project_path: str = typer.Argument(".", help="Project path to check"),
    ) -> None:
        """Audit .fast.json read caches against their source YAML and self-heal drift.

        Catches the class of bug where a concurrent writer races a cache write and a
        later reader trusts a stale (or empty) snapshot forever because it carries a
        matching mtime — see planfile.core.fastio.read_yaml_fast for the mechanism.
        Exits 1 if any drift was found, even when it was healed, so this can be run
        periodically (e.g. by koru) or wired into CI as an early-warning check.
        """
        from pathlib import Path

        from planfile.core.fastio import audit_project_mirrors

        base_dir = Path(project_path).resolve() / ".planfile"
        if not base_dir.exists():
            console.print(f"[yellow]No .planfile/ at {base_dir}[/yellow]")
            raise typer.Exit(0)

        results = audit_project_mirrors(base_dir)
        drift = [r for r in results if not r["ok"]]
        if not drift:
            console.print(f"[green]✓ cache OK[/green] ({len(results)} mirror file(s) checked)")
            raise typer.Exit(0)

        console.print(f"[red]✗ {len(drift)}/{len(results)} cache mirror(s) drifted[/red]")
        for r in drift:
            status = "healed" if r["healed"] else "NOT healed"
            console.print(f"  [yellow]{status}[/yellow] {r['path']}: {r['reason']}")
        raise typer.Exit(1)

    return app
