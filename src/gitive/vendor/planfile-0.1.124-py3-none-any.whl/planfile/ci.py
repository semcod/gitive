"""
CI runner with automated bug-fix loop — ticket-aware refactor.

Merged logic from ci_runner.py (453L) + auto_loop.py display helpers.
Creates planfile tickets from test/analysis failures.
"""

import json
import re
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from planfile.loaders.yaml_loader import load_strategy_yaml
from planfile.runner import review_strategy


@dataclass
class TestResult:
    """Result of running tests."""

    # Not a pytest test class despite the ``Test`` prefix — tell the collector
    # so it stops emitting a PytestCollectionWarning for the ``__init__``.
    __test__ = False

    passed: bool
    failed_tests: list[str]
    coverage: float
    metrics: dict[str, Any]
    output: str


@dataclass
class BugReport:
    """Generated bug report from test failures."""
    name: str
    description: str
    files: list[str]
    test_names: list[str]
    severity: str


class CIRunner:
    """CI/CD runner with automated bug-fix loop and ticket creation."""

    def __init__(
        self,
        strategy_path: str,
        project_path: str,
        backends: dict[str, Any] = None,
        llx_command: str = "llx",
        max_iterations: int = 10,
        auto_fix: bool = False,
        dry_run: bool = False,
        planfile_instance=None,
    ):
        self.strategy_path = Path(strategy_path)
        self.project_path = Path(project_path)
        self.backends = backends or {}
        self.llx_command = llx_command
        self.max_iterations = max_iterations
        self.auto_fix = auto_fix
        self.dry_run = dry_run
        self.strategy = load_strategy_yaml(strategy_path)
        self.iteration = 0

        # Optional planfile ticket integration
        self.pf = planfile_instance
        if self.pf is None:
            try:
                from planfile import Planfile
                self.pf = Planfile.auto_discover(str(self.project_path))
            except Exception:
                self.pf = None

    @staticmethod
    def _extract_json_object(raw_output: str) -> dict[str, Any] | None:
        """Extract JSON object from plain or markdown-wrapped llx output."""
        text = (raw_output or "").strip()
        if not text:
            return None

        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass

        fenced_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        if fenced_match:
            try:
                data = json.loads(fenced_match.group(1))
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                pass

        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            try:
                data = json.loads(text[start:end + 1])
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                pass

        return None

    def run_tests(self) -> TestResult:
        """Run tests and return results."""
        cmd = [
            "python", "-m", "pytest",
            "--cov=planfile",
            "--cov-report=json",
            "--cov-report=term-missing",
            "--junit-xml=test-results.xml",
            "-v"
        ]

        result = subprocess.run(
            cmd, cwd=self.project_path,
            capture_output=True, text=True
        )

        coverage = 0.0
        coverage_file = self.project_path / "coverage.json"
        if coverage_file.exists():
            coverage_data = json.loads(coverage_file.read_text())
            coverage = coverage_data.get("totals", {}).get("percent_covered", 0.0)

        failed_tests = []
        if result.returncode != 0:
            for line in result.stdout.split('\n'):
                if "FAILED" in line and "::" in line:
                    test_name = line.split("FAILED")[1].strip()
                    failed_tests.append(test_name)

        return TestResult(
            passed=result.returncode == 0,
            failed_tests=failed_tests,
            coverage=coverage,
            metrics={"coverage": coverage},
            output=result.stdout + result.stderr
        )

    def run_code_analysis(self) -> dict[str, Any]:
        """Run code2llm and vallm analysis."""
        metrics = {}

        try:
            result = subprocess.run(
                [self.llx_command, "analyze", "--run", "--json"],
                cwd=self.project_path, capture_output=True, text=True
            )
            if result.returncode == 0:
                metrics["code2llm"] = json.loads(result.stdout)
        except Exception:
            pass

        try:
            result = subprocess.run(
                ["vallm", "validate", "--json"],
                cwd=self.project_path, capture_output=True, text=True
            )
            if result.returncode == 0:
                metrics["vallm"] = json.loads(result.stdout)
        except Exception:
            pass

        return metrics

    def generate_bug_report(self, test_result: TestResult, metrics: dict[str, Any]) -> BugReport:
        """Generate bug report using LLM."""
        context = {
            "failed_tests": test_result.failed_tests,
            "coverage": test_result.coverage,
            "metrics": metrics,
            "output": test_result.output[-2000:]
        }

        prompt = f"""
Based on the following test failures and code metrics, create a bug report:

Failed tests: {context['failed_tests']}
Coverage: {context['coverage']}%
Code metrics: {json.dumps(metrics, indent=2)}

Recent test output:
{context['output']}

Respond in JSON format:
{{"title": "...", "description": "...", "files": ["file1.py"], "severity": "high"}}
"""

        result = subprocess.run(
            [self.llx_command, "chat", "--model", "balanced", "--prompt", prompt],
            cwd=self.project_path,
            capture_output=True,
            text=True,
        )

        bug_data = self._extract_json_object(result.stdout)
        if result.returncode == 0 and bug_data:
            name = bug_data.get("name") or bug_data.get("title")
            description = bug_data.get("description")
            if name and description:
                files = bug_data.get("files") or []
                if not isinstance(files, list):
                    files = []
                severity = bug_data.get("severity") or "medium"
                return BugReport(
                    name=str(name),
                    description=str(description),
                    files=[str(file_path) for file_path in files],
                    test_names=test_result.failed_tests,
                    severity=str(severity),
                )

        return BugReport(
            name=f"Tests failed: {len(test_result.failed_tests)} failures",
            description=f"Tests failed: {', '.join(test_result.failed_tests)}",
            files=[],
            test_names=test_result.failed_tests,
            severity="medium",
        )

    def create_bug_tickets(self, bug_report: BugReport) -> list[str]:
        """Create bug tickets in configured backends AND local planfile."""
        if self.dry_run:
            return []

        ticket_urls = []

        # Create local planfile ticket
        if self.pf:
            try:
                from planfile import TicketSource
                ticket = self.pf.create_ticket(
                    name=bug_report.name,
                    priority="critical" if bug_report.severity in ("high", "critical") else "normal",
                    source=TicketSource(tool="ci-runner", context={
                        "error": bug_report.description[:500],
                        "files": bug_report.files,
                    }),
                    labels=["bug", "auto-generated", f"severity-{bug_report.severity}"],
                    description=bug_report.description,
                )
                ticket_urls.append(f"planfile:{ticket.id}")
            except Exception:
                pass

        # Create in external backends
        for _name, backend in self.backends.items():
            try:
                ticket = backend.create_ticket(
                    name=bug_report.name,
                    description=bug_report.description,
                    labels=["bug", "auto-generated", f"severity-{bug_report.severity}"],
                    priority="high" if bug_report.severity in ("high", "critical") else "medium"
                )
                ticket_urls.append(ticket.url)
            except Exception:
                pass

        return ticket_urls

    def _resolve_target_file(self, bug_report: BugReport) -> str:
        """Resolve best target file path for llx plan run task."""
        project_root = self.project_path.resolve()

        for file_path in bug_report.files:
            if not file_path:
                continue

            candidate = Path(file_path)
            if candidate.is_absolute():
                try:
                    return str(candidate.resolve().relative_to(project_root))
                except ValueError:
                    return str(candidate)

            full_candidate = project_root / candidate
            if full_candidate.exists():
                return str(candidate)

        return ""

    @staticmethod
    def _task_patch_applied(results_payload: dict[str, Any]) -> bool:
        """Check llx plan run output payload for real file changes."""
        results = results_payload.get("results") or []
        if not isinstance(results, list):
            return False

        return any(
            isinstance(item, dict)
            and item.get("status") == "success"
            and bool(item.get("file_changed"))
            for item in results
        )

    @staticmethod
    def _extract_yaml_object(raw_output: str) -> dict[str, Any] | None:
        """Extract YAML object from llx stdout, including fenced markdown payloads."""
        text = (raw_output or "").strip()
        if not text:
            return None

        try:
            data = yaml.safe_load(text)
            if isinstance(data, dict):
                return data
        except yaml.YAMLError:
            pass

        fenced_match = re.search(r"```(?:yaml|yml)?\s*(.*?)\s*```", text, re.DOTALL)
        if fenced_match:
            try:
                data = yaml.safe_load(fenced_match.group(1))
                if isinstance(data, dict):
                    return data
            except yaml.YAMLError:
                pass

        return None

    def auto_fix_bugs(self, bug_report: BugReport) -> bool:
        """Attempt to auto-fix bugs via llx plan run editing backend."""
        if not self.auto_fix:
            return False

        target_file = self._resolve_target_file(bug_report)
        if not target_file:
            return False

        ticket_id = f"ci-autofix-{int(time.time())}"
        task_description = (
            f"{bug_report.description}\n\n"
            f"Failed tests: {', '.join(bug_report.test_names)}\n"
            "Apply a minimal patch to resolve the failing tests."
        )

        temp_planfile = {
            "name": "ci-auto-fix",
            "tasks": [
                {
                    "id": ticket_id,
                    "title": bug_report.name,
                    "description": task_description,
                    "file": target_file,
                    "action": "fix",
                    "priority": 1,
                }
            ],
        }

        with tempfile.TemporaryDirectory(prefix="planfile-ci-autofix-") as temp_dir:
            temp_dir_path = Path(temp_dir)
            strategy_path = temp_dir_path / "ci-autofix.planfile.yaml"

            strategy_path.write_text(
                yaml.safe_dump(temp_planfile, sort_keys=False),
                encoding="utf-8",
            )

            cmd = [
                self.llx_command,
                "plan",
                "run",
                str(strategy_path),
                "--format",
                "yaml",
                "--project",
                str(self.project_path),
                "--ticket-id",
                ticket_id,
                "--max-tasks",
                "1",
                "--use-aider",
            ]

            result = subprocess.run(
                cmd,
                cwd=self.project_path,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                return False

            payload = self._extract_yaml_object(result.stdout)
            if not payload:
                return False

            return self._task_patch_applied(payload)

    def check_strategy_completion(self) -> tuple[bool, list[str]]:
        """Check if strategy goals are met."""
        if not self.backends:
            return True, []

        backend_name = next(iter(self.backends))
        review = review_strategy(
            strategy=self.strategy,
            project_path=str(self.project_path),
            backends=self.backends,
            backend_name=backend_name,
        )

        issues = []
        summary = review.get("summary", {})

        if summary.get("total_tickets", 0) > summary.get("completed", 0):
            issues.append(f"Not all tickets completed: {summary['completed']}/{summary['total_tickets']}")

        if summary.get("blocked", 0) > 0:
            issues.append(f"{summary['blocked']} tickets are blocked")

        return len(issues) == 0, issues

    def run_loop(self) -> dict[str, Any]:
        """Run the main CI/CD loop."""
        results = {
            "iterations": [],
            "success": False,
            "total_iterations": 0,
            "tickets_created": [],
            "final_status": "failed"
        }

        for iteration in range(1, self.max_iterations + 1):
            self.iteration = iteration
            results["total_iterations"] = self.iteration
            iteration_result = {
                "iteration": self.iteration,
                "tests_passed": False,
                "tickets_created": [],
                "auto_fixed": False
            }

            test_result = self.run_tests()
            iteration_result["tests_passed"] = test_result.passed
            iteration_result["coverage"] = test_result.coverage

            if test_result.passed:
                strategy_complete, issues = self.check_strategy_completion()

                if strategy_complete:
                    results["success"] = True
                    results["final_status"] = "completed"
                    iteration_result["status"] = "completed"
                    results["iterations"].append(iteration_result)
                    break
            else:
                metrics = self.run_code_analysis()
                bug_report = self.generate_bug_report(test_result, metrics)
                ticket_urls = self.create_bug_tickets(bug_report)
                iteration_result["tickets_created"] = ticket_urls
                results["tickets_created"].extend(ticket_urls)

                if self.auto_fix:
                    fixed = self.auto_fix_bugs(bug_report)
                    iteration_result["auto_fixed"] = fixed

                iteration_result["status"] = "failed"

            results["iterations"].append(iteration_result)
            if self.iteration < self.max_iterations:
                time.sleep(2)

        if not results["success"]:
            results["final_status"] = "max_iterations_reached"

        return results

    def save_results(self, results: dict[str, Any], output_path: str | None = None) -> None:
        """Save results to file."""
        if not output_path:
            output_path = self.project_path / "ci-results.json"
        Path(output_path).write_text(json.dumps(results, indent=2))
